## 0.1.4

- Support for NC 19
- Add scaling options
- Fix : https://github.com/PaulLereverend/NextcloudVideo_Converter/issues/35

## 0.1.3

- Support for NC 18
- Fix security issue

## 0.1.2

- Support for NC 17
- Fix issue on shared folders
- Fix incorrect stack trace

## 0.1.0

- Fix : https://github.com/PaulLereverend/NextcloudVideo_Converter/issues/4
- Fix : https://github.com/PaulLereverend/NextcloudVideo_Converter/issues/6
- Fix : https://github.com/PaulLereverend/NextcloudVideo_Converter/issues/3
- Fix : Override on external local storage.
- Fix : Clarify a few error messages

## 0.0.2

- Initial release
