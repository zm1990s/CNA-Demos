# Video_Converter
Place this app in **nextcloud/apps/**

This app does only support local external storage backend

## Features

* Video Conversion
* Override or not
* Preset option
* More incoming...

## Output supported

* MP4
* AVI
* WEBM
* M4V
* More incoming...

## Requirements

* FFmpeg

## TODO

* Convert multiple files at once
* Schedule conversion
* Choose codec
* Support encrypted files

## PREVIEW 

![alt text](https://raw.githubusercontent.com/PaulLereverend/NextcloudVideo_Converter/master/img/appstore.gif)
