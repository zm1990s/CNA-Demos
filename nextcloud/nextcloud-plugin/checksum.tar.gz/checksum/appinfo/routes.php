<?php
/**
 * adding route for ajax callback
 */
return ['routes' => [
    ['name' => 'checksum#check', 'url' => '/check', 'verb' => 'GET']
]];