<?php

$app = new \OCA\Transmission\AppInfo\Application();
$app->registerHooks();

