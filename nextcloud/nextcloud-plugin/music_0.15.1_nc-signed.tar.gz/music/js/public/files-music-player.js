function EmbeddedPlayer(onClose, onNext, onPrev) {

	var player = new PlayerWrapper();

	var volume = Cookies.get('oc_music_volume') || 50;
	player.setVolume(volume);
	var nextPrevEnabled = false;
	var playDelayTimer = null;
	var currentFileId = null;
	var playTime_s = 0;

	// UI elements (jQuery)
	var musicControls = null;
	var playButton = null;
	var pauseButton = null;
	var prevButton = null;
	var nextButton = null;
	var coverImage = null;
	var titleText = null;
	var artistText = null;

	function play() {
		// discard command while switching to new track is ongoing
		if (!playDelayTimer) {
			player.play();
		}
	}

	function pause() {
		// discard command while switching to new track is ongoing
		if (!playDelayTimer) {
			player.pause();
		}
	}

	function togglePlayback() {
		if (player.isPlaying()) {
			pause();
		} else {
			play();
		}
	}

	function close() {
		player.stop();
		musicControls.css('display', 'none');
		onClose();
	}

	function previous() {
		// Jump to the beginning of the current track if it has already played more than 2 secs
		if (playTime_s > 2.0 && player.seekingSupported()) {
			player.seek(0);
		}
		// Jump to the previous track if the current track has played only 2 secs or less
		else if (nextPrevEnabled && onPrev) {
			onPrev();
		}
		// Jump to the beginning of the current track even if the track has played less than 2 secs
		// but there's no previous track to jump to
		else if (player.seekingSupported()) {
			player.seek(0);
		}
	}

	function next() {
		if (nextPrevEnabled && onNext) {
			onNext();
		}
	}

	function seekBackward() {
		player.seekBackward();
	}

	function seekForward() {
		player.seekForward();
	}

	function createPlayButton() {
		return $(document.createElement('img'))
			.attr('id', 'play')
			.attr('class', 'control svg')
			.attr('src', OC.imagePath('music', 'play-big'))
			.attr('alt', t('music', 'Play'))
			.css('display', 'inline-block')
			.click(play);
	}

	function createPauseButton() {
		return $(document.createElement('img'))
			.attr('id', 'pause')
			.attr('class', 'control svg')
			.attr('src', OC.imagePath('music', 'pause-big'))
			.attr('alt', t('music', 'Pause'))
			.css('display', 'none')
			.click(pause);
	}

	function createPrevButton() {
		return $(document.createElement('img'))
			.attr('id', 'prev')
			.attr('class', 'control svg small disabled')
			.attr('src', OC.imagePath('music', 'play-previous'))
			.attr('alt', t('music', 'Previous'))
			.click(previous);
	}

	function createNextButton() {
		return $(document.createElement('img'))
			.attr('id', 'next')
			.attr('class', 'control svg small disabled')
			.attr('src', OC.imagePath('music', 'play-next'))
			.attr('alt', t('music', 'Next'))
			.click(next);
	}

	function createCoverImage() {
		return $(document.createElement('div')).attr('id', 'albumart');
	}

	function createProgressInfo() {
		var container = $(document.createElement('div')).attr('class', 'progress-info');

		var text = $(document.createElement('span')).attr('class', 'progress-text');

		var seekBar = $(document.createElement('div')).attr('class', 'seek-bar');
		var playBar = $(document.createElement('div')).attr('class', 'play-bar');
		var bufferBar = $(document.createElement('div')).attr('class', 'buffer-bar');

		seekBar.append(playBar);
		seekBar.append(bufferBar);

		container.append(text);
		container.append(seekBar);

		// Progress updating
		var songLength_s = 0;

		function formatTime(seconds) {
			var minutes = Math.floor(seconds/60);
			seconds = Math.floor(seconds - (minutes * 60));
			return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
		}

		function updateProgress() {
			var ratio = 0;
			if (songLength_s === 0) {
				text.text(t('music', 'Loading…'));
			} else {
				text.text(formatTime(playTime_s) + '/' + formatTime(songLength_s));
				ratio = playTime_s / songLength_s;
			}
			playBar.css('width', 100 * ratio + '%');
		}

		function setCursorType(type) {
			seekBar.css('cursor', type);
			playBar.css('cursor', type);
			bufferBar.css('cursor', type);
		}

		player.on('loading', function() {
			playTime_s = 0;
			songLength_s = 0;
			updateProgress();
			bufferBar.css('width', '0');
			setCursorType('default');
		});
		player.on('ready', function() {
			if (player.seekingSupported()) {
				setCursorType('pointer');
			}
		});
		player.on('buffer', function(percent) {
			bufferBar.css('width', Math.round(percent) + '%');
		});
		player.on('progress', function(msecs) {
			playTime_s = Math.round(msecs/1000);
			updateProgress();
		});
		player.on('duration', function(msecs) {
			songLength_s = Math.round(msecs/1000);
			updateProgress();
		});
		player.on('play', function() {
			playButton.css('display', 'none');
			pauseButton.css('display', 'inline-block');
		});
		player.on('pause', function() {
			playButton.css('display', 'inline-block');
			pauseButton.css('display', 'none');
		});

		// Seeking
		seekBar.click(function (event) {
			var posX = $(this).offset().left;
			var percentage = (event.pageX - posX) / seekBar.width();
			player.seek(percentage);
		});

		return container;
	}

	function createInfoProgressContainer() {
		titleText = $(document.createElement('span')).attr('id', 'title');
		artistText = $(document.createElement('span')).attr('id', 'artist');

		var songInfo = $(document.createElement('div')).attr('id', 'song-info');
		songInfo.append(titleText);
		songInfo.append($(document.createElement('br')));
		songInfo.append(artistText);

		var infoProgressContainer = $(document.createElement('div')).attr('id', 'info-and-progress');
		infoProgressContainer.append(songInfo);
		infoProgressContainer.append(createProgressInfo());
		return infoProgressContainer;
	}

	function createVolumeControl() {
		var volumeControl = $(document.createElement('div'))
			.attr('class', 'volume-control');

		var volumeIcon = $(document.createElement('img'))
			.attr('id', 'volume-icon')
			.attr('class', 'control small svg')
			.attr('src', OC.imagePath('music', 'sound'));

		var volumeSlider = $(document.createElement('input'))
			.attr('id', 'volume-slider')
			.attr('min', '0')
			.attr('max', '100')
			.attr('type', 'range')
			.attr('value', volume)
			.on('input change', function() {
				volume = $(this).val();
				player.setVolume(volume);
				Cookies.set('oc_music_volume', volume, { expires: 3650 });
			});

		volumeControl.append(volumeIcon);
		volumeControl.append(volumeSlider);

		return volumeControl;
	}

	function createCloseButton() {
		return $(document.createElement('img'))
			.attr('id', 'close')
			.attr('class', 'control small svg')
			.attr('src', OC.imagePath('music', 'close'))
			.attr('alt', t('music', 'Close'))
			.click(close);
	}

	function createUi() {
		musicControls = $(document.createElement('div')).attr('id', 'music-controls');

		playButton = createPlayButton();
		pauseButton = createPauseButton();
		prevButton = createPrevButton();
		nextButton = createNextButton();
		coverImage = createCoverImage();

		musicControls.append(prevButton);
		musicControls.append(playButton);
		musicControls.append(pauseButton);
		musicControls.append(nextButton);
		musicControls.append(coverImage);
		musicControls.append(createInfoProgressContainer());
		musicControls.append(createVolumeControl());
		musicControls.append(createCloseButton());

		if (OC_Music_Utils.darkThemeActive()) {
			musicControls.addClass('dark-theme');
		}

		var parentContainer = $('div#app-content');
		var isSharePage = (parentContainer.length === 0);
		if (isSharePage) {
			// On share page, there's no #app-content. Use #preview element as parent, instead.
			parentContainer = $('div#preview');
			musicControls.css('left', '0');
		}
		var getViewWidth = function() {
			var width = parentContainer.width();
			// On the share page and in NC14+, the parent width has the scroll bar width
			// already subtracted.
			if (!isSharePage && !OC_Music_Utils.newLayoutStructure()) {
				width -= OC.Util.getScrollBarWidth();
			}
			return width;
		};

		parentContainer.append(musicControls);

		// Resize music controls bar to fit the scroll bar when window size changes or details pane opens/closes.
		// Also the internal layout of the bar is responsive to the available width.
		resizeControls = function() {
			var width = getViewWidth();
			musicControls.css('width', width);
			if (width > 768) {
				musicControls.removeClass('tablet mobile extra-narrow');
			} else if (width > 500) {
				musicControls.addClass('tablet');
				musicControls.removeClass('mobile extra-narrow');
			} else if (width > 360) {
				musicControls.addClass('tablet mobile');
				musicControls.removeClass('extra-narrow');
			} else {
				musicControls.addClass('tablet mobile extra-narrow');
			}
		};
		parentContainer.resize(resizeControls);
		resizeControls();

		player.on('end', onNext);
	}

	function musicAppLinkElements() {
		return $('#song-info *, #albumart');
	}

	function updateMetadata(data) {
		titleText.text(data.title);
		artistText.text(data.artist);

		var cover = data.cover || OC.imagePath('core', 'filetypes/audio');
		coverImage.css('background-image', 'url("' + cover + '")');

		updateMediaSession(data);
	}

	function loadFileInfoFromUrl(url, fallbackTitle, fileId, callback /*optional*/) {
		$.get(url, function(data) {
			// discard results if the file has already changed by the time the
			// result arrives
			if (currentFileId == fileId) {
				updateMetadata(data);

				if (callback) {
					callback(data, fileId);
				}
			}
		}).fail(function() {
			updateMetadata({
				title: fallbackTitle,
				artist: '',
				cover: null
			});
		});
	}

	function titleFromFilename(filename) {
		// parsing logic is ported form parseFileName in utility/scanner.php
		var match = filename.match(/^((\d+)\s*[.-]\s+)?(.+)\.(\w{1,4})$/);
		return match ? match[3] : filename;
	}

	function playUrl(url, mime, tempTitle, nextStep) {
		pause();

		// Set placeholders for track info fields, proper data is filled once received
		updateMetadata({
			title: t('music', 'Loading…'),
			artist: tempTitle,
			cover: null
		});
		musicAppLinkElements().css('cursor', 'default').off("click");

		// Add a small delay before actually starting to load any data. This is
		// to avoid flooding HTTP requests in case the user rapidly jumps over
		// tracks.
		if (playDelayTimer) {
			clearTimeout(playDelayTimer);
		}
		playDelayTimer = setTimeout(function() {
			playDelayTimer = null;
			player.fromURL(url, mime);
			play();
			nextStep();

			// 'Previous' button is enalbed regardless of the playlist size if seeking is
			// supported for the file being played 
			updateNextPrevButtonStatus();
		}, 300);
	}

	function loadFileInfo(fileId, fallbackTitle) {
		var url  = OC.generateUrl('apps/music/api/file/{fileId}/info', {'fileId':fileId});
		loadFileInfoFromUrl(url, fallbackTitle, fileId, updateMusicAppLink);
	}

	function updateMusicAppLink(data, fileId) {
		if (data.in_library) {
			var navigateToMusicApp = function() {
				window.location = OC.generateUrl('apps/music/#/file/{fileId}', {'fileId':fileId});
			};
			musicAppLinkElements()
				.css('cursor', 'pointer')
				.click(navigateToMusicApp)
				.attr('title', t('music', 'Go to album'));
		}
		else {
			musicAppLinkElements().attr('title', t('music', '(file is not within your music collection folder)'));
		}
	}

	function loadSharedFileInfo(shareToken, fileId, fallbackTitle) {
		var url  = OC.generateUrl('apps/music/api/share/{token}/{fileId}/info',
				{'token':shareToken, 'fileId':fileId});
		loadFileInfoFromUrl(url, fallbackTitle, fileId);
	}

	function updateNextPrevButtonStatus() {
		if (nextPrevEnabled) {
			nextButton.removeClass('disabled');
		} else {
			nextButton.addClass('disabled');
		}

		if (nextPrevEnabled || player.seekingSupported()) {
			prevButton.removeClass('disabled');
		} else {
			prevButton.addClass('disabled');
		}
	}

	/**
	 * Integration to the media control panel available on Chrome starting from version 73 and Edge from
	 * version 83. In Firefox, it is still disabled in the version 77, but a partially working support can
	 * be enabled via the advanced settings.
	 *
	 * The API brings the bindings with the special multimedia keys possibly present on the keyboard,
	 * as well as any OS multimedia controls available e.g. in status pane and/or lock screen.
	 */
	if ('mediaSession' in navigator) {
		var registerMediaControlHandler = function(action, handler) {
			try {
				navigator.mediaSession.setActionHandler(action, handler);
			} catch (error) {
				console.log("The media control '" + action + "' is not supported by the browser");
			}
		};

		registerMediaControlHandler('play', play);
		registerMediaControlHandler('pause', pause);
		registerMediaControlHandler('stop', close);
		registerMediaControlHandler('seekbackward', seekBackward);
		registerMediaControlHandler('seekforward', seekForward);
		registerMediaControlHandler('previoustrack', previous);
		registerMediaControlHandler('nexttrack', next);
	}

	function updateMediaSession(data) {
		if ('mediaSession' in navigator) {
			navigator.mediaSession.metadata = new MediaMetadata({
				title: data.title,
				artist: data.artist,
				album: '',
				artwork: [{
					sizes: "200x200",
					src: data.cover,
					type: ""
				}]
			});
		}
	}

	/**
	 * PUBLIC INTEFACE
	 */

	this.show = function() {
		if (!musicControls) {
			createUi();
		}
		musicControls.css('display', 'inline-block');
	};

	this.playFile = function(url, mime, fileId, fileName, /*optional*/ shareToken) {
		currentFileId = fileId;
		var fallbackTitle = titleFromFilename(fileName);
		playUrl(url, mime, fallbackTitle, function() {
			if (shareToken) {
				loadSharedFileInfo(shareToken, fileId, fallbackTitle);
			} else {
				loadFileInfo(fileId, fallbackTitle);
			}
		});
	};

	this.togglePlayback = togglePlayback;

	this.close = close;

	this.setNextAndPrevEnabled = function(enabled) {
		nextPrevEnabled = enabled;
		updateNextPrevButtonStatus();
	};
}


$(document).ready(function() {
	// Nextcloud 13+ have a built-in Music player in its "individual shared music file" page.
	// Initialize our player only if such player is not found.
	if ($('audio').length === 0) {
		initEmbeddedPlayer();
	}
});

function initEmbeddedPlayer() {

	var currentFile = null;
	var shareToken = $('#sharingToken').val(); // undefined when not on share page

	// function to get download URL for given file name, created later as it
	// has to bind some variables not available here
	var urlForFile = null;

	var player = new EmbeddedPlayer(onClose, onNext, onPrev);
	register();

	var playlist = new Playlist();

	function onClose() {
		currentFile = null;
		playlist.reset();
	}

	function onNext() {
		jumpToPlaylistFile(playlist.next());
	}

	function onPrev() {
		jumpToPlaylistFile(playlist.prev());
	}

	function jumpToPlaylistFile(file) {
		if (!file) {
			player.close();
		} else {
			currentFile = file.id;
			player.playFile(
				urlForFile(file.name),
				file.mimetype,
				currentFile,
				file.name,
				shareToken
			);
		}
	}

	function register() {
		var audioMimes = [
			'audio/flac',
			'audio/mp4',
			'audio/m4b',
			'audio/mpeg',
			'audio/ogg',
			'audio/wav'
		];
		var supportedMimes = _.filter(audioMimes, player.canPlayMIME, player);

		// Add play action to file rows with supported mime type.
		// Protect against cases where this script gets (accidentally) loaded outside of the Files app.
		if (typeof OCA.Files !== 'undefined') {
			registerFolderPlayer(supportedMimes);
		}

		// Add player on single-fle-share page if the MIME is supported
		if ($('#header').hasClass('share-file')) {
			registerFileSharePlayer(supportedMimes);
		}
	}

	/**
	 * "Folder player" is used in the Files app and on shared folders
	 */
	function registerFolderPlayer(supportedMimes) {
		// Handle 'play' action on file row
		var onPlay = function(fileName, context) {
			player.show();

			// Check if playing file changes
			var filerow = context.$file;
			if (currentFile != filerow.attr('data-id')) {
				currentFile = filerow.attr('data-id');

				urlForFile = function(name) {
					var url = context.fileList.getDownloadUrl(name, context.dir);
					// append request token unless this is a public share
					if (!shareToken) {
						var delimiter = _.includes(url, '?') ? '&' : '?';
						url += delimiter + 'requesttoken=' + encodeURIComponent(OC.requestToken);
					}
					return url;
				};

				player.playFile(
					urlForFile(fileName),
					filerow.attr('data-mime'),
					currentFile,
					fileName,
					shareToken
				);

				playlist.init(context.fileList.files, supportedMimes, currentFile);
				player.setNextAndPrevEnabled(playlist.length() > 1);
			}
			else {
				player.togglePlayback();
			}
		};

		var registerPlayerForMime = function(mime) {
			OCA.Files.fileActions.register(
					mime,
					'music-play',
					OC.PERMISSION_READ,
					OC.imagePath('music', 'play-big'),
					onPlay,
					t('music', 'Play')
			);
			OCA.Files.fileActions.setDefault(mime, 'music-play');
		};
		_.forEach(supportedMimes, registerPlayerForMime);
	}

	/**
	 * "File share player" is used on individually shared files
	 */
	function registerFileSharePlayer(supportedMimes) {
		var onClick = function() {
			player.show();
			if (!currentFile) {
				currentFile = 1; // bogus id

				player.playFile(
						$('#downloadURL').val(),
						$('#mimetype').val(),
						0,
						$('#filename').val(),
						shareToken
				);
			}
			else {
				player.togglePlayback();
			}
		};

		// Add click handler to the file preview if this is a supported file.
		// The feature is disabled on old IE versions where there's no MutationObserver and
		// $.initialize would not work.
		if (typeof MutationObserver !== "undefined"
				&& _.contains(supportedMimes, $('#mimetype').val()))
		{
			actionRegisteredForSingleShare = true;

			// The #publicpreview is added dynamically by another script.
			// Augment it with the click handler once it gets added.
			$.initialize('img.publicpreview', function() {
				var previewImg = $(this);
				previewImg.css('cursor', 'pointer');
				previewImg.click(onClick);

				// At least in ownCloud 10 and Nextcloud 11-13, there is such an oversight
				// that if MP3 file has no embedded cover, then the placeholder is not shown
				// either. Fix that on our own.
				previewImg.error(function() {
					previewImg.attr('src', OC.imagePath('core', 'filetypes/audio'));
					previewImg.css('width', '128px');
					previewImg.css('height', '128px');
				});
			});
		}
	}

}

function Playlist() {

	var mFiles = null;
	var mCurrentIndex = null;

	function jumpToOffset(offset) {
		if (!mFiles || mFiles.length <= 1) {
			return null;
		} else {
			mCurrentIndex = (mCurrentIndex + mFiles.length + offset) % mFiles.length;
			return mFiles[mCurrentIndex];
		}
	}

	this.init = function(folderFiles, supportedMimes, firstFileId) {
		mFiles = _.filter(folderFiles, function(file) {
			return _.contains(supportedMimes, file.mimetype);
		});
		mCurrentIndex = _.findIndex(mFiles, function(file) {
			// types int/string depend on the cloud version, don't use ===
			return file.id == firstFileId; 
		});
	};

	this.next = function() {
		return jumpToOffset(+1);
	};

	this.prev = function() {
		return jumpToOffset(-1);
	};

	this.reset = function() {
		mFiles = null;
		mCurrentIndex = null;
	};

	this.length = function() {
		return mFiles ? mFiles.length : 0;
	};

}
(function() {
	/**
	 * This custom renderer handles rendering Music app search results shown within the Files app
	 */
	var Music = function() {
		this.initialize();
	};
	/**
	 * @memberof OCA.Search
	 */
	Music.prototype = {
		initialize: function() {
			OC.Plugins.register('OCA.Search', this); // for ownCloud and NextCloud <= 13
			OC.Plugins.register('OCA.Search.Core', this); // for Nextcloud >= 14
		},
		attach: function(search) {
			search.setRenderer('music_artist', this.renderResult);
			search.setRenderer('music_album', this.renderResult);
			search.setRenderer('music_track', this.renderResult);
		},
		renderResult: function($row, item) {
			$row.find('td.icon')
			.css('background-image', 'url(' + OC.imagePath('music', 'music-dark') + ')')
			.css('opacity', '.4');
			return $row;
		}
	};
	OCA.Search.Music = Music;
	OCA.Search.music = new Music();
})();
function PlayerWrapper() {
	var m_underlyingPlayer = null; // set later as 'aurora' or 'html5'
	var m_html5audio = null;
	var m_aurora = null;
	var m_position = 0;
	var m_duration = 0;
	var m_volume = 100;
	var m_playing = false;
	var m_url = null;
	var m_self = this;

	_.extend(this, OC.Backbone.Events);

	function initHtml5() {
		m_html5audio = document.createElement('audio');

		var getBufferedEnd = function() {
			// The buffer may contain holes after seeking but just ignore those.
			// Show the buffering status according the last buffered position.
			var bufCount = m_html5audio.buffered.length;
			return (bufCount > 0) ? m_html5audio.buffered.end(bufCount-1) : 0;
		};
		var latestNotifiedBufferState = null;

		// Bind the various callbacks
		m_html5audio.ontimeupdate = function() {
			// On Firefox, both the last 'progress' event and the 'suspend' event
			// often fire a tad too early, before the 'buffered' state has been
			// updated to its final value. Hence, check here during playback if the
			// buffering state has changed, and fire an extra event if it has.
			if (latestNotifiedBufferState != getBufferedEnd()) {
				this.onprogress();
			}

			m_position = this.currentTime * 1000;
			m_self.trigger('progress', m_position);
		};

		m_html5audio.ondurationchange = function() {
			m_duration = this.duration * 1000;
			m_self.trigger('duration', m_duration);
		};

		m_html5audio.onprogress = function() {
			var bufEnd = getBufferedEnd();
			m_self.trigger('buffer', bufEnd / this.duration * 100);
			latestNotifiedBufferState = bufEnd;
		};

		m_html5audio.onsuspend = function() {
			this.onprogress();
		};

		m_html5audio.onended = function() {
			m_self.trigger('end');
		};

		m_html5audio.oncanplay = function() {
			m_self.trigger('ready');
		};

		m_html5audio.onerror = function() {
			m_playing = false;
			if (m_url) {
				console.log('HTML5 audio: sound load error');
				m_self.trigger('error', m_url);
			} else {
				// ignore stray errors fired by the HTML audio when the src
				// has been cleared (set to invalid).
			}
		};

		m_html5audio.onplaying = onPlayStarted;

		m_html5audio.onpause = onPaused;
	}
	initHtml5();

	function onPlayStarted() {
		m_playing = true;
		m_self.trigger('play');
	}

	function onPaused() {
		m_playing = false;
		if (m_url !== null) {
			m_self.trigger('pause');
		} else {
			m_self.trigger('stop');
		}
	}

	this.play = function() {
		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.play();
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.play();
					onPlayStarted(); // Aurora has no callback => fire event synchronously
				}
				break;
		}
	};

	this.pause = function() {
		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.pause();
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.pause();
				}
				onPaused(); // Aurora has no callback => fire event synchronously
				break;
		}
	};

	this.stop = function() {
		m_url = null;

		switch (m_underlyingPlayer) {
			case 'html5':
				// Amazingly, there's no 'stop' functionality in the HTML5 audio API, nor is there a way to
				// properly remove the src attribute: setting it to null wold be interpreted as addess
				// "<baseURI>/null" and setting it to empty string will make the src equal the baseURI.
				// Still, resetting the source is necessary to detach the player from the mediaSession API.
				// Just be sure to ignore the resulting 'error' events. Unfortunately, this will still print
				// a warning to the console on Firefox.
				m_html5audio.pause();
				m_html5audio.src = '';
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.stop();
				}
				onPaused(); // Aurora has no callback => fire event synchronously
				break;
		}
	};

	this.isPlaying = function() {
		return m_playing;
	};

	this.seekingSupported = function() {
		// Seeking is not implemented in aurora/flac.js and does not work on all
		// files with aurora/mp3.js. Hence, we disable seeking with aurora.
		return (m_underlyingPlayer == 'html5');
	};

	this.seekMsecs = function(msecs) {
		if (this.seekingSupported()) {
			switch (m_underlyingPlayer) {
				case 'html5':
					m_html5audio.currentTime = msecs / 1000;
					break;
				case 'aurora':
					if (m_aurora) {
						m_aurora.seek(msecs);
					}
					break;
			}
		}
		else {
			console.log('seeking is not supported for this file');
		}
	};

	this.seek = function(ratio) {
		this.seekMsecs(ratio * m_duration);
	};

	this.seekForward = function(msecs /*optional*/) {
		msecs = msecs || 10000;
		this.seekMsecs(m_position + msecs);
	};

	this.seekBackward = function(msecs /*optional*/) {
		msecs = msecs || 10000;
		this.seekMsecs(m_position - msecs);
	};

	this.setVolume = function(percentage) {
		m_volume = percentage;

		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.volume = m_volume/100;
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.volume = m_volume;
				}
				break;
		}
	};

	function canPlayWithHtml5(mime) {
		// The m4b format is almost identical with m4a (but intended for audio books).
		// Still, browsers actually able to play m4b files seem to return false when
		// queuring the support for the mime. Hence, a little hack.
		// The m4a files use MIME type 'audio/mp4' while the m4b use 'audio/m4b'.
		return m_html5audio.canPlayType(mime)
			|| (mime == 'audio/m4b' && m_html5audio.canPlayType('audio/mp4'));
	}

	this.canPlayMIME = function(mime) {
		var canPlayWithAurora = (mime == 'audio/flac' || mime == 'audio/mpeg');
		return canPlayWithHtml5(mime) || canPlayWithAurora;
	};

	this.fromURL = function(url, mime) {
		this.trigger('loading');

		m_url = url;

		if (canPlayWithHtml5(mime)) {
			m_underlyingPlayer = 'html5';
		} else {
			m_underlyingPlayer = 'aurora';
		}
		console.log('Using ' + m_underlyingPlayer + ' for type ' + mime + ' URL ' + url);

		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.pause();
				m_html5audio.src = url;
				break;

			case 'aurora':
				if (m_aurora) {
					m_aurora.stop();
				}

				m_aurora = AV.Player.fromURL(url);
				m_aurora.asset.source.chunkSize=524288;

				m_aurora.on('buffer', function(percent) {
					m_self.trigger('buffer', percent);
				});
				m_aurora.on('progress', function(currentTime) {
					m_position = currentTime;
					m_self.trigger('progress', currentTime);
				});
				m_aurora.on('ready', function() {
					m_self.trigger('ready');
				});
				m_aurora.on('end', function() {
					m_self.trigger('end');
				});
				m_aurora.on('duration', function(msecs) {
					m_duration = msecs;
					m_self.trigger('duration', msecs);
				});

				break;
		}

		// Set the current volume to the newly created/selected player instance
		this.setVolume(m_volume);
	};
}

/** @namespace */
var OC_Music_Utils = {

	/**
	 * Nextcloud 14 has a new overall layout structure which requires some
	 * changes on the application logic.
	 */
	newLayoutStructure: function() {
		// Detect the new structure from the presence of the #content-wrapper element.
		return $('#content-wrapper').length === 0;
	},

	/**
	 * Newer versions of Nextcloud come with a "dark theme" which may be activated
	 * from the accessibility settings. Test if the theme is active.
	 */
	darkThemeActive: function() {
		// The name of the theme was originally 'themedark' but changed to simply 'dark' in NC18.
		return OCA.hasOwnProperty('Accessibility')
			&& (OCA.Accessibility.theme == 'themedark' || OCA.Accessibility.theme == 'dark');
	},

	/**
	 * Test if the string @a str starts with another string @a search
	 */
	startsWith: function(str, search) {
		return str !== null && search !== null && str.slice(0, search.length) === search;
	},

	/**
	 * Test if the string @a str ends with another string @a search
	 */
	endsWith: function(str, search) {
		return str !== null && search !== null && str.slice(-search.length) === search;
	}

};