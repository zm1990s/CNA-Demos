
angular.module('Music', ['restangular', 'duScroll', 'gettext', 'ngRoute', 'ngSanitize', 'ang-drag-drop'])
	.config(['RestangularProvider', '$routeProvider', '$locationProvider', '$compileProvider',
		function (RestangularProvider, $routeProvider, $locationProvider, $compileProvider) {

			// disable debug info for performance gains
			$compileProvider.debugInfoEnabled(false);

			// configure RESTAngular path
			RestangularProvider.setBaseUrl(OC.generateUrl('apps/music/api'));

			var albumsControllerConfig = {
				controller:'AlbumsViewController',
				templateUrl:'albumsview.html'
			};

			var playlistControllerConfig = {
				controller:'PlaylistViewController',
				templateUrl:'playlistview.html'
			};

			var allTracksControllerConfig = {
				controller:'AllTracksViewController',
				templateUrl:'alltracksview.html'
			};

			var foldersControllerConfig = {
				controller:'FoldersViewController',
				templateUrl:'foldersview.html'
			};

			var genresControllerConfig = {
				controller:'GenresViewController',
				templateUrl:'genresview.html'
			};

			var settingsControllerConfig = {
				controller:'SettingsViewController',
				templateUrl:'settingsview.html'
			};

			/**
			 * @see https://stackoverflow.com/questions/38455077/angular-force-an-undesired-exclamation-mark-in-url/41223197#41223197
			 */
			$locationProvider.hashPrefix('');

			$routeProvider
				.when('/',                     albumsControllerConfig)
				.when('/artist/:id',           albumsControllerConfig)
				.when('/album/:id',            albumsControllerConfig)
				.when('/track/:id',            albumsControllerConfig)
				.when('/file/:id',             albumsControllerConfig)
				.when('/playlist/:playlistId', playlistControllerConfig)
				.when('/alltracks',            allTracksControllerConfig)
				.when('/folders',              foldersControllerConfig)
				.when('/genres',               genresControllerConfig)
				.when('/settings',             settingsControllerConfig);
		}
	])
	.run(['Token', 'Restangular',
		function(Token, Restangular) {
			// add CSRF token
			Restangular.setDefaultHeaders({requesttoken: Token});
		}
	]);

angular.module('Music').controller('AlbumsViewController', [
	'$scope', '$rootScope', 'playlistService', 'libraryService',
	'Restangular', '$route', '$timeout', 'gettextCatalog',
	function ($scope, $rootScope, playlistService, libraryService,
			Restangular, $route, $timeout, gettextCatalog) {

		$rootScope.currentView = '#';

		// When making the view visible, the artists are added incrementally step-by-step.
		// The purpose of this is to keep the browser responsive even in case the view contains
		// an enormous amount of albums (like several thousands).
		var INCREMENTAL_LOAD_STEP = 20;
		$scope.incrementalLoadLimit = 0;

		// $rootScope listeneres must be unsubscribed manually when the control is destroyed
		var unsubFuncs = [];

		function subscribe(event, handler) {
			unsubFuncs.push( $rootScope.$on(event, handler) );
		}

		$scope.$on('$destroy', function () {
			_.each(unsubFuncs, function(func) { func(); });
		});

		// Prevent controller reload when the URL is updated with window.location.hash,
		// unless the new location actually requires another controller.
		// See http://stackoverflow.com/a/12429133/2104976
		var lastRoute = $route.current;
		$scope.$on('$locationChangeSuccess', function(event) {
			if (lastRoute.$$route.controller === $route.current.$$route.controller) {
				$route.current = lastRoute;
			}
		});

		// Wrap the supplied tracks as a playlist and pass it to the service for playing
		function playTracks(listId, tracks, startIndex /*optional*/) {
			var playlist = _.map(tracks, function(track) {
				return { track: track };
			});
			playlistService.setPlaylist(listId, playlist, startIndex);
			playlistService.publish('play');
		}

		function playPlaylistFromTrack(listId, playlist, track) {
			// update URL hash
			window.location.hash = '#/track/' + track.id;

			var index = _.findIndex(playlist, function(i) {return i.track.id == track.id;});
			playlistService.setPlaylist(listId, playlist, index);
			playlistService.publish('play');
		}

		$scope.playTrack = function(trackId) {
			var track = libraryService.getTrack(trackId);
			var currentTrack = $scope.$parent.currentTrack;

			// play/pause if currently playing track clicked
			if (currentTrack && track.id === currentTrack.id) {
				playlistService.publish('togglePlayback');
			}
			else {
				var currentListId = playlistService.getCurrentPlaylistId();

				// start playing the album/artist from this track if the clicked track belongs
				// to album/artist which is the current play scope
				if (currentListId === 'album-' + track.album.id || currentListId === 'artist-' + track.album.artist.id) {
					playPlaylistFromTrack(currentListId, playlistService.getCurrentPlaylist(), track);
				}
				// on any other track, start playing the collection from this track
				else {
					playPlaylistFromTrack('albums', libraryService.getTracksInAlbumOrder(), track);
				}
			}
		};

		$scope.playAlbum = function(album) {
			// update URL hash
			window.location.hash = '#/album/' + album.id;
			playTracks('album-' + album.id, album.tracks);
		};

		$scope.playArtist = function(artist) {
			// update URL hash
			window.location.hash = '#/artist/' + artist.id;
			var tracks = _.flatten(_.pluck(artist.albums, 'tracks'));
			playTracks('artist-' + artist.id, tracks);
		};

		$scope.playFile = function (fileid) {
			if (fileid) {
				Restangular.one('file', fileid).get().then(function(result) {
					$scope.playTrack(result.id);
					scrollToAlbumOfTrack(result.id);
				});
			}
		};

		/**
		 * Two functions for the alphabet-navigation directive integration
		 */
		$scope.getArtistName = function(index) {
			return $scope.artists[index].name;
		};
		$scope.getArtistElementId = function(index) {
			return 'artist-' + $scope.artists[index].id;
		};

		function getDraggable(type, draggedElement) {
			var draggable = {};
			draggable[type] = draggedElement.id;
			return draggable;
		}

		$scope.getTrackDraggable = function(trackId) {
			return getDraggable('track', libraryService.getTrack(trackId));
		};

		$scope.getAlbumDraggable = function(album) {
			return getDraggable('album', album);
		};

		$scope.getArtistDraggable = function(album) {
			return getDraggable('artist', album);
		};

		$scope.decoratedYear = function(album) {
			return album.year ? ' (' + album.year + ')' : '';
		};

		/**
		 * Gets track data to be dislayed in the tracklist directive
		 */
		$scope.getTrackData = function(track, index, scope) {
			return {
				title: getTitleString(track, scope.artist, false),
				tooltip: getTitleString(track, scope.artist, true),
				number: getTrackNumber(track),
				id: track.id
			};
		};

		/**
		 * Formats a track title string for displaying in tracklist directive
		 */
		function getTitleString(track, artist, plaintext) {
			var att = track.title;
			if (track.artistId !== artist.id) {
				var artistName = ' (' + track.artistName + ') ';
				if (!plaintext) {
					artistName = ' <span class="muted">' + artistName + '</span>';
				}
				att += artistName;
			}
			return att;
		}

		/**
		 * Formats a track number, possible including disk number, for displaying in tracklist directive
		 */
		function getTrackNumber(track) {
			if (track.album.diskCount <= 1) {
				return track.number;
			} else {
				// multidisk album
				var number = track.disk + '-';
				number += (track.number !== null) ? track.number : '?';
				return number;
			}
		}

		// emited on end of playlist by playerController
		subscribe('playlistEnded', function() {
			window.location.hash = '#/';
			updateHighlight(null);
		});

		subscribe('playlistChanged', function(e, playlistId) {
			updateHighlight(playlistId);
		});

		subscribe('scrollToTrack', function(event, trackId, animationTime /* optional */) {
			scrollToAlbumOfTrack(trackId, animationTime);
		});

		function scrollToAlbumOfTrack(trackId, animationTime /* optional */) {
			var track = libraryService.getTrack(trackId);
			if (track) {
				$scope.$parent.scrollToItem('album-' + track.album.id, animationTime);
			}
		}

		function isPlaying() {
			return $rootScope.playingView !== null;
		}

		function updateHighlight(playlistId) {
			// remove any previous highlight
			$('.highlight').removeClass('highlight');

			// add highlighting if album or artist is being played
			if (OC_Music_Utils.startsWith(playlistId, 'album-')
					|| OC_Music_Utils.startsWith(playlistId, 'artist-')) {
				$('#' + playlistId).addClass('highlight');
			}
		}

		function initializePlayerStateFromURL() {
			var hashParts = window.location.hash.substr(1).split('/');
			if (!hashParts[0] && hashParts[1] && hashParts[2]) {
				var type = hashParts[1];
				var id = hashParts[2];

				try {
					if (type == 'file') {
						$scope.playFile(id);
					} else if (type == 'artist') {
						var artist = libraryService.getArtist(id);
						if (artist) {
							$scope.playArtist(artist);
							$scope.$parent.scrollToItem('artist-' + id);
						} else {
							// If there is no such album artist, then maybe this is only a track artist.
							// Try to find the first track by this artist.
							var tracks = libraryService.findTracksByArtist(id);
							$scope.playTrack(tracks[0].id);
							scrollToAlbumOfTrack(tracks[0].id);
						}
					} else if (type == 'album') {
						$scope.playAlbum(libraryService.getAlbum(id));
						$scope.$parent.scrollToItem('album-' + id);
					} else if (type == 'track') {
						$scope.playTrack(id);
						scrollToAlbumOfTrack(id);
					}
				}
				catch (exception) {
					OC.Notification.showTemporary(gettextCatalog.getString('Requested entry was not found'));
					window.location.hash = '#/';
				}
			}

			updateHighlight(playlistService.getCurrentPlaylistId());
		}

		/**
		 * Increase number of shown artists aynchronously step-by-step until
		 * they are all visible. This is to avoid script hanging up for too
		 * long on huge collections.
		 */
		function showMore() {
			// show more entries only if the view is not already (being) deactivated
			if ($rootScope.currentView && $scope.$parent) {
				$scope.incrementalLoadLimit += INCREMENTAL_LOAD_STEP;
				if ($scope.incrementalLoadLimit < $scope.$parent.artists.length) {
					$timeout(showMore);
				} else {
					$rootScope.loading = false;

					// Do not reinitialize the player state if it is already playing.
					// This is the case when the user has started playing music while scanning is ongoing,
					// and then hits the 'update' button. Reinitializing would stop and restart the playback.
					if (!isPlaying()) {
						$timeout(initializePlayerStateFromURL);
					} else {
						updateHighlight(playlistService.getCurrentPlaylistId());
					}
				}
			}
		}

		// Start making artists visible immediatedly if the artists are already loaded.
		// Otherwise it happens on the 'artistsLoaded' event handler.
		if ($scope.$parent.artists) {
			showMore();
		}

		subscribe('artistsLoaded', function() {
			// Start the anynchronus process of making aritsts visible
			$scope.incrementalLoadLimit = 0;
			showMore();
		});

		subscribe('deactivateView', function() {
			$timeout(function() {
				$rootScope.$emit('viewDeactivated');
			});
		});
	}
]);

angular.module('Music').controller('AllTracksViewController', [
	'$rootScope', '$scope', 'playlistService', 'libraryService', 'alphabetIndexingService', '$timeout',
	function ($rootScope, $scope, playlistService, libraryService, alphabetIndexingService, $timeout) {

		$rootScope.currentView = window.location.hash;

		var _tracks = null;
		var _indexChars = alphabetIndexingService.indexChars();

		// Tracks are split into "buckets" to facilitate lazy loading. One track-list directive
		// is created for each bucket. All tracks in a single bucket have the same indexing char
		// but a single indexing char may have several buckets.
		var BUCKET_MAX_SIZE = 100;
		$scope.trackBuckets = null;

		// $rootScope listeneres must be unsubscribed manually when the control is destroyed
		var _unsubFuncs = [];

		function subscribe(event, handler) {
			_unsubFuncs.push( $rootScope.$on(event, handler) );
		}

		$scope.$on('$destroy', function () {
			_.each(_unsubFuncs, function(func) { func(); });
		});

		function play(startIndex /*optional*/) {
			playlistService.setPlaylist('alltracks', _tracks, startIndex);
			playlistService.publish('play');
		}

		// Call playlistService to play all songs in the current playlist from the beginning
		$scope.onHeaderClick = function() {
			play();
		};

		// Play the list, starting from a specific track
		$scope.onTrackClick = function(trackId) {
			// play/pause if currently playing list item clicked
			if ($scope.$parent.currentTrack && $scope.$parent.currentTrack.id === trackId) {
				playlistService.publish('togglePlayback');
			}
			// on any other list item, start playing the list from this item
			else {
				var index = _.findIndex(_tracks, function(i) {return i.track.id == trackId;});
				play(index);
			}
		};

		/**
		 * Gets track data to be dislayed in the tracklist directive
		 */
		$scope.getTrackData = function(listItem, index, scope) {
			var track = listItem.track;
			return {
				title: track.artistName + ' - ' + track.title,
				tooltip: '',
				number: scope.$parent.bucket.baseIndex + index + 1,
				id: track.id
			};
		};

		/**
		 * Two functions for the alphabet-navigation directive integration
		 */
		$scope.getBucketName = function(index) {
			return $scope.trackBuckets[index].name;
		};
		$scope.getBucketElementId = function(index) {
			return 'track-bucket-' + index;
		};

		$scope.getDraggable = function(trackId) {
			return { track: trackId };
		};

		function findTrackFromBucket(bucket, trackId) {
			return _(bucket.tracks).find(function(item) {
				return item.track.id == trackId;
			});
		}

		function bucketElementForTrack(trackId) {
			var track = libraryService.getTrack(trackId);
			if (track) {
				return document.getElementById('track-bucket-' + track.bucket.id);
			} else {
				return null;
			}
		}

		subscribe('scrollToTrack', function(event, trackId) {
			if ($scope.$parent) {
				$rootScope.$emit('inViewObserver_revealElement', bucketElementForTrack(trackId));
				$scope.$parent.scrollToItem('track-' + trackId);
			}
		});

		// Init happens either immediately (after making the loading animation visible)
		// or once artists have been loaded
		$timeout(initView);

		subscribe('artistsLoaded', function () {
			// Nullify any previous tracks to force tracklist directive recreation
			_tracks = null;
			$scope.trackBuckets = null;
			$timeout(initView);
		});

		function initView() {
			if (libraryService.collectionLoaded()) {
				_tracks = libraryService.getTracksInAlphaOrder();
				$scope.trackBuckets = createTrackBuckets();
				$timeout(function() {
					$rootScope.loading = false;
				});
			}
		}

		function trackAtIndexPreceedsIndexCharAt(trackIdx, charIdx) {
			var name = _tracks[trackIdx].track.artistName;
			return (charIdx >= _indexChars.length
				|| alphabetIndexingService.titlePrecedesIndexCharAt(name, charIdx));
		}

		function createTrackBuckets() {
			var buckets = [];

			for (var charIdx = 0, trackIdx = 0;
				charIdx < _indexChars.length && trackIdx < _tracks.length;
				++charIdx)
			{
				if (trackAtIndexPreceedsIndexCharAt(trackIdx, charIdx + 1)) {
					// Track at trackIdx belongs to bucket of the char _indexChars[charIdx]

					var bucket = null;
	
					// Add all the items belonging to the same alphabet to the same bucket
					do {
						// create a new bucket when necessary
						if (!bucket || bucket.tracks.length >= BUCKET_MAX_SIZE) {
							bucket = {
								id: buckets.length,
								char: _indexChars[charIdx],
								firstForChar: !bucket,
								name: _tracks[trackIdx].track.artistName,
								tracks: [],
								baseIndex: trackIdx
							};
							buckets.push(bucket);
						}

						_tracks[trackIdx].track.bucket = bucket;
						bucket.tracks.push(_tracks[trackIdx]);
						++trackIdx;
					}
					while (trackIdx < _tracks.length
							&& trackAtIndexPreceedsIndexCharAt(trackIdx, charIdx + 1));
				}
			}

			return buckets;
		}

		subscribe('deactivateView', function() {
			// The small delay may help in bringing up the load indicator a bit faster
			// on huge collections (tens of thousands of tracks)
			$timeout(function() {
				$rootScope.$emit('viewDeactivated');
			}, 100);
		});

	}
]);

angular.module('Music').controller('ArtistDetailsController', [
	'$rootScope', '$scope', 'Restangular', 'gettextCatalog', 'libraryService',
	function ($rootScope, $scope, Restangular, gettextCatalog, libraryService) {

		function resetContents() {
			$scope.artist = null;
			$scope.artistAlbumTrackCount = 0;
			$scope.artistTrackCount = 0;
			$scope.loading = true;
			$scope.artAvailable = false;
			$scope.lastfmInfo = null;
			$scope.artistBio = null;
			$scope.artistTags = null;
			$scope.similarArtists = null;
		}
		resetContents();

		function showDetails(artistId) {
			if (!$scope.artist || artistId != $scope.artist.id) {
				resetContents();

				$scope.artist = libraryService.getArtist(artistId);
				$scope.artistAlbumTrackCount = _.chain($scope.artist.albums).pluck('tracks').flatten().value().length;
				$scope.artistTrackCount = libraryService.findTracksByArtist(artistId).length;

				var art = $('#app-sidebar .albumart');
				art.css('background-image', '');

				Restangular.one('artist', artistId).one('cover').get().then(
					function(result) {
						$scope.artAvailable = true;
						$scope.loading = false;

						var url = OC.generateUrl('apps/music/api/artist/') + artistId + '/cover?originalSize=true';
						art.css('background-image', 'url("' + url + '")');
					},
					function(result) {
						// error handling
						$scope.artAvailable = false;
						$scope.loading = false;
						$scope.noImageHint = gettextCatalog.getString(
							'Upload image named "{{name}}" to anywhere within your library path to see it here.',
							{ name: $scope.artist.name + '.*' }
						);
					}
				);

				Restangular.one('artist', artistId).one('details').get().then(
					function(result) {
						$scope.lastfmInfo = result;
						$scope.artistBio = result.artist.bio.content || result.artist.bio.summary;
						// modify all links in the biography so that they will open to a new tab
						$scope.artistBio = $scope.artistBio.replace(/<a href=/g, '<a target="_blank" href=');

						$scope.artistTags = formatTags(result.artist.tags.tag);
						$scope.similarArtists = formatLinkList(result.artist.similar.artist);
					}
				);
			}
		}

		function formatTags(tags) {
			// Filter out the tag "seen live" because it is intended to be used on Last.fm for the feature
			// which allows filtering based on the tags set by the user herself. As a global tag, it makes
			// no sense because almost all artists have been seen live by someone.
			tags = _.reject(tags, {name: 'seen live'});
			return formatLinkList(tags);
		}

		function formatLinkList(linkArray) {
			htmlLinks = _.map(linkArray, function(item) {
				return '<a href="' + item.url + '" target="_blank">' + item.name + '</a>';
			});
			return htmlLinks.join(', ');
		}

		$scope.$watch('contentId', showDetails);
	}
]);

angular.module('Music').controller('FoldersViewController', [
	'$rootScope', '$scope', 'playlistService', 'libraryService', '$timeout',
	function ($rootScope, $scope, playlistService, libraryService, $timeout) {

		$scope.folders = null;
		$rootScope.currentView = window.location.hash;

		// When making the view visible, the folders are added incrementally step-by-step.
		// The purpose of this is to keep the browser responsive even in case the view contains
		// an enormous amount of folders (like several thousands).
		var INCREMENTAL_LOAD_STEP = 100;
		$scope.incrementalLoadLimit = 0;

		// $rootScope listeneres must be unsubscribed manually when the control is destroyed
		var unsubFuncs = [];

		function subscribe(event, handler) {
			unsubFuncs.push( $rootScope.$on(event, handler) );
		}

		function playPlaylist(listId, tracks, startFromTrackId /*optional*/) {
			var startIndex = null;
			if (startFromTrackId !== undefined) {
				startIndex = _.findIndex(tracks, function(i) {return i.track.id == startFromTrackId;});
			}
			playlistService.setPlaylist(listId, tracks, startIndex);
			playlistService.publish('play');
		}

		$scope.onFolderTitleClick = function(folder) {
			playPlaylist('folder-' + folder.id, folder.tracks);
		};

		$scope.onTrackClick = function(trackId) {
			// play/pause if currently playing folder item clicked
			if ($scope.$parent.currentTrack && $scope.$parent.currentTrack.id === trackId) {
				playlistService.publish('togglePlayback');
			}
			// on any other list item, start playing the folder from this item
			else {
				var currentListId = playlistService.getCurrentPlaylistId();
				var folder = libraryService.getTrack(trackId).folder;

				// start playing the folder from this track if the clicked track belongs
				// to folder which is the current play scope
				if (currentListId === 'folder-' + folder.id) {
					playPlaylist(currentListId, folder.tracks, trackId);
				}
				// on any other track, start playing the collection from this track
				else {
					playPlaylist('folders', libraryService.getTracksInFolderOrder(), trackId);
				}
			}
		};

		function updateHighlight(playlistId) {
			// remove any previous highlight
			$('.highlight').removeClass('highlight');

			// add highlighting if an individual folder is being played
			if (OC_Music_Utils.startsWith(playlistId, 'folder-')) {
				$('#' + playlistId).addClass('highlight');
			}
		}

		/**
		 * Gets track data to be dislayed in the tracklist directive
		 */
		$scope.getTrackData = function(listItem, index, scope) {
			var track = listItem.track;
			return {
				title: track.artistName + ' - ' + track.title,
				tooltip: '',
				number: index + 1,
				id: track.id
			};
		};

		function getDraggable(type, draggedElementId) {
			var draggable = {};
			draggable[type] = draggedElementId;
			return draggable;
		}

		$scope.getTrackDraggable = function(trackId) {
			return getDraggable('track', trackId);
		};

		$scope.getFolderDraggable = function(folder) {
			return getDraggable('folder', folder.id);
		};

		/**
		 * Two functions for the alphabet-navigation directive integration
		 */
		$scope.getFolderName = function(index) {
			return $scope.folders[index].name;
		};
		$scope.getFolderElementId = function(index) {
			return 'folder-' + $scope.folders[index].id;
		};

		subscribe('playlistEnded', function() {
			updateHighlight(null);
		});

		subscribe('playlistChanged', function(e, playlistId) {
			updateHighlight(playlistId);
		});

		subscribe('scrollToTrack', function(event, trackId) {
			if ($scope.$parent) {
				var elementId = 'track-' + trackId;
				// If the track element is hidden (collapsed), scroll to the folder
				// element instead
				var trackElem = $('#' + elementId);
				if (trackElem.length === 0 || !trackElem.is(':visible')) {
					var folder = libraryService.getTrack(trackId).folder; 
					elementId = 'folder-' + folder.id;
				}
				$scope.$parent.scrollToItem(elementId);
			}
		});

		$scope.$on('$destroy', function () {
			_.each(unsubFuncs, function(func) { func(); });
		});

		// Init happens either immediately (after making the loading animation visible)
		// or once collection has been loaded
		if (libraryService.collectionLoaded()) {
			$timeout(initView);
		}

		subscribe('artistsLoaded', function () {
			$timeout(initView);
		});

		function initView() {
			$scope.incrementalLoadLimit = 0;
			if ($scope.$parent) {
				$scope.$parent.loadFoldersAndThen(function() {
					$scope.folders = libraryService.getAllFolders();
					$timeout(showMore);
				});
			}
		}

		/**
		 * Increase number of shown folders aynchronously step-by-step until
		 * they are all visible. This is to avoid script hanging up for too
		 * long on huge collections.
		 */
		function showMore() {
			// show more entries only if the view is not already (being) deactivated
			if ($rootScope.currentView && $scope.$parent) {
				$scope.incrementalLoadLimit += INCREMENTAL_LOAD_STEP;
				if ($scope.incrementalLoadLimit < $scope.folders.length) {
					$timeout(showMore);
				} else {
					$rootScope.loading = false;
					updateHighlight(playlistService.getCurrentPlaylistId());
				}
			}
		}

		subscribe('deactivateView', function() {
			$timeout(function() {
				$rootScope.$emit('viewDeactivated');
			});
		});
	}
]);

angular.module('Music').controller('GenresViewController', [
	'$rootScope', '$scope', 'playlistService', 'libraryService', '$timeout',
	function ($rootScope, $scope, playlistService, libraryService, $timeout) {

		$scope.genres = null;
		$rootScope.currentView = window.location.hash;

		// When making the view visible, the genres are added incrementally step-by-step.
		// The purpose of this is to keep the browser responsive even in case the view contains
		// an enormous amount of genres (like several thousands).
		var INCREMENTAL_LOAD_STEP = 100;
		$scope.incrementalLoadLimit = 0;

		// $rootScope listeneres must be unsubscribed manually when the control is destroyed
		var unsubFuncs = [];

		function subscribe(event, handler) {
			unsubFuncs.push( $rootScope.$on(event, handler) );
		}

		$scope.startScanning = function() {
			$scope.$parent.startScanning($scope.$parent.filesWithUnscannedGenre);
			$scope.$parent.filesWithUnscannedGenre = null;
		};

		function playPlaylist(listId, tracks, startFromTrackId /*optional*/) {
			var startIndex = null;
			if (startFromTrackId !== undefined) {
				startIndex = _.findIndex(tracks, function(i) {return i.track.id == startFromTrackId;});
			}
			playlistService.setPlaylist(listId, tracks, startIndex);
			playlistService.publish('play');
		}

		$scope.onGenreTitleClick = function(genre) {
			playPlaylist('genre-' + genre.id, genre.tracks);
		};

		$scope.onTrackClick = function(trackId) {
			// play/pause if currently playing item clicked
			if ($scope.$parent.currentTrack && $scope.$parent.currentTrack.id === trackId) {
				playlistService.publish('togglePlayback');
			}
			// on any other list item, start playing the genre or whole library from this item
			else {
				var currentListId = playlistService.getCurrentPlaylistId();
				var genre = libraryService.getTrack(trackId).genre;

				// start playing the genre from this track if the clicked track belongs
				// to genre which is the current play scope
				if (currentListId === 'genre-' + genre.id) {
					playPlaylist(currentListId, genre.tracks, trackId);
				}
				// on any other track, start playing the collection from this track
				else {
					playPlaylist('genres', libraryService.getTracksInGenreOrder(), trackId);
				}
			}
		};

		function updateHighlight(playlistId) {
			// remove any previous highlight
			$('.highlight').removeClass('highlight');

			// add highlighting if an individual genre is being played
			if (OC_Music_Utils.startsWith(playlistId, 'genre-')) {
				$('#' + playlistId).addClass('highlight');
			}
		}

		/**
		 * Gets track data to be dislayed in the tracklist directive
		 */
		$scope.getTrackData = function(listItem, index, scope) {
			var track = listItem.track;
			return {
				title: track.artistName + ' - ' + track.title,
				tooltip: '',
				number: index + 1,
				id: track.id
			};
		};

		function getDraggable(type, draggedElementId) {
			var draggable = {};
			draggable[type] = draggedElementId;
			return draggable;
		}

		$scope.getTrackDraggable = function(trackId) {
			return getDraggable('track', trackId);
		};

		$scope.getGenreDraggable = function(genre) {
			return getDraggable('genre', genre.id);
		};

		/**
		 * Two functions for the alphabet-navigation directive integration
		 */
		$scope.getGenreName = function(index) {
			// Substitute the empty string used on unknown genre with a character from
			// the private use area. This should sort after alphabet regardless of the
			// locale settings.
			return $scope.genres[index].name || '';
		};
		$scope.getGenreElementId = function(index) {
			return 'genre-' + $scope.genres[index].id;
		};

		subscribe('playlistEnded', function() {
			updateHighlight(null);
		});

		subscribe('playlistChanged', function(e, playlistId) {
			updateHighlight(playlistId);
		});

		subscribe('scrollToTrack', function(event, trackId) {
			if ($scope.$parent) {
				var elementId = 'track-' + trackId;
				// If the track element is hidden (collapsed), scroll to the genre
				// element instead
				var trackElem = $('#' + elementId);
				if (trackElem.length === 0 || !trackElem.is(':visible')) {
					var genre = libraryService.getTrack(trackId).genre; 
					elementId = 'genre-' + genre.id;
				}
				$scope.$parent.scrollToItem(elementId);
			}
		});

		$scope.$on('$destroy', function () {
			_.each(unsubFuncs, function(func) { func(); });
		});

		// Init happens either immediately (after making the loading animation visible)
		// or once collection has been loaded
		if (libraryService.genresLoaded()) {
			$timeout(initView);
		}

		subscribe('genresLoaded', function () {
			$timeout(initView);
		});

		function initView() {
			$scope.incrementalLoadLimit = 0;
			$scope.genres = libraryService.getAllGenres();
			$timeout(showMore);

			// The "rescan needed" banner uses "collapsed" layout if there are any genres already available
			var rescanPopup = $('#toRescan');
			if ($scope.genres.length > 0) {
				rescanPopup.addClass('collapsed');
			} else {
				rescanPopup.removeClass('collapsed');
			}
		}

		/**
		 * Increase number of shown genres aynchronously step-by-step until
		 * they are all visible. This is to avoid script hanging up for too
		 * long on huge collections.
		 */
		function showMore() {
			// show more entries only if the view is not already (being) deactivated
			if ($rootScope.currentView && $scope.$parent) {
				$scope.incrementalLoadLimit += INCREMENTAL_LOAD_STEP;
				if ($scope.incrementalLoadLimit < $scope.genres.length) {
					$timeout(showMore);
				} else {
					$rootScope.loading = false;
					updateHighlight(playlistService.getCurrentPlaylistId());
				}
			}
		}

		subscribe('deactivateView', function() {
			$timeout(function() {
				$rootScope.$emit('viewDeactivated');
			});
		});
	}
]);

angular.module('Music').controller('MainController', [
'$rootScope', '$scope', '$timeout', '$window', '$document', 'ArtistFactory', 
'playlistService', 'libraryService', 'inViewService', 'gettextCatalog', 'Restangular',
function ($rootScope, $scope, $timeout, $window, $document, ArtistFactory, 
		playlistService, libraryService, inViewService, gettextCatalog, Restangular) {

	// retrieve language from backend - is set in ng-app HTML element
	gettextCatalog.currentLanguage = $rootScope.lang;

	// Add dark-theme class to the #app element if Nextcloud dark theme detected.
	// Css can then diffentiate the style of the contained elments where necessary.
	if (OC_Music_Utils.darkThemeActive()) {
		$('#app').addClass('dark-theme');
	}

	$rootScope.playing = false;
	$rootScope.playingView = null;
	$scope.currentTrack = null;
	playlistService.subscribe('trackChanged', function(e, listEntry){
		$scope.currentTrack = listEntry.track;
		$scope.currentTrackIndex = playlistService.getCurrentIndex();
	});

	playlistService.subscribe('play', function(e, playingView) {
		// assume that the play started from current view if no other view given
		$rootScope.playingView = playingView || $rootScope.currentView;
	});

	playlistService.subscribe('playlistEnded', function() {
		$rootScope.playingView = null;
		$scope.currentTrack = null;
		$scope.currentTrackIndex = -1;
	});

	$scope.trackCountText = function(playlist) {
		var trackCount = playlist ? playlist.tracks.length : libraryService.getTrackCount();
		return gettextCatalog.getPlural(trackCount, '1 track', '{{ count }} tracks', { count: trackCount });
	};

	$scope.albumCountText = function() {
		var albumCount = libraryService.getAlbumCount();
		return gettextCatalog.getPlural(albumCount, '1 album', '{{ count }} albums', { count: albumCount });
	};

	$scope.folderCountText = function() {
		if (libraryService.foldersLoaded()) {
			var folderCount = libraryService.getAllFolders().length;
			return gettextCatalog.getPlural(folderCount, '1 folder', '{{ count }} folders', { count: folderCount });
		} else {
			return '';
		}
	};

	$scope.genresCountText = function() {
		if (libraryService.genresLoaded()) {
			var genreCount = libraryService.getAllGenres().length;
			return gettextCatalog.getPlural(genreCount, '1 genre', '{{ count }} genres', { count: genreCount });
		} else {
			return '';
		}
	};

	$scope.loadIndicatorVisible = function() {
		var contentNotReady = ($rootScope.loadingCollection || $rootScope.searchInProgress);
		return $rootScope.loading
			|| (contentNotReady && $rootScope.currentView != '#/settings');
	};

	$scope.update = function() {
		$scope.updateAvailable = false;
		$rootScope.loadingCollection = true;

		$scope.artists = null; // the null-value tells the views that data is not yet available
		$rootScope.$emit('artistsUpdating');

		// load the music collection
		ArtistFactory.getArtists().then(function(artists) {
			libraryService.setCollection(artists);
			libraryService.setFolders(null); // invalidate any out-dated folders
			$scope.artists = libraryService.getAllArtists();

			// Emit the event asynchronously so that the DOM tree has already been
			// manipulated and rendered by the browser when obeservers get the event.
			$timeout(function() {
				$rootScope.$emit('artistsLoaded');
			});

			// Load playlists once the collection has been loaded
			Restangular.all('playlists').getList().then(function(playlists) {
				libraryService.setPlaylists(playlists);
				$scope.playlists = libraryService.getAllPlaylists();
				$rootScope.$emit('playlistsLoaded');
			});

			// Load also genres once the collection has been loaded
			Restangular.one('genres').get().then(function(genres) {
				libraryService.setGenres(genres.genres);
				$scope.filesWithUnscannedGenre = genres.unscanned;
				$rootScope.$emit('genresLoaded');
			});

			// The "no content"/"click to scan"/"scanning" banner uses "collapsed" layout
			// if there are any tracks already visible
			var collapsiblePopups = $('#app-content .emptycontent:not(#noSearchResults):not(#toRescan)');
			if (libraryService.getTrackCount() > 0) {
				collapsiblePopups.addClass('collapsed');
			} else {
				collapsiblePopups.removeClass('collapsed');
			}

			$rootScope.loadingCollection = false;

			// check the availability of unscanned files after the collection has been loaded,
			// unless we are already in the middle of scanning (and intermediate results were just loaded)
			if (!$scope.scanning) {
				$scope.updateFilesToScan();
			}
		},
		function(response) { // error handling
			$rootScope.loadingCollection = false;

			var reason = null;
			switch (response.status) {
			case 500:
				reason = gettextCatalog.getString('Internal server error');
				break;
			case 504:
				reason = gettextCatalog.getString('Timeout');
				break;
			default:
				reason = response.status;
				break;
			}
			OC.Notification.showTemporary(
					gettextCatalog.getString('Failed to load the collection: ') + reason);
		});

	};

	// initial loading of artists
	$scope.update();

	var FILES_TO_SCAN_PER_STEP = 10;
	var filesToScan = null;
	var filesToScanIterator = 0;
	var previouslyScannedCount = 0;

	$scope.updateFilesToScan = function() {
		Restangular.one('scanstate').get().then(function(state) {
			previouslyScannedCount = state.scannedCount;
			filesToScan = state.unscannedFiles;
			filesToScanIterator = 0;
			$scope.toScan = (filesToScan.length > 0);
			$scope.scanningScanned = previouslyScannedCount;
			$scope.scanningTotal = previouslyScannedCount + filesToScan.length;
			$scope.noMusicAvailable = ($scope.scanningTotal === 0);
		});
	};

	function processNextScanStep() {
		var sliceEnd = filesToScanIterator + FILES_TO_SCAN_PER_STEP;
		var filesForStep = filesToScan.slice(filesToScanIterator, sliceEnd);
		var params = {
				files: filesForStep.join(','),
				finalize: sliceEnd >= filesToScan.length
		};
		Restangular.all('scan').post(params).then(function(result) {
			// Ignore the results if scanning has been cancelled while we
			// were waiting for the result.
			if ($scope.scanning) {
				filesToScanIterator = sliceEnd;

				if (result.filesScanned || result.coversUpdated) {
					$scope.updateAvailable = true;
				}

				$scope.scanningScanned = previouslyScannedCount + filesToScanIterator;

				if (filesToScanIterator < filesToScan.length) {
					processNextScanStep();
				} else {
					$scope.scanning = false;
				}

				// Update the newly scanned tracks to UI automatically when
				// a) the first batch is ready
				// b) the scanning process is completed.
				// Otherwise the UI state is updated only when the user hits the 'update' button
				if ($scope.updateAvailable && $scope.artists && ($scope.artists.length === 0 || !$scope.scanning)) {
					$scope.update();
				}
			}
		});
	}

	$scope.startScanning = function(fileIds /*optional*/) {
		if (fileIds) {
			filesToScan = fileIds;
			previouslyScannedCount = 0;
			$scope.scanningScanned = 0;
			$scope.scanningTotal = fileIds.length;
		}

		$scope.toScan = false;
		$scope.scanning = true;
		processNextScanStep();
	};

	$scope.stopScanning = function() {
		$scope.scanning = false;
	};

	$scope.resetScanned = function() {
		$scope.toScan = false;
		filesToScan = null;
		filesToScanIterator = 0;
		previouslyScannedCount = 0;
	};

	$scope.loadFoldersAndThen = function(callback) {
		if (libraryService.foldersLoaded()) {
			$timeout(callback);
		} else {
			Restangular.one('folders').get().then(function (folders) {
				libraryService.setFolders(folders);
				callback();
			});
		}
	};

	$scope.showTrackDetails = function(trackId) {
		$rootScope.$emit('showTrackDetails', trackId);
		$('#app-content').addClass('with-app-sidebar');
		$timeout(function() {
			var trackElem = document.getElementById('track-' + trackId);
			if (!isElementInViewPort(trackElem)) {
				$rootScope.$emit('scrollToTrack', trackId, 0);
			}
		}, 300);
	};

	$scope.showArtistDetails = function(artist) {
		$rootScope.$emit('showArtistDetails', artist.id);
		$('#app-content').addClass('with-app-sidebar');
		$timeout(function() {
			var artistElem = document.getElementById('artist-' + artist.id);
			if (!isElementInViewPort(artistElem)) {
				$rootScope.$emit('scrollToArtist', artist.id, 0);
			}
		}, 300);
	};

	$scope.hideSidebar = function() {
		$rootScope.$emit('hideDetails');
		$('#app-content').removeClass('with-app-sidebar');
		$('#app-content').css('margin-right', '');
	};

	function scrollOffset() {
		var controls = document.getElementById('controls');
		var header = document.getElementById('header');
		var offset = controls ? controls.offsetHeight : 0;
		if (OC_Music_Utils.newLayoutStructure() && header) {
			offset += header.offsetHeight;
		}
		return offset;
	}

	$scope.scrollToItem = function(itemId, animationTime /* optional */) {
		if (itemId) {
			var container = OC_Music_Utils.newLayoutStructure() ? $document : $('#app-content');
			var element = $('#' + itemId);
			if (container && element) {
				if (animationTime === undefined) {
					animationTime = 500;
				}
				container.scrollToElement(element, scrollOffset(), animationTime);
			}
		}
	};

	$scope.scrollToTop = function() {
		var container = OC_Music_Utils.newLayoutStructure() ? $document : $('#app-content');
		container.scrollTo(0, 0);
	};

	// Test if element is at least partially within the view-port
	function isElementInViewPort(el) {
		return inViewService.isElementInViewPort(el, -scrollOffset());
	}

	function setMasterLayout(classes) {
		var missingClasses = _.difference(['tablet', 'mobile', 'portrait'], classes);
		var appContent = $('#app-content');

		_.each(classes, function(cls) {
			appContent.addClass(cls);
		});
		_.each(missingClasses, function(cls) {
			appContent.removeClass(cls);
		});
	}

	$rootScope.$on('resize', function(event, appView) {
		var appViewWidth = appView.outerWidth();

		// Adjust controls bar width to not overlap with the scroll bar.
		// Subtrack one pixel from the width because outerWidth() seems to
		// return rounded integer value which may sometimes be slightly larger
		// than the actual width of the #app-view.
		var controlsWidth = appViewWidth - 1;
		$('#controls').css('width', controlsWidth);
		$('#controls').css('min-width', controlsWidth);

		// the "no content"/"click to scan"/"scanning" banner has the same width as controls 
		$('#app-content .emptycontent').css('width', controlsWidth);
		$('#app-content .emptycontent').css('min-width', controlsWidth);

		// Set the app-content class according to window and view width. This has
		// impact on the overall layout of the app. See mobile.css and tablet.css.
		if ($window.innerWidth <= 570 || appViewWidth <= 500) {
			setMasterLayout(['mobile', 'portrait']);
		}
		else if ($window.innerWidth <= 768) {
			setMasterLayout(['mobile']);
		}
		else if (appViewWidth <= 690) {
			setMasterLayout(['tablet', 'portrait']);
		}
		else if (appViewWidth <= 1024) {
			setMasterLayout(['tablet']);
		}
		else {
			setMasterLayout([]);
		}
	});

	if (OC_Music_Utils.newLayoutStructure()) {
		$('#controls').addClass('taller-header');
	}

	// Work-around for NC14+: The sidebar width has been limited to 500px (normally 27%),
	// but it's not possible to make corresponding "max margin" definition for #app-content
	// in css. Hence, the margin width is limited here.
	var appContent = $('#app-content');
	appContent.resize(function() {
		if (appContent.hasClass('with-app-sidebar')) {
			var sidebarWidth = $('#app-sidebar').outerWidth();
			var viewWidth = $('#header').outerWidth();

			if (sidebarWidth < 0.27 * viewWidth) {
				appContent.css('margin-right', sidebarWidth);
			} else {
				appContent.css('margin-right', '');
			}
		}
		else {
			appContent.css('margin-right', '');
		}
	});

	$scope.scanning = false;
	$scope.scanningScanned = 0;
	$scope.scanningTotal = 0;
}]);

angular.module('Music').controller('NavigationController', [
	'$rootScope', '$scope', 'Restangular', '$timeout', 'playlistService', 'libraryService', 'gettextCatalog',
	function ($rootScope, $scope, Restangular, $timeout, playlistService, libraryService, gettextCatalog) {

		$rootScope.loading = true;

		$scope.newPlaylistName = '';

		// holds the state of the editor (visible or not)
		$scope.showCreateForm = false;
		// same as above, but for the playlist renaming. Holds the number of the playlist, which is currently edited
		$scope.showEditForm = null;

		// Start creating playlist
		$scope.startCreate = function() {
			$scope.showCreateForm = true;
			// Move the focus to the input field. This has to be made asynchronously
			// because the field is not visible yet, it is shown by ng-show binding
			// later during this digest loop.
			$timeout(function() {
				$('.new-list').focus();
			});
		};

		// Commit creating playlist
		$scope.commitCreate = function() {
			if ($scope.newPlaylistName.length > 0) {
				Restangular.all('playlists').post({name: $scope.newPlaylistName}).then(function(playlist){
					libraryService.addPlaylist(playlist);
					$scope.newPlaylistName = '';
				});

				$scope.showCreateForm = false;
			}
		};

		// Start renaming playlist
		$scope.startEdit = function(playlist) {
			$scope.showEditForm = playlist.id;
			// Move the focus to the input field. This has to be made asynchronously
			// because the field does not exist yet, it is added by ng-if binding
			// later during this digest loop.
			$timeout(function() {
				$('.edit-list').focus();
			});
		};

		// Commit renaming of playlist
		$scope.commitEdit = function(playlist) {
			if (playlist.name.length > 0) {
				Restangular.one('playlists', playlist.id).put({name: playlist.name});
				$scope.showEditForm = null;
			}
		};

		// Remove playlist
		$scope.remove = function(playlist) {
			OC.dialogs.confirm(
					gettextCatalog.getString('Are you sure to remove the playlist "{{ name }}"?', { name: playlist.name }),
					gettextCatalog.getString('Remove playlist'),
					function(confirmed) {
						if (confirmed) {
							Restangular.one('playlists', playlist.id).remove();

							// remove the elemnt also from the AngularJS list
							libraryService.removePlaylist(playlist);
						}
					},
					true
				);
		};

		// Play/pause playlist
		$scope.togglePlay = function(destination, playlist) {
			if ($rootScope.playingView == destination) {
				playlistService.publish('togglePlayback');
			}
			else {
				var play = function(id, tracks) {
					if (tracks && tracks.length) {
						playlistService.setPlaylist(id, tracks);
						playlistService.publish('play', destination);
					}
				};

				if (destination == '#') {
					play('albums', libraryService.getTracksInAlbumOrder());
				} else if (destination == '#/alltracks') {
					play('alltracks', libraryService.getTracksInAlphaOrder());
				} else if (destination == '#/folders') {
					$scope.$parent.loadFoldersAndThen(function() {
						play('folders', libraryService.getTracksInFolderOrder());
					});
				} else if (destination == '#/genres') {
					play('genres', libraryService.getTracksInGenreOrder());
				} else {
					play('playlist-' + playlist.id, playlist.tracks);
				}
			}
		};

		// Add track to the playlist
		$scope.addTrack = function(playlist, songId) {
			addTracks(playlist, [songId]);
		};

		// Add all tracks on an album to the playlist
		$scope.addAlbum = function(playlist, albumId) {
			addTracks(playlist, trackIdsFromAlbum(albumId));
		};

		// Add all tracks on all albums by an artist to the playlist
		$scope.addArtist = function(playlist, artistId) {
			addTracks(playlist, trackIdsFromArtist(artistId));
		};

		// Add all tracks in a folder to the playlist
		$scope.addFolder = function(playlist, folderId) {
			addTracks(playlist, trackIdsFromFolder(folderId));
		};

		// Add all tracks of the genre to the playlist
		$scope.addGenre = function(playlist, genreId) {
			addTracks(playlist, trackIdsFromGenre(genreId));
		};

		// Navigate to a view selected from the navigation bar
		var navigationDestination = null;
		$scope.navigateTo = function(destination) {
			if ($rootScope.currentView != destination) {
				$rootScope.currentView = null;
				navigationDestination = destination;
				$rootScope.loading = true;
				// Deactivate the current view. The view emits 'viewDeactivated' once that is done.
				$rootScope.$emit('deactivateView');
			}
		};

		$rootScope.$on('viewDeactivated', function() {
			// carry on with the navigation once the previous view is deactivated
			window.location.hash = navigationDestination;
		});

		// An item dragged and dropped on a navigation bar playlist item
		$scope.dropOnPlaylist = function(droppedItem, playlist) {
			if ('track' in droppedItem) {
				$scope.addTrack(playlist, droppedItem.track);
			} else if ('album' in droppedItem) {
				$scope.addAlbum(playlist, droppedItem.album);
			} else if ('artist' in droppedItem) {
				$scope.addArtist(playlist, droppedItem.artist);
			} else if ('folder' in droppedItem) {
				$scope.addFolder(playlist, droppedItem.folder);
			} else if ('genre' in droppedItem) {
				$scope.addGenre(playlist, droppedItem.genre);
			} else {
				console.error("Unknwon entity dropped on playlist");
			}
		};

		$scope.allowDrop = function(playlist) {
			// Don't allow dragging a track from a playlist back to the same playlist
			return $rootScope.currentView != '#/playlist/' + playlist.id;
		};

		function trackIdsFromAlbum(albumId) {
			var album = libraryService.getAlbum(albumId);
			return _.pluck(album.tracks, 'id');
		}

		function trackIdsFromArtist(artistId) {
			var artist = libraryService.getArtist(artistId);
			return _.flatten(_.map(_.pluck(artist.albums, 'id'), trackIdsFromAlbum));
		}

		function trackIdsFromFolder(folderId) {
			var folder = libraryService.getFolder(folderId);
			return _.pluck(_.pluck(folder.tracks, 'track'), 'id');
		}

		function trackIdsFromGenre(genreId) {
			var genre = libraryService.getGenre(genreId);
			return _.pluck(_.pluck(genre.tracks, 'track'), 'id');
		}

		function addTracks(playlist, trackIds) {
			_.forEach(trackIds, function(trackId) {
				libraryService.addToPlaylist(playlist.id, trackId);
			});

			// Update the currently playing list if necessary
			if ($rootScope.playingView == "#/playlist/" + playlist.id) {
				var newTracks = _.map(trackIds, function(trackId) {
					return { track: libraryService.getTrack(trackId) };
				});
				playlistService.onTracksAdded(newTracks);
			}

			Restangular.one('playlists', playlist.id).all("add").post({trackIds: trackIds.join(',')});
		}
	}
]);

angular.module('Music').controller('PlayerController', [
'$scope', '$rootScope', 'playlistService', 'libraryService',
'Audio', 'Restangular', 'gettextCatalog', '$timeout', '$document',
function ($scope, $rootScope, playlistService, libraryService,
		Audio, Restangular, gettextCatalog, $timeout, $document) {

	$scope.loading = false;
	$scope.player = Audio;
	$scope.currentTrack = null;
	$scope.currentAlbum = null;
	$scope.seekCursorType = 'default';
	$scope.volume = parseInt(Cookies.get('oc_music_volume')) || 50;  // volume can be 0~100
	$scope.repeat = Cookies.get('oc_music_repeat') == 'true';
	$scope.shuffle = Cookies.get('oc_music_shuffle') == 'true';
	$scope.position = {
		bufferPercent: '0%',
		currentPercent: '0%',
		current: 0,
		total: 0
	};

	playlistService.setRepeat($scope.repeat);
	playlistService.setShuffle($scope.shuffle);

	// Player events may fire synchronously or asynchronously. Utilize $timeout
	// to always handle them asynchronously to run the handler within digest loop
	// but with no nested digests loop (which causes an exception).
	function onPlayerEvent(event, handler) {
		$scope.player.on(event, function(arg) {
			$timeout(function() {
				handler(arg);
			});
		});
	}

	onPlayerEvent('buffer', function (percent) {
		$scope.setBufferPercentage(percent);
	});
	onPlayerEvent('ready', function () {
		$scope.setLoading(false);
	});
	onPlayerEvent('progress', function (currentTime) {
		$scope.setTime(currentTime/1000, $scope.position.total);
		$rootScope.$emit('playerProgress', currentTime);
	});
	onPlayerEvent('end', function() {
		$scope.next();
	});
	onPlayerEvent('duration', function(msecs) {
		$scope.setTime($scope.position.current, msecs/1000);
	});
	onPlayerEvent('error', function(url) {
		var filename = url.split('?').shift().split('/').pop();
		OC.Notification.showTemporary(gettextCatalog.getString('Error playing file: ' + filename));
		$scope.next();
	});
	onPlayerEvent('play', function() {
		$rootScope.playing = true;
	});
	onPlayerEvent('pause', function() {
		$rootScope.playing = false;
	});
	onPlayerEvent('stop', function() {
		$rootScope.playing = false;
	});

	var titleApp = $('title').html().trim();
	var titleSong = '';
	var titleIcon = '';

	function updateWindowTitle() {
		$('title').html(titleIcon + titleSong + titleApp);
	}

	// display a play icon in the title if a song is playing
	$scope.$watch('playing', function(newValue) {
		titleIcon = newValue ? '▶ ' : '';
		updateWindowTitle();
	});

	// display the song name and artist in the title when there is current track
	$scope.$watch('currentTrack', function(newTrack) {
		titleSong = newTrack ? newTrack.title + ' (' + newTrack.artistName + ') - ' : '';
		updateWindowTitle();
	});

	$scope.getPlayableFileId = function (track) {
		for(var mimeType in track.files) {
			if($scope.player.canPlayMIME(mimeType)) {
				return {
					'mime': mimeType,
					'id': track.files[mimeType]
				};
			}
		}

		return null;
	};

	function setCurrentTrack(playlistEntry) {
		var track = playlistEntry ? playlistEntry.track : null;

		if (track !== null) {
			// switch initial state
			$rootScope.started = true;
			$scope.setLoading(true);
			playTrack(track);
		} else {
			$scope.stop();
		}
	}

	var pathRequestTimer = null;
	function playTrack(track) {
		$scope.currentTrack = track;
		$scope.currentAlbum = track.album;

		// Pause any previous playback
		$scope.player.pause();

		// Execute the action with small delay. This is to limit the number of GET requests
		// when repeatedly changing the playing track like when rapidly and repeatedly clicking
		// the Next button. Too high number of simultaneous GET requests could easily jam a
		// low-power server.
		if (pathRequestTimer !== null) {
			$timeout.cancel(pathRequestTimer);
		}

		pathRequestTimer = $timeout(function() {
			// Get path to the track and from a webDAV URL. The webDAV URL is 
			// then passed to PlayerWrapper for playing.
			var mimeAndId = $scope.getPlayableFileId(track);
			Restangular.one('file', mimeAndId.id).one('path').get().then(
				function(result) {
					// It is possible that the active track has already changed again by the time we get
					// the URI. Do not start playback in that case.
					if (track == $scope.currentTrack) {
						var url = OC.linkToRemoteBase('webdav') + result.path +
								'?requesttoken=' + encodeURIComponent(OC.requestToken);
						$scope.player.fromURL(url, mimeAndId.mime);
						$scope.seekCursorType = $scope.player.seekingSupported() ? 'pointer' : 'default';

						$scope.player.play();

						pathRequestTimer = null;
					}
				}
			);
		}, 300);
	}

	$scope.setLoading = function(loading) {
		$scope.loading = loading;
		if (loading) {
			$scope.position.current = 0;
			$scope.position.currentPercent = 0;
			$scope.position.bufferPercent = 0;
			$scope.position.total = 0;
		}
	};

	$scope.$watch('volume', function(newValue, oldValue) {
		$scope.player.setVolume(newValue);
		Cookies.set('oc_music_volume', newValue, { expires: 3650 });
	});

	$scope.toggleShuffle = function() {
		$scope.shuffle = !$scope.shuffle;
		playlistService.setShuffle($scope.shuffle);
		Cookies.set('oc_music_shuffle', $scope.shuffle.toString(), { expires: 3650 });
	};

	$scope.toggleRepeat = function() {
		$scope.repeat = !$scope.repeat;
		playlistService.setRepeat($scope.repeat);
		Cookies.set('oc_music_repeat', $scope.repeat.toString(), { expires: 3650 });
	};

	$scope.setTime = function(position, duration) {
		$scope.position.current = position;
		$scope.position.total = duration;
		$scope.position.currentPercent = (duration > 0 && position <= duration) ?
				Math.round(position/duration*100) + '%' : 0;
	};

	$scope.setBufferPercentage = function(percent) {
		$scope.position.bufferPercent = Math.min(100, Math.round(percent)) + '%';
	};

	$scope.play = function() {
		if ($scope.currentTrack !== null) {
			$scope.player.play();
		}
	};

	$scope.pause = function() {
		if ($scope.currentTrack !== null) {
			$scope.player.pause();
		}
	};

	$scope.togglePlayback = function() {
		if ($rootScope.playing) {
			$scope.pause();
		} else {
			$scope.play();
		}
	};

	$scope.stop = function() {
		$scope.player.stop();
		$scope.currentTrack = null;
		$scope.currentAlbum = null;
		$rootScope.playing = false;
		$rootScope.started = false;
		playlistService.clearPlaylist();
	};

	$scope.next = function() {
		var entry = playlistService.jumpToNextTrack(),
			tracksSkipped = false;

		// get the next track as long as the current one contains no playable
		// audio mimetype
		while (entry !== null && !$scope.getPlayableFileId(entry.track)) {
			tracksSkipped = true;
			entry = playlistService.jumpToNextTrack();
		}
		if (tracksSkipped) {
			OC.Notification.showTemporary(gettextCatalog.getString('Some not playable tracks were skipped.'));
		}
		setCurrentTrack(entry);
	};

	$scope.prev = function() {
		// Jump to the beginning of the current track if it has already played more than 2 secs
		if ($scope.position.current > 2.0 && $scope.player.seekingSupported()) {
			$scope.player.seek(0);
		}
		// Jump to the previous track if the current track has played only 2 secs or less
		else {
			var track = playlistService.jumpToPrevTrack();
			if (track !== null) {
				setCurrentTrack(track);
			}
		}
	};

	$scope.seek = function($event) {
		var offsetX = $event.offsetX || $event.originalEvent.layerX;
		var ratio = offsetX / $event.currentTarget.clientWidth;
		$scope.player.seek(ratio);
	};

	$scope.seekBackward = $scope.player.seekBackward;

	$scope.seekForward = $scope.player.seekForward;

	playlistService.subscribe('play', $scope.next /* fetch track and start playing*/);

	playlistService.subscribe('togglePlayback', $scope.togglePlayback);

	$scope.scrollToCurrentTrack = function() {
		if ($scope.currentTrack) {
			$rootScope.$emit('scrollToTrack', $scope.currentTrack.id);
		}
	};

	$document.bind('keydown', function(e) {
		if (e.target == document.body) {
			var func = null;
			switch (e.which) {
				case 32: //space
					func = $scope.togglePlayback;
					break;
				case 37: // arrow left
					func = $scope.prev;
					break;
				case 39: // arrow right
					func = $scope.next;
					break;
			}

			if (func) {
				$timeout(func);
				return false;
			}
		}

		return true;
	});

	/**
	 * Integration to the media control panel available on Chrome starting from version 73 and Edge from
	 * version 83. In Firefox, it is still disabled in the version 77, but a partially working support can
	 * be enabled via the advanced settings.
	 *
	 * The API brings the bindings with the special multimedia keys possibly present on the keyboard,
	 * as well as any OS multimedia controls available e.g. in status pane and/or lock screen.
	 */
	if ('mediaSession' in navigator) {
		var registerMediaControlHandler = function(action, handler) {
			try {
				navigator.mediaSession.setActionHandler(action, function() { $timeout(handler); });
			} catch (error) {
				console.log("The media control '" + action + "' is not supported by the browser");
			}
		};

		registerMediaControlHandler('play', $scope.play);
		registerMediaControlHandler('pause', $scope.pause);
		registerMediaControlHandler('stop', $scope.stop);
		registerMediaControlHandler('seekbackward', $scope.seekBackward);
		registerMediaControlHandler('seekforward', $scope.seekForward);
		registerMediaControlHandler('previoustrack', $scope.prev);
		registerMediaControlHandler('nexttrack', $scope.next);

		$scope.$watch('currentTrack', function(track) {
			if (track) {
				navigator.mediaSession.metadata = new MediaMetadata({
					title: track.title,
					artist: track.artistName,
					album: track.album.name,
					artwork: [{
						sizes: "190x190",
						src: track.album.cover,
						type: ""
					}]
				});
			}
		});
	}
}]);

angular.module('Music').controller('PlaylistViewController', [
	'$rootScope', '$scope', '$routeParams', 'playlistService', 'libraryService',
	'gettextCatalog', 'Restangular', '$timeout',
	function ($rootScope, $scope, $routeParams, playlistService, libraryService,
			gettextCatalog, Restangular, $timeout) {

		var INCREMENTAL_LOAD_STEP = 1000;
		$scope.incrementalLoadLimit = INCREMENTAL_LOAD_STEP;
		$scope.tracks = null;
		$rootScope.currentView = window.location.hash;

		// $rootScope listeneres must be unsubscribed manually when the control is destroyed
		var unsubFuncs = [];

		function subscribe(event, handler) {
			unsubFuncs.push( $rootScope.$on(event, handler) );
		}

		$scope.$on('$destroy', function() {
			_.each(unsubFuncs, function(func) { func(); });
		});

		$scope.getCurrentTrackIndex = function() {
			return listIsPlaying() ? $scope.$parent.currentTrackIndex : null;
		};

		// Remove chosen track from the list
		$scope.removeTrack = function(trackIndex) {
			var listId = $scope.playlist.id;

			// Remove the element first from our internal array, without recreating the whole array.
			// Doing this before the HTTP request improves the perceived performance.
			libraryService.removeFromPlaylist(listId, trackIndex);

			if (listIsPlaying()) {
				var playingIndex = $scope.getCurrentTrackIndex();
				if (trackIndex <= playingIndex) {
					--playingIndex;
				}
				playlistService.onPlaylistModified($scope.tracks, playingIndex);
			}

			Restangular.one('playlists', listId).all("remove").post({indices: trackIndex});
		};

		function play(startIndex /*optional*/) {
			var id = 'playlist-' + $scope.playlist.id;
			playlistService.setPlaylist(id, $scope.tracks, startIndex);
			playlistService.publish('play');
		}

		// Call playlistService to play all songs in the current playlist from the beginning
		$scope.onHeaderClick = function() {
			play();
		};

		// Play the list, starting from a specific track
		$scope.onTrackClick = function(trackIndex) {
			// play/pause if currently playing list item clicked
			if ($scope.getCurrentTrackIndex() === trackIndex) {
				playlistService.publish('togglePlayback');
			}
			// on any other list item, start playing the list from this item
			else {
				play(trackIndex);
			}
		};

		$scope.getDraggable = function(index) {
			$scope.draggedIndex = index;
			return {
				track: $scope.tracks[index].track.id,
				srcIndex: index
			};
		};

		$scope.reorderDrop = function(draggable, dstIndex) {
			var listId = $scope.playlist.id;
			var srcIndex = draggable.srcIndex;

			libraryService.reorderPlaylist($scope.playlist.id, srcIndex, dstIndex);

			if (listIsPlaying()) {
				var playingIndex = $scope.getCurrentTrackIndex();
				if (playingIndex === srcIndex) {
					playingIndex = dstIndex;
				}
				else {
					if (playingIndex > srcIndex) {
						--playingIndex;
					}
					if (playingIndex >= dstIndex) {
						++playingIndex;
					}
				}
				playlistService.onPlaylistModified($scope.tracks, playingIndex);
			}

			Restangular.one('playlists', listId).all("reorder").post({fromIndex: srcIndex, toIndex: dstIndex});
		};

		$scope.allowDrop = function(draggable, dstIndex) {
			return draggable.srcIndex != dstIndex;
		};

		$scope.updateHoverStyle = function(dstIndex) {
			var element = $('.playlist-area .track-list');
			if ($scope.draggedIndex > dstIndex) {
				element.removeClass('insert-below');
				element.addClass('insert-above');
			} else if ($scope.draggedIndex < dstIndex) {
				element.removeClass('insert-above');
				element.addClass('insert-below');
			} else {
				element.removeClass('insert-above');
				element.removeClass('insert-below');
			}
		};

		subscribe('scrollToTrack', function(event, trackId) {
			if ($scope.$parent) {
				var currentIdx = $scope.getCurrentTrackIndex();
				var index;

				// There may be more than one playlist entry with the same track ID.
				// Prefer to scroll to the currently playing entry if the requested
				// track ID matches that. Otherwise scroll to the first match.
				if (currentIdx &&  $scope.tracks[currentIdx].track.id == trackId) {
					index = currentIdx;
				} else {
					index = _.findIndex($scope.tracks, function(entry) {
						return entry.track.id == trackId;
					});
				}
				$scope.$parent.scrollToItem('playlist-track-' + index);
			}
		});

		// Init happens either immediately (after making the loading animation visible)
		// or once both aritsts and playlists have been loaded
		$timeout(initViewFromRoute);
		subscribe('artistsLoaded', initViewFromRoute);
		subscribe('playlistsLoaded', initViewFromRoute);

		function listIsPlaying() {
			return ($rootScope.playingView === $rootScope.currentView);
		}

		function showMore() {
			// show more entries only if the view is not already (being) deactivated
			if ($rootScope.currentView && $scope.$parent) {
				$scope.incrementalLoadLimit += INCREMENTAL_LOAD_STEP;
				if ($scope.incrementalLoadLimit < $scope.tracks.length) {
					$timeout(showMore);
				} else {
					$rootScope.loading = false;
				}
			}
		}

		function initViewFromRoute() {
			if (libraryService.collectionLoaded() && libraryService.playlistsLoaded()) {
				if ($routeParams.playlistId) {
					var playlist = libraryService.getPlaylist($routeParams.playlistId);
					if (playlist) {
						$scope.playlist = playlist;
						$scope.tracks = playlist.tracks;
					}
					else {
						OC.Notification.showTemporary(gettextCatalog.getString('Requested entry was not found'));
						window.location.hash = '#/';
					}
				}
				$timeout(showMore);
			}
		}

		function showLess() {
			$scope.incrementalLoadLimit -= INCREMENTAL_LOAD_STEP;
			if ($scope.incrementalLoadLimit > 0) {
				$timeout(showLess);
			} else {
				$scope.incrementalLoadLimit = 0;
				$rootScope.$emit('viewDeactivated');
			}
		}

		subscribe('deactivateView', function() {
			$timeout(showLess);
		});

	}
]);

/**
 * This controller implements the search/filtering logic for all views. The details
 * of the search still vary per-view.
 * 
 * When the search query is written to the searchbox, the core automatically sends the query
 * to the backend. However, we disregard any results from the back-end and conduct the search
 * on our own, on the front-end.
 */
angular.module('Music').controller('SearchController', [
'$scope', '$rootScope', 'libraryService', 'alphabetIndexingService', '$timeout', '$document', 'gettextCatalog',
function ($scope, $rootScope, libraryService, alphabetIndexingService, $timeout, $document, gettextCatalog) {

	var MAX_MATCHES = 5000;
	var MAX_MATCHES_IN_PLAYLIST = 1000;

	var searchbox = $('#searchbox');
	$scope.queryString = searchbox.val().trim();

	/** Conduct the search when there is a pause in typing in text */
	var checkQueryChange = _.debounce(function() {
		if ($scope.queryString != searchbox.val().trim()) {
			onEnterSearchString();
		}
	}, 250);
	searchbox.bind('propertychange change keyup input paste', checkQueryChange);

	/** Handle clearing the searchbox. This has to be registered to the parent form
	 *  of the #searchbox element.
	 */
	$('.searchbox').on('reset', function() {
		$scope.queryString = '';
		$scope.$apply(startProgress);
		$timeout(clearSearch);
	});

	/** Catch ctrl+f except when the Settings view is active */
	$document.bind('keydown', function(e) {
		if ($rootScope.currentView !== '#/settings' && e.ctrlKey && e.key === 'f') {
			searchbox.focus();
			return false;
		}
		return true;
	});

	/** Run search when enter pressed within the searchbox */
	searchbox.bind('keydown', function (event) {
		if (event.which === 13) {
			onEnterSearchString();
		}
	});

	/** Search query is considered to be empty if it contains only whitespace and/or quotes (") */
	function queryIsEmpty() {
		return ($scope.queryString.length === 0 || $scope.queryString.match(/[^\s"]/) === null);
	}

	function onEnterSearchString() {
		$scope.queryString = searchbox.val().trim();

		$scope.$apply(startProgress);

		$timeout(function() {
			if (!queryIsEmpty()) {
				runSearch($scope.queryString);
			} else {
				clearSearch();
			}
		});
	}

	function startProgress() {
		$rootScope.searchInProgress = true;
		$scope.$parent.scrollToTop();
	}

	function endProgress() {
		$rootScope.searchInProgress = false;
	}

	function runSearch(query) {
		// reset previous matches
		$('.matched').removeClass('matched');

		var matchingTracks = null;
		var view = $rootScope.currentView;

		if (view == '#') {
			matchingTracks = searchInAlbumsView(query);
		} else if (view == '#/folders') {
			matchingTracks = searchInFoldersView(query);
		} else if (view == '#/genres') {
			matchingTracks = searchInGenresView(query);
		} else if (view == '#/alltracks') {
			matchingTracks = searchInAllTracksView(query);
		} else if (view.startsWith('#/playlist/')) {
			matchingTracks = searchInPlaylistView(view.substr('#/playlist/'.length), query);
		} else {
			OC.Notification.showTemporary(gettextCatalog.getString('Search not available in this view'));
			endProgress();
			return;
		}

		$scope.searchResultsOmitted = matchingTracks.truncated;
		$scope.noSearchResults = (matchingTracks.result.length === 0);

		// inform the track-list directive about changed search matches
		$rootScope.$emit('searchMatchedTracks', matchingTracks.result);

		$('#app-view').addClass('searchmode');

		$rootScope.$emit('inViewObserver_visibilityEvent', true);

		endProgress();
	}

	function searchInAlbumsView(query) {
		var matches = libraryService.searchTracksInAlbums(query, MAX_MATCHES);

		// mark track matches and collet the unique parent albums and artists
		var artists = {};
		var albums = {};
		_(matches.result).each(function(track) {
			$('#track-' + track.id).addClass('matched');
			albums[track.album.id] = 1;
			artists[track.album.artist.id] = 1;
		});

		// mark parent artists of the matches
		_(artists).each(function(value, artistId) {
			$('#artist-' + artistId).addClass('matched');
		});

		// mark parent albums of the matches
		_(albums).each(function(value, albumId) {
			$('#album-' + albumId).addClass('matched');
		});

		return matches;
	}

	function searchInFoldersView(query) {
		var matches = libraryService.searchTracksInFolders(query, MAX_MATCHES);

		// mark track matches and collect the unique parent folders
		var folders = {};
		_(matches.result).each(function(track) {
			$('#track-' + track.id).addClass('matched');
			folders[track.folder.id] = 1;
		});

		// mark parent folders of the matches
		_(folders).each(function(value, folderId) {
			$('#folder-' + folderId).addClass('matched');
		});

		return matches;
	}

	function searchInGenresView(query) {
		var matches = libraryService.searchTracksInGenres(query, MAX_MATCHES);

		// mark track matches and collect the unique parent genres
		var genres = {};
		_(matches.result).each(function(track) {
			$('#track-' + track.id).addClass('matched');
			genres[track.genre.id] = 1;
		});

		// mark parent folders of the matches
		_(genres).each(function(value, genreId) {
			$('#genre-' + genreId).addClass('matched');
		});

		return matches;
	}

	function searchInAllTracksView(query) {
		var matches = libraryService.searchTracks(query, MAX_MATCHES);

		// mark matching tracks and collect unique parent buckets
		var buckets = {};
		_(matches.result).each(function(track) {
			$('#track-' + track.id).addClass('matched');
			buckets[track.bucket.id] = 1;
		});

		// mark parent buckets
		_(buckets).each(function(value, bucketId) {
			$('#track-bucket-' + bucketId).addClass('matched');
		});

		return matches;
	}

	function searchInPlaylistView(playlistId, query) {
		var matches = libraryService.searchTracksInPlaylist(playlistId, query, MAX_MATCHES_IN_PLAYLIST);
		_(matches.result).each(function(track) {
			$('li[data-track-id=' + track.id + ']').addClass('matched');
		});

		return matches;
	}

	function clearSearch() {
		$rootScope.$emit('searchOff');
		$('#app-view').removeClass('searchmode');
		$('.matched').removeClass('matched');
		$rootScope.$emit('inViewObserver_visibilityEvent', false);
		$scope.searchResultsOmitted = false;
		$scope.noSearchResults = false;
		endProgress();
	}

	$rootScope.$on('deactivateView', function() {
		$scope.searchResultsOmitted = false;
		$scope.noSearchResults = false;
		$rootScope.$emit('searchOff');
		endProgress();
	});
}]);

angular.module('Music').controller('SettingsViewController', [
	'$scope', '$rootScope', 'Restangular', '$window', '$timeout', 'gettextCatalog',
	function ($scope, $rootScope, Restangular, $window, $timeout, gettextCatalog) {

		$rootScope.currentView = window.location.hash;

		$scope.issueTrackerUrl = 'https://github.com/owncloud/music/issues';
		$scope.ampacheClientsUrl = 'https://github.com/owncloud/music/wiki/Ampache';
		$scope.subsonicClientsUrl = 'https://github.com/owncloud/music/wiki/Subsonic';

		// $rootScope listeneres must be unsubscribed manually when the control is destroyed
		var unsubFuncs = [];

		function subscribe(event, handler) {
			unsubFuncs.push( $rootScope.$on(event, handler) );
		}

		$scope.$on('$destroy', function () {
			_.each(unsubFuncs, function(func) { func(); });
		});

		$scope.selectPath = function() {
			OC.dialogs.filepicker(
				gettextCatalog.getString('Path to your music collection'),
				function (path) {
					if (path.substr(-1) !== '/') {
						path = path + '/';
					}
					if ($scope.settings.path !== path) {
						$scope.pathChangeOngoing = true;

						// Stop any ongoing scan if path got changed
						$scope.$parent.stopScanning();

						// Store the parent reference before posting the changed value to backend;
						// $scope.$parent may not be available any more in the callback in case
						// the user has navigated to another view in the meantime.
						var parent = $scope.$parent;
						Restangular.all('settings/user/path').post({value: path}).then(
							function (data) {
								if (data.success) {
									$scope.errorPath = false;
									$scope.settings.path = path;
									parent.update();
								} else {
									$scope.errorPath = true;
								}
								$scope.pathChangeOngoing = false;
							},
							function(response) { // error handling
								$scope.pathChangeOngoing = false;
								$scope.errorPath = true;
							}
						);
					}
				},
				false,
				'httpd/unix-directory',
				true
			);
		};

		$scope.resetCollection = function() {
			OC.dialogs.confirm(
				gettextCatalog.getString('Are you sure to reset the music collection? This removes all scanned tracks and user-created playlists!'),
				gettextCatalog.getString('Reset music collection'),
				function(confirmed) {
					if (confirmed) {
						$scope.resetOngoing = true;

						// stop any ongoing scan before posting the reset command
						$scope.$parent.stopScanning();

						// $scope.$parent may not be available any more in the callback in case
						// the user has navigated to another view in the meantime
						var parent = $scope.$parent;
						var executeReset = function() {
							Restangular.all('resetscanned').post().then(
									function (data) {
										if (data.success) {
											parent.resetScanned();
											parent.update();
										}
										$scope.resetOngoing = false;
									},
									function(response) { // error handling
										$scope.resetOngoing = false;
										OC.Notification.showTemporary(
												gettextCatalog.getString('Failed to reset the collection: ') + reason);
									}
								);
						};

						// Trigger the reset with a small delay. This is to tackle a small issue when
						// reset button is pressed during scanning: if the POST /api/scan call fires
						// just before POST /api/resetscanned, the server may receive these two messages
						// in undeterministic order. This is because modern browsers typically hold several
						// TCP connections and successive messages are often sent through different TCP pipes.
						$timeout(executeReset, 100);
					}
				},
				true
			);
		};

		$scope.addAPIKey = function() {
			var password = Math.random().toString(36).slice(-6) + Math.random().toString(36).slice(-6);
			Restangular.all('settings/userkey/add').post({ password: password, description: $scope.ampacheDescription }).then(function(data) {
				if (data.success) {
					$scope.settings.ampacheKeys.push({
						description: $scope.ampacheDescription,
						id: data.id
						});
					$scope.ampacheDescription = '';
					$scope.ampachePassword = password;
				} else {
					$scope.ampachePassword = '';
					$scope.errorAmpache = true;
				}
			});
		};

		$scope.removeAPIKey = function(key) {
			key.loading=true;
			Restangular.all('settings/userkey/remove').post({ id: key.id }).then(function(data) {
				if (data.success) {
					// refresh remaining ampacheKeys
					Restangular.one('settings').get().then(function (value) {
						$scope.settings.ampacheKeys = value.ampacheKeys;
					});
				} else {
					key.loading=false;
				}
			});
		};

		$scope.copyToClipboard = function(elementId) {
			var range = document.createRange();
			range.selectNode(document.getElementById(elementId));
			window.getSelection().removeAllRanges(); // clear current selection
			window.getSelection().addRange(range); // to select text
			var success = document.execCommand("copy");

			if (success) {
				OC.Notification.showTemporary(
						gettextCatalog.getString('Text copied to clipboard'));
			}
		};

		$scope.errorPath = false;
		$scope.errorAmpache = false;

		$timeout(function() {
			Restangular.one('settings').get().then(function (value) {
				$scope.settings = value;
				$rootScope.loading = false;
			});
		});

		subscribe('deactivateView', function() {
			$rootScope.$emit('viewDeactivated');
		});

	}
]);

angular.module('Music').controller('SidebarController', [
	'$rootScope', '$scope', '$timeout',
	function ($rootScope, $scope, $timeout) {

		$scope.follow = Cookies.get('oc_music_details_follow_playback') == 'true';

		$scope.contentType = null;
		$scope.contentId = null;

		$scope.adjustFixedPositions = function() {
			$timeout(function() {
				var sidebarWidth = $('#app-sidebar').outerWidth();
				var contentWidth = $('#app-sidebar .sidebar-content').outerWidth();
				var offset = sidebarWidth - contentWidth;
				$('#app-sidebar .close').css('right', offset);
				$('#app-sidebar #follow-playback').css('right', offset);

				$('#app-sidebar .close').css('top', $('#header').outerHeight());
			});
		};

		function showTrackDetails(trackId) {
			OC.Apps.showAppSidebar();
			$scope.contentType = 'track';
			$scope.contentId = trackId;
			$scope.adjustFixedPositions();
		}

		function showArtistDetails(artistId) {
			OC.Apps.showAppSidebar();
			$scope.contentType = 'artist';
			$scope.contentId = artistId;
			$scope.adjustFixedPositions();
		}

		$rootScope.$on('showTrackDetails', function(event, trackId) {
			showTrackDetails(trackId);
		});

		$rootScope.$on('showArtistDetails', function(event, artistId) {
			showArtistDetails(artistId);
		});

		$rootScope.$on('hideDetails', function() {
			OC.Apps.hideAppSidebar();
		});

		$rootScope.$on('resize', $scope.adjustFixedPositions);

		$scope.$parent.$watch('currentTrack', function(track) {
			// show details for the current track if the feature is enabled
			if ($scope.follow && track && !$('#app-sidebar').hasClass('disappear')) {
				showTrackDetails(track.id);
			}
		});

		$scope.toggleFollow = function() {
			$scope.follow = !$scope.follow;
			Cookies.set('oc_music_details_follow_playback', $scope.follow.toString(), { expires: 3650 });

			// If "follow playback" was enabled and the currently shown track doesn't match currently
			// playing track, then immediately switch to the details of the playing track.
			if ($scope.follow && $scope.$parent.currentTrack
					&& ($scope.$parent.currentTrack.id != $scope.contentId || $scope.contentType != 'track')) {
				showTrackDetails($scope.$parent.currentTrack.id);
			}
		};
	}
]);

angular.module('Music').controller('TrackDetailsController', [
	'$rootScope', '$scope', 'Restangular', 'libraryService',
	function ($rootScope, $scope, Restangular, libraryService) {

		$scope.selectedTab = 'general';

		var currentTrack = null;

		function getFileId(trackId) {
			var files = libraryService.getTrack(trackId).files;
			return files[Object.keys(files)[0]];
		}

		function toArray(obj) {
			return _.map(obj, function(val, key) {
				return {key: key, value: val};
			});
		}

		function isFloat(n) {
			return typeof n === "number" && Math.floor(n) !== n;
		}

		function showDetails(trackId) {
			if (trackId != currentTrack) {
				currentTrack = trackId;
				$scope.details = null;

				var albumart = $('#app-sidebar .albumart');
				albumart.css('background-image', '').css('height', '0');

				var fileId = getFileId(trackId);
				$('#path').attr('href', OC.generateUrl('/f/' + fileId));

				Restangular.one('file', fileId).one('details').get().then(function(result) {
					if (result.tags.picture) {
						albumart.css('background-image', 'url("' + result.tags.picture + '")');
						albumart.css('height', ''); // remove the inline height and use the one from the css file
					}
					delete result.tags.picture;

					result.tags = toArray(result.tags);
					result.fileinfo = toArray(result.fileinfo);
					$scope.details = result;

					if ($scope.selectedTab == 'lyrics' && !$scope.details.lyrics) {
						// 'lyrics' tab is selected but not available => select 'general' tab
						$scope.selectedTab = 'general';
					}

					$scope.$parent.adjustFixedPositions();
				});
			}
		}

		$scope.$watch('contentId', showDetails);

		$rootScope.$on('playerProgress', function(event, time) {
			// check if we are viewing time-synced lyrics of the currently playing track
			if ($scope.details && $scope.details.lyrics && $scope.details.lyrics.synced
					&& $scope.$parent.currentTrack.id == currentTrack) {
				// Check if the highlighted row needs to change. First find the last row
				// which has been already reached by the playback.
				var allRows = $("#app-sidebar .lyrics");
				for (var i = allRows.length - 1; i >= 0; --i) {
					var curRow = $(allRows[i]);
					if (Number(curRow.attr('data-timestamp')) <= time) {
						if (!curRow.hasClass('highlight')) {
							// highlight actually needs to move
							allRows.removeClass('highlight');
							curRow.addClass('highlight');
						}
						break;
					}
				}
			}
		});

		$scope.$watch('selectedTab', $scope.$parent.adjustFixedPositions);

		$scope.formatDetailValue = function(value) {
			if (isFloat(value)) {
				// limit the number of shown digits on floating point numbers
				return Number(value.toPrecision(6));
			} else if (_.isString(value)){
				// convert \r\n -> \n because IE9 prints two new-lines on the former
				return value.replace(/\r\n/g, '\n');
			} else {
				return value;
			}
		};

		$scope.formatDetailName = function(rawName) {
			switch (rawName) {
			case 'band':			return 'album artist';
			case 'albumartist':		return 'album artist';
			case 'tracktotal':		return 'total tracks';
			case 'totaltracks':		return 'total tracks';
			case 'part_of_a_set':	return 'disc number';
			case 'discnumber':		return 'disc number';
			case 'dataformat':		return 'format';
			case 'channelmode':		return 'channel mode';
			default:				return rawName.replace(/_/g, ' ').toLowerCase();
			}
		};

		$scope.tagRank = function(tag) {
			switch (tag.key) {
			case 'title':			return 1;
			case 'artist':			return 2;
			case 'album':			return 3;
			case 'albumartist':		return 4;
			case 'album_artist':	return 4;
			case 'band':			return 4;
			case 'composer':		return 5;
			case 'part_of_a_set':	return 6;
			case 'discnumber':		return 6;
			case 'disc_number':		return 6;
			case 'track_number':	return 7;
			case 'tracknumber':		return 7;
			case 'track':			return 7;
			case 'totaltracks':		return 8;
			case 'tracktotal':		return 8;
			case 'comment':			return 100;
			default:				return 10;
			}
		};
	}
]);

angular.module('Music').directive('albumart', [function() {

	function setCoverImage(element, imageUrl) {
		// remove placeholder stuff
		element.html('');
		element.css('background-color', '');

		element.css('background-image', 'url(' + imageUrl + ')');
	}

	function setPlaceholder(element, text) {
		if (text) {
			// remove background image
			element.css('-ms-filter', '');
			element.css('background-image', '');
			// add placeholder stuff
			element.imageplaceholder(text);
			// remove inlined size-related style properties set by imageplaceholder() to allow
			// dynamic changing between mobile and desktop styles when window size changes
			element.css('line-height', '');
			element.css('font-size', '');
			element.css('width', '');
			element.css('height', '');
		}
	}

	return {
		require: '?^inViewObserver',
		link: function(scope, element, attrs, ctrl) {
			/**
			 * This directive can be used for two different purposes in two different
			 * contexts:
			 * 1. Within a scroling container, in which case there should be inViewObserver
			 *    directive as ancestor of this directive. In this case, inViewObserver is 
			 *    paased to here in the argument `ctrl`.
			 * 2. Within the player control pane, in which case there's no ancestor inViewObserver
			 *    and `ctrl` is null. In this case, the directive observes any changes on the
			 *    related attributes of the element.
			 */

			var onCoverChanged = function() {
				if (attrs.cover) {
					setCoverImage(element, attrs.cover);
				} else {
					setPlaceholder(element, attrs.albumart);
				}
			};

			var onAlbumartChanged = function() {
				if (!attrs.cover) {
					setPlaceholder(element, attrs.albumart);
				}
			};

			if (ctrl) {
				ctrl.registerListener({
					onEnterView: onCoverChanged,
					onLeaveView: function() { /* nothing to do */ }
				});
			}
			else {
				attrs.$observe('albumart', onAlbumartChanged);
				attrs.$observe('cover', onCoverChanged);
			}
		}
	};
}]);


angular.module('Music').directive('alphabetNavigation', ['$rootScope', '$timeout', 'alphabetIndexingService',
function($rootScope, $timeout, alphabetIndexingService) {
	return {
		restrict: 'E',
		scope: {
			itemCount: '<',
			getElemTitle: '<',
			getElemId: '<',
			scrollToTarget: '<'
		},
		templateUrl: 'alphabetnavigation.html',
		replace: true,
		link: function(scope, element, attrs, ctrl) {

			var links = alphabetIndexingService.indexChars();
			var linksShort = [
				'#', 'A-B', 'C-D', 'E-F', 'G-H', 'I-J', 'K-L', 'M-N',
				'O-P', 'Q-R', 'S-T', 'U-V', 'W-X', 'Y-Z', '…'
			];
			var linksExtraShort = [
				'A-C', 'D-F', 'G-I', 'J-L', 'M-O', 'P-R', 'S-U', 'V-X', 'Y-Z'
			];
			scope.links = links;
			scope.targets = {};

			function itemPrecedesLetter(itemIdx, linkIdx) {
				var title = scope.getElemTitle(itemIdx);
				return (linkIdx >= links.length
						|| alphabetIndexingService.titlePrecedesIndexCharAt(title, linkIdx));
			}

			function setUpMainLinks() {
				for (var linkIdx = 0, itemIdx = 0;
					linkIdx < links.length && itemIdx < scope.itemCount;
					++linkIdx)
				{
					if (itemPrecedesLetter(itemIdx, linkIdx + 1)) {
						// Item is smaller than the next alphabet, i.e.
						// alphabet <= item < nextAlphabet, link the item to this alphabet
						var alphabet = links[linkIdx];
						scope.targets[alphabet] = scope.getElemId(itemIdx);
	
						// Skip the rest of the items belonging to the same alphabet
						do {
							++itemIdx;
						} while (itemIdx < scope.itemCount
								&& itemPrecedesLetter(itemIdx, linkIdx + 1));
					}
				}
			}

			function setUpGroupedLinks(groupSize) {
				for (var i = 1; i < links.length - groupSize; i += groupSize) {
					var group = links[i] + '-' + links[i+groupSize-1];

					for (var j = 0; j < groupSize; ++j) {
						var alphabet = links[i+j];
						if (alphabet in scope.targets) {
							scope.targets[group] = scope.targets[alphabet];
							break;
						}
					}
				}
			}

			function setUpTargets() {
				setUpMainLinks();
				setUpGroupedLinks(2);
				setUpGroupedLinks(3);
			}
			setUpTargets();

			function onResize(event, appView) {
				// top and bottom padding of 5px each
				var height = appView.height() - 10;

				element.css('height', height);

				if (height < 200) {
					scope.links = linksExtraShort;
					element.find("a").removeClass("dotted");
				} else if (height < 300) {
					scope.links = linksShort;
					element.find("a").removeClass("dotted");
				} else if (height < 450) {
					scope.links = links;
					element.find("a").addClass("dotted");
				} else {
					scope.links = links;
					element.find("a").removeClass("dotted");
				}
				scope.$apply();

				// adapt line-height to spread links over the available height
				element.css('line-height', Math.floor(height/scope.links.length) + 'px');

				// anchor the alphabet navigation to the right edge of the app view
				var appViewRight = document.body.clientWidth - appView.offset().left - appView.innerWidth();
				element.css('right', appViewRight);
			}

			function onPlayerBarShownOrHidden() {
				// React asynchronously so that angularjs bindings have had chance
				// to update the properties of the #app-view element.
				$timeout(function() {
					onResize(null, $('#app-view'));
				});
			}

			// Trigger resize on #app-view resize and player status changes.
			// Trigger re-evaluation of available scroll targets when collection reloaded.
			var unsubscribeFuncs = [
				$rootScope.$on('resize', onResize),
				$rootScope.$watch('started', onPlayerBarShownOrHidden),
				$rootScope.$on('artistsLoaded', setUpTargets)
			];

			// unsubscribe listeners when the scope is destroyed
			scope.$on('$destroy', function () {
				_.each(unsubscribeFuncs, function(func) { func(); });
			});
		}
	};
}]);

/**
 * This directive observes whether the host element is within the view-port or not.
 * When the status changes to either direction, it notifies the registered listeners.
 */
angular.module('Music').directive('inViewObserver', ['$rootScope', '$timeout', 'inViewService',
function($rootScope, $timeout, inViewService) {

	var _instances = []; // in creation order i.e. top-most first
	var _firstIndexInView = 0;
	var _lastIndexInView = -1;
	// tracking the range of visible items reduces the workload when there are a huge number of instances,
	// but it cannot be used while some of the instances may be hidden (e.g. with "display: none")
	var _trackVisibleRange = true;

	// Drop all instances when view switching or artists reloading begins
	$rootScope.$on('deactivateView', eraseInstances);
	$rootScope.$on('artistsUpdating', eraseInstances);

	function eraseInstances() {
		// cancel any pending notifications first
		_(_instances).each(function(inst) {
			if (inst.pendingEnterView) {
				$timeout.cancel(inst.pendingEnterView);
			}
		});

		_instances = [];
		_firstIndexInView = 0;
		_lastIndexInView = -1;
	}

	var throttledOnScroll = _.throttle(onScroll, 50, {leading: false});

	var scrollContainer = OC_Music_Utils.newLayoutStructure() ? document : document.getElementById('app-content');
	scrollContainer.addEventListener('scroll', throttledOnScroll);
	$rootScope.$on('resize', throttledOnScroll);
	$rootScope.$on('trackListCollapsed', throttledOnScroll);
	$rootScope.$on('artistsLoaded', throttledOnScroll);
	$rootScope.$watch('loading', throttledOnScroll);

	$rootScope.$on('inViewObserver_visibilityEvent', function(event, itemsMayBeHidden) {
		_trackVisibleRange = !itemsMayBeHidden;

		resetAll();
		if (_trackVisibleRange) {
			initInViewRange(/*skipDelays=*/true);
		} else {
			updateStatusForAll(/*skipDelays=*/true);
		}
	});

	$rootScope.$on('inViewObserver_revealElement', function(event, element) {
		var inst = _(_instances).find({element: element});

		// cancel any pending "enter view" because it's about to happen immediately
		if (inst.pendingEnterView) {
			$timeout.cancel(inst.pendingEnterView);
			inst.pendingEnterView = null;
			inst.inViewPort = false;
		}

		// nothing to do if the instance is already within the viewport and and notified about it
		if (!inst.inViewPort) {
			onEnterView(inst);
			inst.inViewPort = true;
		}
	});

	var debouncedNotifyLeave = _.debounce(function() {
		_(_instances).each(function(inst) {
			if (inst.leaveViewPending) {
				onLeaveView(inst);
			}
		});
	}, 1000);

	function onScroll() {
		// do not react while the layout building is still ongoing
		if (!$rootScope.loading) {

			if (_trackVisibleRange) {
				if (!validInViewRange()) {
					initInViewRange();
				} else {
					updateInViewRange();
				}
			}
			else {
				updateStatusForAll();
			}

			// leave notifications are post-poned until when the scrolling stops
			debouncedNotifyLeave();
		}
	}

	function validInViewRange() {
		return _firstIndexInView <= _lastIndexInView;
	}

	/**
	 * Initial setup of the in-view-port statuses of the available instances
	 */
	function initInViewRange(skipDelays/*optional*/) {
		var length = _instances.length;
		var i;

		// loop from the begining until we find the first instance in viewport
		for (i = 0; i < length; ++i) {
			if (updateInViewStatus(_instances[i], skipDelays)) {
				_firstIndexInView = i;
				_lastIndexInView = i;
				break;
			}
		}

		// if some instance was found, then continue looping until we have found
		// all the instances in viewport
		for (++i; i < length; ++i) {
			if (updateInViewStatus(_instances[i], skipDelays)) {
				_lastIndexInView = i;
			} else {
				break;
			}
		}
	}

	/**
	 * Update in-view-port status when we have a valid previous in-view-range
	 */
	function updateInViewRange() {
		var prevFirst = _firstIndexInView;
		var prevLast = _lastIndexInView;
		var i;
		var length = _instances.length;

		// Check if instances in the beginning of the range have slided off
		for (i = _firstIndexInView; i <= _lastIndexInView; ++i) {
			if (!updateInViewStatus(_instances[i])) {
				++_firstIndexInView;
			} else {
				break;
			}
		}

		// Check if instances in the end of the range have slided off
		for (i = _lastIndexInView; i > _firstIndexInView; --i) {
			if (!updateInViewStatus(_instances[i])) {
				--_lastIndexInView;
			} else {
				break;
			}
		}

		if (!validInViewRange()) {
			// None of the previous instances were anymore in the view-port.
			// We have lost the track of the scrolling direction and location
			// and have to start from scratch.
			initInViewRange();
		}
		else {
			// There may be more in-view instances above if the first index
			// did not move downwards
			if (prevFirst === _firstIndexInView) {
				for (i = _firstIndexInView - 1; i >= 0; --i) {
					if (updateInViewStatus(_instances[i])) {
						--_firstIndexInView;
					} else {
						break;
					}
				}
			}

			// There may be more in-view instances below if the last index
			// did not move upwards
			if (prevLast === _lastIndexInView) {
				for (i = _lastIndexInView + 1; i < length; ++i) {
					if (updateInViewStatus(_instances[i])) {
						++_lastIndexInView;
					} else {
						break;
					}
				}
			}
		}
	}

	/**
	 * Update in-view-port status of the given instance
	 */
	function updateInViewStatus(inst, skipDelays/*optional*/) {
		skipDelays = skipDelays || false;

		var wasInViewPort = inst.inViewPort;
		inst.inViewPort = instanceInViewPort(inst) && !instanceIsInvisible(inst);

		if (!wasInViewPort && inst.inViewPort) {
			if (!inst.leaveViewPending) {
				// element entered the viewport, notify the listeners with small delay,
				// unless immediate action has been requested
				if (skipDelays) {
					onEnterView(inst);
				} else {
					inst.pendingEnterView = $timeout(onEnterView, 250, true, inst);
				}
			}
			inst.leaveViewPending = false;
		}
		else if (wasInViewPort && !inst.inViewPort) {
			if (inst.pendingEnterView) {
				// element left the viewport before onEnterView was called, cancel the pending call
				$timeout.cancel(inst.pendingEnterView);
				inst.pendingEnterView = null;
			}
			else {
				// element left the viewport after it had been notified that it has entered the view
				if (skipDelays) {
					onLeaveView(inst);
				} else {
					inst.leaveViewPending = true;
				}
			}
		}

		return inst.inViewPort;
	}

	function instanceInViewPort(inst) {
		var margin = inst.viewPortMargin;
		return inViewService.isElementInViewPort(inst.element, margin, margin);
	}

	function instanceIsInvisible(inst) {
		var el = inst.element;
		// IE uses currentStyle, all the other browsers the getComputedStyle
		return el.currentStyle
			? (el.currentStyle.display == 'none')
			: (getComputedStyle(el, null).display == 'none');
	}

	function onEnterView(inst) {
		inst.pendingEnterView = null;

		if (!instanceIsInvisible(inst)) {
			_(inst.listeners).each(function(listener) {
				listener.onEnterView();
			});
		}
	}

	function onLeaveView(inst) {
		inst.leaveViewPending = false;
		_(inst.listeners).each(function(listener) {
			listener.onLeaveView();
		});
	}

	function resetAll() {
		_(_instances).each(function(inst) {
			if (inst.pendingEnterView) {
				$timeout.cancel(inst.pendingEnterView);
				inst.pendingEnterView = null;
			}
			if (!instanceIsInvisible(inst)) {
				onLeaveView(inst);
				inst.inViewPort = false;
			}
		});
		_firstIndexInView = 0;
		_lastIndexInView = -1;
	}

	function updateStatusForAll(skipDelays/*optional*/) {
		_(_instances).each(function(inst) {
			updateInViewStatus(inst, skipDelays);
		});
	}

	return {
		scope: {},
		controller: function($scope, $element) {
			this.inViewPort = false;
			this.leaveViewPending = false;
			this.pendingEnterView = null;
			this.element = $element[0];
			this.listeners = [];

			/**
			 * Listener must have two function-type properties: onEnterView and onLeaveView
			 */
			this.registerListener = function(listener) {
				this.listeners.push(listener);
			};

			_instances.push(this);
		},
		link: function(scope, element, attributes, controller) {
			controller.viewPortMargin = Number(attributes.inViewObserverMargin) || 500;

			// Remove this instance from the static array if this would still be there upon destruction.
			// This seems to happen when the album view contents are updated during/after scanning.
			scope.$on('$destroy', function() {
				var index = _instances.indexOf(controller);
				if (index !== -1) {
					_instances.splice(index, 1);
				}
			});

			// The visibilites should be evaluated after all the ng-repeated instances
			// have been linked. There may be no actual `scroll` or `resize` events after
			// page load, in case there's so few items that no scrollbar appears.
			if (scope.$parent.$last && !$rootScope.loading) {
				throttledOnScroll();
			}
		}
	};
}]);

/**
 * This custom directive produces a self-contained list heading widget which
 * is able to lazy-load its contents only when it is about to enter the viewport.
 * Respectively, contents are cleared when the widget leaves the viewport.
 */

angular.module('Music').directive('listHeading', ['$rootScope', '$timeout', 'gettextCatalog',
function ($rootScope, $timeout, gettextCatalog) {

	var playText = gettextCatalog.getString('Play');
	var playIconSrc = OC.imagePath('music','play-big.svg');
	var detailsText = gettextCatalog.getString('Details');

	/**
	 * Set up the contents for a given heading element
	 */
	function setup(data) {
		/**
		 * Remove any placeholder and add the proper content
		 */
		removeChildNodes(data.element);
		data.element.appendChild(render());

		/**
		 * Create the contained HTML elements
		 */
		function render() {
			var fragment = document.createDocumentFragment();

			var outerSpan = document.createElement('span');
			outerSpan.setAttribute('draggable', true);
			if (data.tooltip) {
				outerSpan.setAttribute('title', data.tooltip);
			}

			var innerSpan = document.createElement('span');
			innerSpan.innerHTML = data.heading;
			outerSpan.appendChild(innerSpan);

			if (data.headingExt) {
				var extSpan = document.createElement('span');
				extSpan.className = 'muted';
				extSpan.innerHTML = data.headingExt;
				outerSpan.appendChild(extSpan);
			}

			if (data.showPlayIcon) {
				var playIcon = document.createElement('img');
				playIcon.className = 'play svg';
				playIcon.setAttribute('alt', playText);
				playIcon.setAttribute('src', playIconSrc);
				outerSpan.appendChild(playIcon);
			}

			fragment.appendChild(outerSpan);

			if (data.onDetailsClick) {
				var detailsButton = document.createElement('button');
				detailsButton.className = 'icon-details';
				detailsButton.setAttribute('title', detailsText);
				fragment.appendChild(detailsButton);
			}

			return fragment;
		}

		var ngElem = $(data.element);

		/**
		 * Click handlers
		 */
		ngElem.on('click', 'span', function(e) {
			data.onClick(data.model);
		});
		ngElem.on('click', 'button', function(e) {
			data.onDetailsClick(data.model);
		});

		/**
		 * Drag&Drop compatibility
		 */
		ngElem.on('dragstart', 'span', function(e) {
			if (e.originalEvent) {
				e.dataTransfer = e.originalEvent.dataTransfer;
			}
			var offset = {x: e.offsetX, y: e.offsetY};
			var transferDataObject = {
				data: data.getDraggable(data.model),
				channel: 'defaultchannel',
				offset: offset
			};
			var transferDataText = angular.toJson(transferDataObject);
			e.dataTransfer.setData('text', transferDataText);
			e.dataTransfer.effectAllowed = 'copyMove';
			$rootScope.$broadcast('ANGULAR_DRAG_START', e, 'defaultchannel', transferDataObject);
		});

		ngElem.on('dragend', 'span', function(e) {
			$rootScope.$broadcast('ANGULAR_DRAG_END', e, 'defaultchannel');
		});

		data.scope.$on('$destroy', function() {
			tearDown(data);
		});
	}

	function tearDown(data) {
		$(data.element).off();
	}

	function setupPlaceholder(data) {
		data.element.innerHTML = data.heading;
	}

	/**
	 * Helper to remove all child nodes from an HTML element
	 */
	function removeChildNodes(htmlElem) {
		while (htmlElem.firstChild) {
			htmlElem.removeChild(htmlElem.firstChild);
		}
	}

	return {
		restrict: 'E',
		require: '^inViewObserver',
		compile: function(tmplElement, tmplAttrs) {
			// Replace the <list-heading> element with <h?> element of desired size
			var hElem = document.createElement('h' + (tmplAttrs.level || '1'));
			tmplElement.replaceWith(hElem);

			return {
				post: function(scope, element, attrs, controller) {
					var data = {
						heading: scope.$eval(attrs.heading),
						headingExt: scope.$eval(attrs.headingExt),
						tooltip: scope.$eval(attrs.tooltip),
						showPlayIcon: scope.$eval(attrs.showPlayIcon),
						model: scope.$eval(attrs.model),
						onClick: scope.$eval(attrs.onClick),
						onDetailsClick: scope.$eval(attrs.onDetailsClick),
						getDraggable: scope.$eval(attrs.getDraggable),
						element: element[0],
						scope: scope
					};

					// Populate the heading first with a placeholder.
					// The placeholder is replaced with the actual content once the element
					// enters the viewport (with some margins).
					setupPlaceholder(data);

					controller.registerListener({
						onEnterView: function() {
							setup(data);
						},
						onLeaveView: function() {
							tearDown(data);
							setupPlaceholder(data);
						}
					});
				}
			};
		}
	};
}]);

angular.module('Music').directive('navigationItem', function() {
	return {
		scope: {
			text: '=',
			destination: '=',
			playlist: '='
		},
		templateUrl: 'navigationitem.html',
		replace: true
	};
});

angular.module('Music').directive('ngEnter', function () {
	return function (scope, element, attrs) {
		element.bind("keydown keypress", function (event) {
			if(event.which === 13) {
				scope.$apply(function (){
					scope.$eval(attrs.ngEnter);
				});
				event.preventDefault();
			}
		});
	};
});

angular.module('Music').directive('resizeNotifier', ['$rootScope', function($rootScope) {
	return function(scope, element, attrs, ctrl) {
		element.resize(function() {
			$rootScope.$emit('resize', element);
		});
	};
}]);

/**
 * This custom directive produces a self-contained track list widget that updates
 * its list items according to the global playback state and user interaction.
 * Handling this with markup alone would produce a large amount of watchers.
 * 
 * The directive also contains a lazy-loading logic: The list is not populated
 * with track item entries, and no listeners are registered before the list instance
 * in question is scrolled to the viewport. Respectively, the list item elements are
 * removed and listeners de-registered once the list instance leaves the viewport.
 */

angular.module('Music').directive('trackList', ['$rootScope', '$interpolate', '$timeout', 'gettextCatalog',
function ($rootScope, $interpolate, $timeout, gettextCatalog) {

	var trackTemplate = '<div class="play-pause"></div>' +
		'<span class="muted">{{ number ? number + ".&nbsp;" : "" }}</span>' +
		'<span title="{{ tooltip }}">{{ title }}</span>';
	var trackRenderer = $interpolate(trackTemplate);

	// Localized strings
	var lessText = gettextCatalog.getString('Show less …');
	var detailsText = gettextCatalog.getString('Details');
	var moreText = function(count) {
		return gettextCatalog.getString('Show all {{ count }} songs …', { count: count });
	};

	// Search support
	var searchModeTrackMatches = null;
	$rootScope.$on('searchMatchedTracks', function(event, matchingTracks) {
		// store only the IDs of the matching tracks; store them in sorted array
		// to enable binary search
		searchModeTrackMatches = _(matchingTracks).pluck('id');
		searchModeTrackMatches.sort(function(a,b) { return a - b; });
	}); 
	$rootScope.$on('searchOff', function() {
		searchModeTrackMatches = null;
	}); 
	function inSearchMode() {
		return searchModeTrackMatches !== null;
	}
	function trackMatchedInSearch(trackId) {
		return _.indexOf(searchModeTrackMatches, trackId, true) !== -1;
	}

	function trackIdFromElementId(elemId) {
		if (elemId && elemId.substring(0, 6) === 'track-') {
			return parseInt(elemId.split('-')[1]);
		} else {
			return null;
		}
	}

	/**
	 * Set up the track items and the listeners for a given <ul> element
	 */
	function setup(data) {
		data.listeners = [
			data.scope.$watch('currentTrack', updateClasses),
			$rootScope.$watch('playing', updateClasses)
		];

		var htmlElem = data.element[0];

		/**
		 * Remove any placeholder and add the nested <li> elements for each shown track.
		 */
		removeChildNodes(htmlElem);
		htmlElem.appendChild(renderTrackList());

		if (data.expanded || inSearchMode()) {
			renderHiddenTracks();
		}

		/**
		 * Set classes of the track items according to current scope
		 */
		function updateClasses() {
			var elems = htmlElem.querySelectorAll(".playing, .current");
			_(elems).each(function (el) {
				el.classList.remove('current');
				el.classList.remove('playing');
			});

			if (data.scope.currentTrack) {
				var currentTrack = htmlElem.querySelector('#track-' + data.scope.currentTrack.id);
				if (currentTrack) {
					currentTrack.classList.add('current');
					if ($rootScope.playing) {
						currentTrack.classList.add('playing');
					} else {
						currentTrack.classList.remove('playing');
					}
				}
			}
		}

		/**
		 * Create the list of individual tracks. Skips after reaching the "toggle threshold"
		 * so only tracks that are initially visible are actually being rendered
		 *
		 * @returns {DocumentFragment}
		 */
		function renderTrackList() {
			var trackListFragment = document.createDocumentFragment();

			var tracksToShow = data.tracks.length;
			if (tracksToShow > data.collapseLimit) {
				tracksToShow = data.collapseLimit - 1;
			}

			for (var i = 0; i < tracksToShow; i++) {
				trackListFragment.appendChild(getTrackNode(data.tracks[i], i));
			}

			if (data.tracks.length > data.collapseLimit) {
				var lessEl = document.createElement('li');
				var moreEl = document.createElement('li');

				lessEl.innerHTML = lessText;
				lessEl.className = 'muted more-less collapsible';
				moreEl.innerHTML = moreText(data.tracks.length);
				moreEl.className = 'muted more-less';
				trackListFragment.appendChild(lessEl);
				trackListFragment.appendChild(moreEl);
			}
			return trackListFragment;
		}

		/**
		 * Renders a single Track HTML Node
		 *
		 * @param object track
		 * @param int index
		 * @param string className (optional)
		 * @returns {HTMLLIElement}
		 */
		function getTrackNode(track, index, className) {
			var listItem = document.createElement('li');

			var listItemContent = document.createElement('div');
			var trackData = data.getTrackData(track, index, data.scope);
			listItemContent.innerHTML = trackRenderer(trackData);
			listItemContent.setAttribute('draggable', true);
			listItem.appendChild(listItemContent);

			var detailsButton = document.createElement('button');
			detailsButton.className = 'icon-details';
			detailsButton.title = detailsText;
			listItem.appendChild(detailsButton);

			listItem.id = 'track-' + trackData.id;
			if (className) {
				listItem.className = className;
			}

			if (inSearchMode()) {
				if (trackMatchedInSearch(trackData.id)) {
					listItem.className += ' matched';
				}
			}

			return listItem;
		}

		/**
		 * Adds those tracks that aren't initially visible to the element
		 */
		function renderHiddenTracks() {
			if (data.collapseLimit < data.tracks.length) {
				var trackListFragment = document.createDocumentFragment();

				for (var i = data.collapseLimit - 1; i < data.tracks.length; i++) {
					trackListFragment.appendChild(getTrackNode(data.tracks[i], i, 'collapsible'));
				}
				var toggle = htmlElem.getElementsByClassName('muted more-less collapsible');
				htmlElem.insertBefore(trackListFragment, toggle[0]);

				updateClasses();

				data.hiddenTracksRendered = true;
			}
		}

		/**
		 * Click handler for list items
		 */
		data.element.on('click', 'li', function(event) {
			var trackId = trackIdFromElementId(this.id);
			if (trackId) {
				if (event.target.className == 'icon-details') {
					data.showTrackDetails(trackId);
				} else {
					data.playTrack(trackId);
					data.scope.$apply();
				}
			}
			else { // "show more/less" item
				if (!data.hiddenTracksRendered) {
					renderHiddenTracks();
				}
				data.expanded = !data.expanded;
				data.element.toggleClass('collapsed');
			}
		});

		/**
		 * Drag&Drop compatibility
		 */
		data.element.on('dragstart', 'li', function(e) {
			if (e.originalEvent) {
				e.dataTransfer = e.originalEvent.dataTransfer;
			}
			var trackId = trackIdFromElementId(this.id);
			var offset = {x: e.offsetX, y: e.offsetY};
			var transferDataObject = {
				data: data.getDraggable(trackId),
				channel: 'defaultchannel',
				offset: offset
			};
			var transferDataText = angular.toJson(transferDataObject);
			e.dataTransfer.setData('text', transferDataText);
			e.dataTransfer.effectAllowed = 'copyMove';
			$rootScope.$broadcast('ANGULAR_DRAG_START', e, 'defaultchannel', transferDataObject);
		});

		data.element.on('dragend', 'li', function (e) {
			$rootScope.$broadcast('ANGULAR_DRAG_END', e, 'defaultchannel');
		});

		data.scope.$on('$destroy', function() {
			tearDown(data);
		});
	}

	/**
	 * Tear down a given <ul> element, removing all child nodes and unsubscribing any listeners
	 */
	function tearDown(data) {
		if (data.listeners !== null) {
			data.element.off();
			_(data.listeners).each(function(lstnr) {
				lstnr();
			});
			data.listeners = null;
		}
	}

	/**
	 * Setup a placeholder list item within the given <ul> element
	 */
	function setupPlaceholder(data) {
		data.hiddenTracksRendered = false;
		removeChildNodes(data.element[0]);

		var height = estimateContentsHeight(data);
		placeholder = document.createElement('li');
		placeholder.style.height = height + 'px';
		placeholder.className = 'placeholder';
		data.element[0].appendChild(placeholder);
	}

	/**
	 * Estimate the total height needed for the <li> entries of the track list element
	 */
	function estimateContentsHeight(data) {
		var rowCount = 0;

		// During search, all matched tracks are shown
		if (inSearchMode()) {
			for (var i = 0; i < data.tracks.length; ++i) {
				var trackData = data.getTrackData(data.tracks[i], i, data.scope);
				if (trackMatchedInSearch(trackData.id)) {
					rowCount++;
				}
			}
		}
		// Otherwise, the non-collapsed tracks are shown
		else {
			if (data.expanded) {
				rowCount = data.tracks.length + 1; // all tracks + "Show less"
			} else {
				rowCount = Math.min(data.tracks.length, data.collapseLimit);
			}
		}
		return 31.4833 * rowCount;
	}

	/**
	 * Helper to remove all child nodes from an HTML element
	 */
	function removeChildNodes(htmlElem) {
		while (htmlElem.firstChild) {
			htmlElem.removeChild(htmlElem.firstChild);
		}
	}

	return {
		restrict: 'E',
		template: '<ul class="track-list collapsed"></ul>',
		replace: true,
		require: '?^inViewObserver',
		link: function(scope, element, attrs, controller) {
			var data = {
				expanded: false,
				hiddenTracksRendered: false,
				tracks: scope.$eval(attrs.tracks),
				getTrackData: scope.$eval(attrs.getTrackData),
				playTrack: scope.$eval(attrs.playTrack),
				showTrackDetails: scope.$eval(attrs.showTrackDetails),
				getDraggable: scope.$eval(attrs.getDraggable),
				collapseLimit: attrs.collapseLimit || 999999,
				listeners: null,
				scope: scope,
				element: element
			};

			// In case this directive has inViewObserver as ancestor, populate it first
			// with a placeholder. The placeholder is replaced with the actual content
			// once the element enters the viewport (with some margins).
			if (controller) {
				setupPlaceholder(data);

				controller.registerListener({
					onEnterView: function() {
						setup(data);
					},
					onLeaveView: function() {
						tearDown(data);
						setupPlaceholder(data);
					}
				});
			}
			// Otherwise, populate immediately with the actual content
			else {
				setup(data);
			}
		}
	};
}]);

angular.module('Music').factory('ArtistFactory', ['Restangular', '$rootScope', function (Restangular, $rootScope) {
	return {
		getArtists: function() {
			return Restangular.all('prepare_collection').post().then(function(reply) {
				return Restangular.all('collection').getList({hash: reply.hash});
			});
		}
	};
}]);

angular.module('Music').factory('Audio', ['$rootScope', function ($rootScope) {
	return new PlayerWrapper();
}]);

angular.module('Music').factory('Token', [function () {
	return document.getElementsByTagName('head')[0].getAttribute('data-requesttoken');
}]);

angular.module('Music').filter('playTime', function() {
	return function(input) {
		var minutes = Math.floor(input/60),
			seconds = Math.floor(input - (minutes * 60));
		return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
	};
});
angular.module('Music').service('alphabetIndexingService', [function() {

	var _indexChars = [
		'#', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
		'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '…'
	];

	function _isVariantOfZ(char) {
		return ('Zz\u017A\u017B\u017C\u017D\u017E\u01B5\u01B6\u0224\u0225\u0240\u1E90\u1E91\u1E92'
			+ '\u1E93\u1E94\u1E95\u24CF\u24E9\u2C6B\u2C6C\uA762\uA763\uFF3A\uFF5A').indexOf(char) >= 0;
	}

	return {
		indexChars: function() {
			return _indexChars;
		},

		titlePrecedesIndexCharAt: function(title, charIdx) {
			var initialChar = title.substr(0,1).toUpperCase();

			// Special case: '…' is considered to be larger than Z or any of its variants
			// but equal to any other character greater than Z
			if (_indexChars[charIdx] === '…') {
				return _isVariantOfZ(initialChar) || this.titlePrecedesIndexCharAt(title, charIdx-1);
			} else {
				return initialChar.localeCompare(_indexChars[charIdx]) < 0;
			}
		},

		indexCharForTitle: function(title) {
			for (var i = 0; i < _indexChars.length - 1; ++i) {
				if (this.titlePrecedesIndexCharAt(title, i+1)) {
					return _indexChars[i];
				}
			}
			return '…';
		}
	};
}]);

angular.module('Music').service('inViewService', ['$rootScope', function($rootScope) {

	var dirty = true;
	var headerHeight = null;
	var appViewHeight = null;

	$rootScope.$on('resize', function() {
		dirty = true;
	});

	function updateHeights() {
		var appView = document.getElementById('app-view');
		var header = document.getElementById('header');

		headerHeight = header.offsetHeight;
		appViewHeight = appView.offsetHeight;

		dirty = false;
	}

	return {
		/**
		 * Check if the given element is within the viewport, optionally defining
		 * margins which effectively enlarge (or shrink) the area where the element
		 * is considered to be "within viewport".
		 * @param el And HTML element
		 * @param int topMargin Optional top extension in pixels (use negative value for reduction)
		 * @param int bottomMargin Optional bottom extension in pixels (use negative value for reduction)
		 */
		isElementInViewPort: function(el, topMargin/*optional*/, bottomMargin/*optional*/) {
			if (el) {
				topMargin = topMargin || 0;
				bottomMargin = bottomMargin || 0;

				if (dirty) {
					updateHeights();
				}

				var viewPortTop = headerHeight - topMargin;
				var viewPortBottom = headerHeight + appViewHeight + bottomMargin;

				var rect = el.getBoundingClientRect();
				return rect.bottom >= viewPortTop && rect.top <= viewPortBottom;
			}
			else {
				return false;
			}
		}
	};
}]);

angular.module('Music').service('libraryService', ['$rootScope', function($rootScope) {

	var artists = null;
	var albums = null;
	var tracksIndex = {};
	var tracksInAlbumOrder = null;
	var tracksInAlphaOrder = null;
	var tracksInFolderOrder = null;
	var tracksInGenreOrder = null;
	var playlists = null;
	var folders = null;
	var genres = null;

	/** 
	 * Sort array according to a specified text field.
	 * Note:  The exact ordering is browser-dependant and usually affected by the browser language.
	 * Note2: The array is sorted in-place instead of returning a new array.
	 */
	function sortByTextField(items, field) {
		items.sort(function(a, b) {
			return a[field].localeCompare(b[field]);
		});
	}

	/**
	 * Like sortByTextField but to be used with arrays of playlist entries where
	 * field is within outer field "track".
	 */
	function sortByPlaylistEntryField(items, field) {
		items.sort(function(a, b) {
			return a.track[field].localeCompare(b.track[field]);
		});
	}

	function sortByYearAndName(aAlbums) {
		sortByTextField(aAlbums, 'name');
		aAlbums = _.sortBy(aAlbums, 'year');
		return aAlbums;
	}

	function sortByDiskNumberAndTitle(tracks) {
		sortByTextField(tracks, 'title');
		tracks = _.sortBy(tracks, 'number');
		tracks = _.sortBy(tracks, 'disk');
		return tracks;
	}

	/**
	 * Sort the passed in collection alphabetically, and set up parent references
	 */
	function transformCollection(collection) {
		sortByTextField(collection, 'name');
		_.forEach(collection, function(artist) {
			artist.albums = sortByYearAndName(artist.albums);
			_.forEach(artist.albums, function(album) {
				album.artist = artist;
				album.tracks = sortByDiskNumberAndTitle(album.tracks);
				_.forEach(album.tracks, function(track) {
					track.album = album;
				});
			});
		});
		return collection;
	}

	function moveArrayElement(array, from, to) {
		array.splice(to, 0, array.splice(from, 1)[0]);
	}

	function playlistEntry(track) {
		return { track: track };
	}

	function playlistEntryFromId(trackId) {
		return playlistEntry(tracksIndex[trackId]);
	}

	function wrapPlaylist(playlist) {
		return {
			id: playlist.id,
			name: playlist.name,
			tracks: _.map(playlist.trackIds, playlistEntryFromId)
		};
	}

	function wrapFolder(folder) {
		var wrapped = wrapPlaylist(folder);
		wrapped.path = folder.path;
		return wrapped;
	}

	function createTrackContainers() {
		// album order "playlist"
		var tracks = _.flatten(_.pluck(albums, 'tracks'));
		tracksInAlbumOrder = _.map(tracks, playlistEntry);

		// alphabetic order "playlist"
		sortByTextField(tracks, 'title');
		sortByTextField(tracks, 'artistName');
		tracksInAlphaOrder = _.map(tracks, playlistEntry);

		// tracks index
		_.forEach(tracks, function(track) {
			tracksIndex[track.id] = track;
		});
	}

	var diacriticRegExp = /[\u0300-\u036f]/g;
	/** Convert string to "folded" form suitable for fuzzy matching */
	function foldString(str) {
		if (str) {
			str = str.toLocaleLowerCase();

			// Skip the normalization if the browser is ancient and doesn't support it
			if ('normalize' in String.prototype) {
				str = str.normalize('NFD').replace(diacriticRegExp, "");
			}
		}

		return str;
	}

	/** Split search query to array by whitespace.
	 *  As an exception, quoted substrings are kept as one entity. The quotation marks are removed.
	 */
	function splitSearchQuery(query) {
		var regExQuoted = /\".*?\"/g;

		// Get any quoted substring. Also the quotation marks get extracted, and they are sliced off separately.
		var quoted = query.match(regExQuoted) || [];
		quoted = _.map(quoted, function(str) {
			return str.slice(1, -1);
		});

		// remove the quoted substrings and stray quotation marks, and extact the rest of the parts
		query = query.replace(regExQuoted, ' ');
		query = query.replace('"', ' ');
		var unquoted = query.match(/\S+/g) || [];

		return quoted.concat(unquoted);
	}

	function objectFieldsContainAll(object, getFieldValueFuncs, subStrings) {
		return _.every(subStrings, function(subStr) {
			return _.some(getFieldValueFuncs, function(getter) {
				var value = getter(object);
				return (value !== null && foldString(value).indexOf(subStr) !== -1);
			});
		});
	}

	function fieldPathToGetterFunc(path) {
		// On the newest underscore.js, this could be achieved with 
		// return _.property(path.split('.'));
		// but the cloud core may ship so old underscore.js that property method doesn't support nesting.
		// The following is a modified copy from the up-to-date sources of underscore.js.
		path = path.split('.');
		return function(obj) {
			for (var i = 0, length = path.length; i < length; i++) {
				if (obj === null) {
					return null;
				}
				obj = obj[path[i]];
			}
			return length ? obj : null;
		};
	}

	function search(container, fields, query, maxResults/*optional*/) {
		maxResults = maxResults || Infinity;

		query = foldString(query);
		// In case the query contains many words separated with whitespace, each part
		// has to be found but the whitespace is disregarded.
		var queryParts = splitSearchQuery(query);

		// @a fields may be an array or an idividual string
		if (!Array.isArray(fields)) {
			fields = [fields];
		}

		// Field may be given as a '.'-separated path;
		// convert the fields to corresponding getter functions.
		var fieldGetterFuncs = _.map(fields, fieldPathToGetterFunc);

		var matchCount = 0;
		var maxLimitReached = false;
		var matches = _.filter(container, function(item) {
			var matched = !maxLimitReached && objectFieldsContainAll(item, fieldGetterFuncs, queryParts);
			if (matched && matchCount++ == maxResults) {
				maxLimitReached = true;
				matched = false;
			}
			return matched;
		});

		return {
			result: matches,
			truncated: maxLimitReached
		};
	}

	return {
		setCollection: function(collection) {
			artists = transformCollection(collection);
			albums = _.flatten(_.pluck(artists, 'albums'));
			createTrackContainers();
		},
		setPlaylists: function(lists) {
			playlists = _.map(lists, wrapPlaylist);
		},
		setFolders: function(folderData) {
			if (!folderData) {
				folders = null;
				tracksInFolderOrder = null;
			} else {
				folders = _.map(folderData, wrapFolder);
				sortByTextField(folders, 'name');
				// the tracks within each folder are sorted by the file name by the back-end 
				_.forEach(folders, function(folder) {
					_.forEach(folder.tracks, function(trackEntry) {
						trackEntry.track.folder = folder;
					});
				});
				tracksInFolderOrder = _.flatten(_.pluck(folders, 'tracks'));
			}
		},
		setGenres: function(genreData) {
			if (!genreData) {
				genres = null;
				tracksInGenreOrder = null;
			} else {
				genres = _.map(genreData, wrapPlaylist);
				sortByTextField(genres, 'name');
				// if the first item after sorting is the unknown genre (empty string),
				// then move it to the end of the list
				if (genres.length > 0 && genres[0].name === '') {
					genres.push(genres.shift());
				}

				_.forEach(genres, function(genre) {
					sortByPlaylistEntryField(genre.tracks, 'title');
					sortByPlaylistEntryField(genre.tracks, 'artistName');

					_.forEach(genre.tracks, function(trackEntry) {
						trackEntry.track.genre = genre;
					});
				});

				tracksInGenreOrder = _.flatten(_.pluck(genres, 'tracks'));
			}
		},
		addPlaylist: function(playlist) {
			playlists.push(wrapPlaylist(playlist));
		},
		removePlaylist: function(playlist) {
			playlists.splice(playlists.indexOf(playlist), 1);
		},
		addToPlaylist: function(playlistId, trackId) {
			var playlist = this.getPlaylist(playlistId);
			playlist.tracks.push(playlistEntryFromId(trackId));
		},
		removeFromPlaylist: function(playlistId, indexToRemove) {
			var playlist = this.getPlaylist(playlistId);
			playlist.tracks.splice(indexToRemove, 1);
		},
		reorderPlaylist: function(playlistId, srcIndex, dstIndex) {
			var playlist = this.getPlaylist(playlistId);
			moveArrayElement(playlist.tracks, srcIndex, dstIndex);
		},
		getArtist: function(id) {
			return _.findWhere(artists, { id: Number(id) });
		},
		getAllArtists: function() {
			return artists;
		},
		getAlbum: function(id) {
			return _.findWhere(albums, { id: Number(id) });
		},
		getAlbumCount: function() {
			return albums ? albums.length : 0;
		},
		getTrack: function(id) {
			return tracksIndex[id];
		},
		getTracksInAlphaOrder: function() {
			return tracksInAlphaOrder;
		},
		getTracksInAlbumOrder: function() {
			return tracksInAlbumOrder;
		},
		getTracksInFolderOrder: function() {
			return tracksInFolderOrder;
		},
		getTracksInGenreOrder: function() {
			return tracksInGenreOrder;
		},
		getTrackCount: function() {
			return tracksInAlphaOrder ? tracksInAlphaOrder.length : 0;
		},
		getPlaylist: function(id) {
			return _.findWhere(playlists, { id: Number(id) });
		},
		getAllPlaylists: function() {
			return playlists;
		},
		getFolder: function(id) {
			return _.findWhere(folders, { id: Number(id) });
		},
		getAllFolders: function() {
			return folders;
		},
		getGenre: function(id) {
			return _.findWhere(genres, { id: Number(id) });
		},
		getAllGenres: function() {
			return genres;
		},
		findTracksByArtist: function(artistId) {
			return _.filter(tracksIndex, {artistId: Number(artistId)});
		},
		collectionLoaded: function() {
			return artists !== null;
		},
		playlistsLoaded: function() {
			return playlists !== null;
		},
		foldersLoaded: function() {
			return folders !== null;
		},
		genresLoaded: function() {
			return genres !== null;
		},
		searchTracks: function(query, maxResults/*optional*/) {
			return search(tracksIndex, ['title', 'artistName'], query, maxResults);
		},
		searchTracksInAlbums: function(query, maxResults/*optional*/) {
			return search(
					tracksIndex,
					['title', 'artistName', 'album.name', 'album.year', 'album.artist.name'],
					query,
					maxResults);
		},
		searchTracksInFolders: function(query, maxResults/*optional*/) {
			return search(
					tracksIndex,
					['title', 'artistName', 'folder.path'],
					query,
					maxResults);
		},
		searchTracksInGenres: function(query, maxResults/*optional*/) {
			return search(
					tracksIndex,
					['title', 'artistName', 'genre.name'],
					query,
					maxResults);
		},
		searchTracksInPlaylist: function(playlistId, query, maxResults/*optional*/) {
			var list = this.getPlaylist(playlistId) || [];
			list = _.pluck(list.tracks, 'track');
			list = _.uniq(list);
			return search(list, ['title', 'artistName'], query, maxResults);
		},
	};
}]);

angular.module('Music').service('playlistService', ['$rootScope', function($rootScope) {
	var playlist = null;
	var playlistId = null;
	var playOrder = [];
	var playOrderIter = -1;
	var startFromIndex = null;
	var shuffle = false;
	var repeat = false;
	var prevShuffleState = false;

	function shuffledIndices() {
		var indices = _.range(playlist.length);
		return _.shuffle(indices);
	}

	function shuffledIndicesExcluding(toExclude) {
		var indices = _.range(playlist.length);
		indices.splice(toExclude, 1);
		return _.shuffle(indices);
	}

	function wrapIndexToStart(list, index) {
		if (index > 0) {
			// slice array in two parts and interchange them
			var begin = list.slice(0, index);
			var end = list.slice(index);
			list = end.concat(begin);
		}
		return list;
	}

	function enqueueIndices() {
		var nextIndices = null;

		if (shuffle) {
			if (startFromIndex !== null) {
				nextIndices = [startFromIndex].concat(shuffledIndicesExcluding(startFromIndex));
			} else {
				nextIndices = shuffledIndices();
			}
			// if the next index ended up to be tha same as the pervious one, flip
			// it to the end of the order
			if (playlist.length > 1 && _.last(playOrder) == _.first(nextIndices)) {
				nextIndices = wrapIndexToStart(nextIndices, 1);
			}
		}
		else {
			nextIndices = _.range(playlist.length);
			if (startFromIndex !== null) {
				nextIndices = wrapIndexToStart(nextIndices, startFromIndex);
			}
		}

		playOrder = playOrder.concat(nextIndices);
		prevShuffleState = shuffle;
	}

	// drop the planned play order but preserve the history
	function dropFuturePlayOrder() {
		playOrder = _.first(playOrder, playOrderIter + 1);
	}

	function insertMany(hostArray, targetIndex, insertedItems) {
		hostArray.splice.apply(hostArray, [targetIndex, 0].concat(insertedItems));
	}

	return {
		setShuffle: function(state) {
			shuffle = state;
		},
		setRepeat: function(state) {
			repeat = state;
		},
		getCurrentIndex: function() {
			return (playOrderIter >= 0) ? playOrder[playOrderIter] : null;
		},
		getCurrentPlaylistId: function() {
			return playlistId;
		},
		getCurrentPlaylist: function() {
			return playlist;
		},
		jumpToPrevTrack: function() {
			if (playlist && playOrderIter > 0) {
				--playOrderIter;
				var track = playlist[this.getCurrentIndex()];
				this.publish('trackChanged', track);
				return track;
			}
			return null;
		},
		jumpToNextTrack: function() {
			if (playlist === null || playOrder === null) {
				return null;
			}

			// check if shuffle state has changed after the play order was last updated
			if (shuffle != prevShuffleState) {
				dropFuturePlayOrder();
				startFromIndex = playOrder[playOrderIter];
				playOrder = _.initial(playOrder); // drop also current index as it will be readded on next step
				enqueueIndices();
			}

			++playOrderIter;

			// check if we have run to the end of the enqueued tracks
			if (playOrderIter >= playOrder.length) {
				if (repeat) { // start another round
					enqueueIndices();
				} else { // we are done
					this.clearPlaylist();
					return null;
				}
			}

			var track = playlist[this.getCurrentIndex()];
			this.publish('trackChanged', track);
			return track;
		},
		setPlaylist: function(listId, pl, startIndex /*optional*/) {
			playlist = pl.slice(); // copy
			startFromIndex = (startIndex === undefined) ? null : startIndex;
			if (listId === playlistId) {
				// preserve the history if list wasn't actually changed
				dropFuturePlayOrder();
			} else {
				// drop the history if list changed
				playOrder = [];
				playOrderIter = -1; // jumpToNextTrack will move this to first valid index
				playlistId = listId;
				this.publish('playlistChanged', playlistId);
			}
			enqueueIndices();
		},
		clearPlaylist: function() {
			playOrderIter = -1;
			playlist = null;
			playlistId = null;
			this.publish('playlistEnded');
		},
		onPlaylistModified: function(pl, currentIndex) {
			var currentTrack = playlist[this.getCurrentIndex()];
			// check if the track being played is still available in the list
			if (pl[currentIndex] === currentTrack) {
				// re-init the play-order, erasing any history data
				playlist = pl.slice(); // copy
				startFromIndex = currentIndex;
				playOrder = [];
				enqueueIndices();
				playOrderIter = 0;
			}
			// if not, then we no longer have a valid list position
			else {
				playlist = null;
				playlistId = null;
				playOrder = null;
				playOrderIter = -1;
			}
			this.publish('trackChanged', currentTrack);
		},
		onTracksAdded: function(newTracks) {
			var prevListSize = playlist.length;
			playlist = playlist.concat(newTracks);
			var newIndices = _.range(prevListSize, playlist.length);
			if (prevShuffleState) {
				// Shuffle the new tracks with the remaining tracks on the list
				var remaining = _.tail(playOrder, playOrderIter+1);
				remaining = _.shuffle(remaining.concat(newIndices));
				playOrder = _.first(playOrder, playOrderIter+1).concat(remaining);
			}
			else {
				// Try to find the next position of the previously last track of the list,
				// and insert the new tracks in play order after that. If the index is not
				// found, then we have already wrapped over the last track and the new tracks
				// do not need to be added.
				var insertPos = _.indexOf(playOrder, prevListSize-1, playOrderIter);
				if (insertPos >= 0) {
					++insertPos;
					insertMany(playOrder, insertPos, newIndices);
				}
			}
		},
		publish: function(name, parameters) {
			$rootScope.$emit(name, parameters);
		},
		subscribe: function(name, listener) {
			return $rootScope.$on(name, listener);
		}
	};
}]);

angular.module('Music').run(['gettextCatalog', function (gettextCatalog) {
/* jshint -W100 */
    gettextCatalog.setStrings('ach', {});
    gettextCatalog.setStrings('ady', {});
    gettextCatalog.setStrings('af_ZA', {"+ New Playlist":"+ Nuwe Afspeellys","Albums":"Albums","All tracks":"Alle snitte","Artists":"Kunstenaars","Click here to start the scan":"Klik hier om skandering te begin","Description":"Beskrywing","Description (e.g. App name)":"Beskrywing (bv. Toepnaam)","Generate API password":"Genereer API-wagwoord","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Hier kan u wagwoorde genereer vir gebruik ,et die Ampache API aangesien dit weens die ontwerp van die Ampache API nie op ’n veilige manier bewaar kan word nie. U kan soveel wagwoorde na hartelus genereer en dit ter eniger tyd herroep.","Invalid path":"Ongeldige pad","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Hou in gedagte dat die Ampache API ’n onstabiele voorskou is. Voel vry om verslag van u ervaring met hierdie funksie in die ooreenkomstige <a href=\"https://github.com/owncloud/music/issues/60\">uitgawe</a> te doen. Ek sal ook graag ’n kliëntlys wil hê om mee te toets. Dankie.","Music":"Musiek","New music available":"Nuwe musiek beskikbaar","New music available. Click here to reload the music library.":"Nuwe musiek beskikbaar. Klik hier om die musiekbiblioteek te herlaai.","Next":"Volgende","No music found":"Geen musiek gevind","Path to your music collection":"Pad na u musiekversameling","Pause":"Wag","Play":"Speel","Previous":"Vorige","Repeat":"Herhaal","Revoke API password":"Herroep API-wagwoord","Scanning music …":"Skandeer tans musiek …","Shuffle":"Skommel","Some not playable tracks were skipped.":"Sommige onspeelbare snitte is oorgeslaan.","This setting specifies the folder which will be scanned for music.":"Hierdie instelling spesifiseer die te skandeerde vouer vir musiek. ","Tracks":"Snitte","Unknown album":"Onbekende album","Unknown artist":"Onbekende kunstenaar","Upload music in the files app to listen to it here":"Laai musiek in die lêers-toep op om hier daarna te luister","Use this address to browse your music collection from any Ampache compatible player.":"Gebruik hierdie adres om in enige Ampache-versoenbare speler deur u musiekversameling te blaai.","Use your username and following password to connect to this Ampache instance:":"Gebruik u gebruikersnaam en die volgende wagwoord om aan hierdie Ampache-instansie te koppel:","Volume":"Volume","tracks":"snitte","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} van {{ scanningTotal }}"});
    gettextCatalog.setStrings('af', {});
    gettextCatalog.setStrings('ak', {});
    gettextCatalog.setStrings('am_ET', {});
    gettextCatalog.setStrings('ar', {"Albums":"الألبومات","Artists":"الفنانون","Description":"الوصف","Description (e.g. App name)":"الوصف (مثل اسم التطبيق)","Generate API password":"أنشِئ كلمة سر لواجهة برمجة التطبيقات ( API)","Invalid path":"مسار غير صحيح","Music":"الموسيقى","Next":"التالي","Pause":"إيقاف","Play":"تشغيل","Previous":"السابق","Repeat":"إعادة","Revoke API password":"إلغاء كلمة سر API","Shuffle":"اختيار عشوائي","Some not playable tracks were skipped.":"جرى تخطى بعض المقاطع غير العاملة","This setting specifies the folder which will be scanned for music.":"ستخصص الإعدادات الملف الذي سُيجرى البحث فيه عن الموسيقى","Tracks":"المقاطع","Unknown album":"ألبوم غير معروف","Unknown artist":"فنان غير معروف","Use this address to browse your music collection from any Ampache compatible player.":"استخدم هذا العنوان في أي مشغل متوافق مع Ampache للبحث عن مجموعتك الموسيقية "});
    gettextCatalog.setStrings('ast', {"Albums":"Álbumes","Artists":"Artistes","Description":"Descripción","Description (e.g. App name)":"Descripción (p.ex, nome de l'aplicación)","Generate API password":"Xenerar contraseña pa la API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Equí pues xenerar contraseñes pa usales cola API d'Ampache, yá que nun puen almacenase de mou seguru pol diseñu de la API d'Ampache. Pues crear toles contraseñes que quieras y revocales en cualquier momentu.","Invalid path":"Camín inválidu","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Recuerda que la API d'Ampache namái ye un prototipu y ye inestable. Informa de la to esperiencia con esta nueva carauterística nel <a href=\"https://github.com/owncloud/music/issues/60\">informe de fallu</a> correspondiente. Prestábame tener una llista de veceros cola que probala. Gracies.","Music":"Música","Next":"Siguiente","Path to your music collection":"Camín a la to coleición de música","Pause":"Posa","Play":"Reproducir","Previous":"Anterior","Repeat":"Repitir","Revoke API password":"Revocar contraseña pa la API","Shuffle":"Mecer","Tracks":"Canciones","Unknown album":"Álbum desconocíu","Unknown artist":"Artista desconocíu","Use your username and following password to connect to this Ampache instance:":"Usa'l to nome d'usuariu y la siguiente contraseña pa coneutate con esta instancia d'Ampache:"});
    gettextCatalog.setStrings('az', {"Albums":"Albomlar","Artists":"Müğənnilər","Description":"Açıqlanma","Description (e.g. App name)":"Açıqlanma(Misal üçün proqram adı)","Generate API password":"APİ şifrəsinin generasiyası","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ampache APİ-nin istifadə edilməsi üçün burda siz şifrələr generasiya edə bilərsiniz ona görə ki, onlar yalnz təhlükəsiz saxlana bilər. Bu Ampache API-nin öz dizaynıdır. Siz istənilən zaman çoxlu şifrə yarada və onları silə bilərsiniz.","Invalid path":"Yalnış ünvan","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Yadda saxlayın, Ampache API yalnız göstərmək üçündür və stabil deyil. Bu imkanla olan öz praktikanızı <a href=\"https://github.com/owncloud/music/issues/60\">səbəb</a> uyğun unvanla bölüşməkdən çəkinməyin. Həmçinin bunun test edilməsi üçün müştərilər siyahısını istərdim.\nTəşəkkürlər ","Music":"Musiqi","Next":"Növbəti","Path to your music collection":"Sizin musiqi yığmasının ünvanı","Pause":"Ara ver","Play":"Oxu","Previous":"Əvvələ","Repeat":"Təkrar","Revoke API password":"API şifrəsini sil","Shuffle":"Qarışdırmaq","Some not playable tracks were skipped.":"Bəzi oxunulabilməyən musiqilər ötürülüb.","This setting specifies the folder which will be scanned for music.":"Bu quraşdırma qovluğu təyin edir hansı ki, musiqi üçün tədqiq ediləcək.","Tracks":"Musiqi","Unknown album":"Bəlli olmayan albom","Unknown artist":"Bəlli olmayan artist","Use this address to browse your music collection from any Ampache compatible player.":"İstənilən Ampache uyğunluğu olan oxuyucudan sizin musiqi kolleksiyanızı göstərmək üçün, bu ünvandan istifadə edin.","Use your username and following password to connect to this Ampache instance:":"Bu Ampache nusxəsinə qoşulmaq üçün öz istifadəçi adı və şifrənizi istifadə edin."});
    gettextCatalog.setStrings('be', {});
    gettextCatalog.setStrings('bg_BG', {"Albums":"Албуми","Artists":"Изпълнители","Description":"Описание","Description (e.g. App name)":"Описание (пр. име на Приложението)","Generate API password":"Генерирай API парола","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Тук можеш да генерираш пароли, които да използваш с Ampache API, защото те не могат да бъдат съхранени по сигурен начин поради архитектурата на Ampachi API. Можеш да генерираш колко искаш пароли и да ги спираш по всяко време.","Invalid path":"Невалиден път","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Помни, че Ampache API е само предварителна варсия и не е стабилно. Можеш да опишеш своя опит с тази услуга на <a href=\"https://github.com/owncloud/music/issues/60\">следната страница</a>.","Music":"Музика","Next":"Следваща","Path to your music collection":"Пътят към музикалната ти колекция","Pause":"Пауза","Play":"Пусни","Previous":"Предишна","Repeat":"Повтори","Revoke API password":"Премахни API паролата","Shuffle":"Разбъркай","Some not playable tracks were skipped.":"Някои невъзпроизведими песни бяха пропуснати.","This setting specifies the folder which will be scanned for music.":"Тази настройка задава папката, която ще бъде сканирана за музика.","Tracks":"Песни","Unknown album":"Непознат албум","Unknown artist":"Непознат изпълнител","Use this address to browse your music collection from any Ampache compatible player.":"Използвай този адрес, за да разглеждаш музикалната си колекция от всеки съвместим с Ampache музикален плеър.","Use your username and following password to connect to this Ampache instance:":"Използвай своето потребителско име и следната парола за връзка с тази Ampache инсталация:"});
    gettextCatalog.setStrings('bg', {"Albums":"Албуми","Artists":"Изпълнители","Description":"Описание","Description (e.g. App name)":"Описание (пр. име на Приложението)","Generate API password":"Генерирай API парола","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Тук можеш да генерираш пароли, които да използваш с Ampache API, защото те не могат да бъдат съхранени по сигурен начин поради архитектурата на Ampachi API. Можеш да генерираш колко искаш пароли и да ги спираш по всяко време.","Invalid path":"Невалиден път","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Помни, че Ampache API е само предварителна варсия и не е стабилно. Можеш да опишеш своя опит с тази услуга на <a href=\"https://github.com/owncloud/music/issues/60\">следната страница</a>.","Music":"Музика","Next":"Следваща","Path to your music collection":"Пътят към музикалната ти колекция","Pause":"Пауза","Play":"Пусни","Previous":"Предишна","Repeat":"Повтори","Revoke API password":"Премахни API паролата","Shuffle":"Разбъркай","Some not playable tracks were skipped.":"Някои невъзпроизведими песни бяха пропуснати.","This setting specifies the folder which will be scanned for music.":"Тази настройка задава папката, която ще бъде сканирана за музика.","Tracks":"Песни","Unknown album":"Непознат албум","Unknown artist":"Непознат изпълнител","Use this address to browse your music collection from any Ampache compatible player.":"Използвай този адрес, за да разглеждаш музикалната си колекция от всеки съвместим с Ampache музикален плеър.","Use your username and following password to connect to this Ampache instance:":"Използвай своето потребителско име и следната парола за връзка с тази Ampache инсталация:"});
    gettextCatalog.setStrings('bn_BD', {"Albums":"অ্যালবামসমূহ","Artists":"শিল্পীগণ","Description":"বিবরণ","Description (e.g. App name)":"বিবরণ (উদাহরণ: অ্যাপ নাম)","Generate API password":"API কুটশব্দ তৈরী কর","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"এখানে আপনি Ampache API এর জন্য কুটশব্দ তৈরী করতে পারেন কারণ তার ডিজােইনের কারণেই Ampache API কে নিরাপদে সংরক্ষণ করা যায়না। আপনার যত খুশি কুটশব্দ তৈরী করতে পারেন এবং ইচ্ছেমাফিক তাদের বাতিল করতেও পারেন।","Invalid path":"পথটি সঠিক নয়","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"মনে রাখুন যে Ampache API একটি প্রিভিউ মাত্র এবং এটি স্থির কিছু নয়। এতদ্বিষয়ে আপনার অভিজ্ঞতা আমাদের জানাতে <a href=\"https://github.com/owncloud/music/issues/60\">issue</a> ব্যাবহার করুন। এটি পরীক্ষা করার জন্য আমার কিছু ব্যাবহারকারী প্রয়োজন। ধন্যবাদ ","Music":"গানবাজনা","Next":"পরবর্তী","Path to your music collection":"আপনার গানের সংগ্রহের পথ ","Pause":"বিরতি","Play":"বাজাও","Previous":"পূর্ববর্তী","Repeat":"পূনঃসংঘটন","Revoke API password":"API কুটশব্দ বাতিল কর","Shuffle":"এলোমেলো কর","Some not playable tracks were skipped.":"বাজানোর অনুপযোগী কিছু ট্র্যাক এড়িয়ে যাওয়া হয়েছে।","This setting specifies the folder which will be scanned for music.":"এই নিয়ামকটি গান খুজে বের করার জন্য ফোল্ডার নির্ধারণ করে।","Tracks":"ট্র্যাকসমূহ","Unknown album":"অজানা অ্যালবাম","Unknown artist":"অজানা শিল্পী","Use this address to browse your music collection from any Ampache compatible player.":"Ampache compatible player হতে আপনার গানের সংগ্রহ দেখতে এই ঠিকানা ব্যাবহার করুন।","Use your username and following password to connect to this Ampache instance:":"এই  Ampache-টিতে সংযুক্ত হতে আপনার ব্যাবহারকারী নাম ও নীচের কুটশব্দ ব্যাবহার করুন:"});
    gettextCatalog.setStrings('bn_IN', {"Albums":"অ্যালবাম","Artists":"শিল্পী","Description":"বর্ণনা","Description (e.g. App name)":"বর্ণনা (যেমন অ্যাপ নাম)","Generate API password":"এপিআই পাসওয়ার্ড নির্মাণ করা","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"এখানে আপনি আম্পাচে এপিআইের সঙ্গে ব্যবহার করার জন্য পাসওয়ার্ড তৈরি করতে পারেন,কারন তাদের নিরাপদ ভাবে সংরক্ষণ করা যাবে না আম্পাচে এপিআই এর নকশার জন্যে।আপনি যখন ইচ্ছে অনেক পাসওয়ার্ড জেনারেট করতে পারেন এবং যে কোনো সময় তাদের প্রত্যাহার করতে পারেন.","Invalid path":"অবৈধ পথ","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"  মনে রাখবেন যে আম্পাচে এপিআই শুধু একটি প্রাকদর্শন এবং অস্থির।এই বৈশিষ্ট্যের সঙ্গে আপনার অভিজ্ঞতা রিপোর্ট করুন বিনা দ্বিধায় <a href=\"https://github.com/owncloud/music/issues/60\">সংশ্লিষ্ট প্রকাশে</a>।আমি সঙ্গে পরীক্ষা করার জন্য গ্রাহকদের একটি তালিকা চাই।ধন্যবাদ","Music":"সঙ্গীত","Next":"পরবর্তী","Path to your music collection":"আপনার সঙ্গীত সংগ্রহের পথ","Pause":"বিরাম","Play":"প্লে","Previous":"পূর্ববর্তী","Repeat":"পুনরাবৃত্তি","Revoke API password":"এপিআই পাসওয়ার্ড প্রত্যাহার করা","Shuffle":"অদলবদল","Some not playable tracks were skipped.":"কিছু কিছু প্লে করার যোগ্য ট্র্যাক এড়ানো হয়েছে।","This setting specifies the folder which will be scanned for music.":"এই সেটিং ফোল্ডার উল্লেখ করে যেটা সঙ্গীতের জন্য স্ক্যান করা হবে।","Tracks":"সঙ্গীত","Unknown album":"অজানা অ্যালবাম","Unknown artist":"অজানা শিল্পী","Use this address to browse your music collection from any Ampache compatible player.":"কোনো আম্পাচে সামঞ্জস্যপূর্ণ প্লেয়ার থেকে আপনার সঙ্গীত সংগ্রহের এবং ব্রাউজ করার জন্য এই ঠিকানা ব্যবহার করুন।","Use your username and following password to connect to this Ampache instance:":"এই আম্পাচে উদাহরণস্বরূপের সাথে সংযোগ স্থাপন করতে আপনার ব্যবহারকারীর নাম ও নিম্নলিখিত পাসওয়ার্ড ব্যবহার করুন:"});
    gettextCatalog.setStrings('bs', {"Description":"Opis","Next":"Sljedeći","Pause":"Pauza","Play":"Play","Previous":"Prethodno","Repeat":"Ponovi"});
    gettextCatalog.setStrings('ca@valencia', {});
    gettextCatalog.setStrings('ca', {"+ New Playlist":"+ Nova llista de reproducció","Albums":"Àlbums","Artists":"Artistes","Description":"Descripció","Description (e.g. App name)":"Descripció (per exemple nom de l'aplicació)","Generate API password":"Genera contrasenya API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aquí podeu generar contrasenyes per usar amb l'API d'Ampache,ja que no es poden desar de forma segura degut al diseny de l'API d'Ampache. Podeu generar tantes contrasenyes com volgueu i revocar-les en qualsevol moment.","Invalid path":"El camí no és vàlid","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Recordeu que l'API d'Ampache és només una previsualització i que és inestable. Sou lliures d'informar de la vostra experiència amb aquesta característica en el <a href=\"https://github.com/owncloud/music/issues/60\">fil</a> corresponent. També voldríem tenir una llista de clients per fer proves. Gràcies.","Music":"Música","Next":"Següent","Path to your music collection":"Camí a la col·lecció de música","Pause":"Pausa","Play":"Reprodueix","Previous":"Anterior","Repeat":"Repeteix","Revoke API password":"Revoca la cotrasenya de l'API","Shuffle":"Aleatori","Some not playable tracks were skipped.":"Algunes pistes no reproduïbles s'han omès.","This setting specifies the folder which will be scanned for music.":"Aquest arranjament especifica la carpeta que s'escanejarà en cerca de música","Tracks":"Peces","Unknown album":"Àlbum desconegut","Unknown artist":"Artista desconegut","Use this address to browse your music collection from any Ampache compatible player.":"Utilitza aquesta adreça per navegar per la teva col·lecció de música des de qualsevol reproductor compatible amb Ampache.","Use your username and following password to connect to this Ampache instance:":"Useu el vostre nom d'usuari i contrasenya per connectar amb la instància Ampache:"});
    gettextCatalog.setStrings('cs_CZ', {"+ New Playlist":"+ Nový seznam","Albums":"Alba","All tracks":"Všechny stopy","Artists":"Umělci","Click here to start the scan":"Klikněte zde pro začátek hledání","Description":"Popis","Description (e.g. App name)":"Popis (např. Jméno aplikace)","Generate API password":"Generovat heslo API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Zde můžete vytvářet hesla pro Ampache API, protože tato nemohou být uložena skutečně bezpečným způsobem z důvodu designu Ampache API. Je možné vygenerovat libovolné množství hesel a kdykoliv je zneplatnit.","Invalid path":"Chybná cesta","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Mějte na paměti, že Ampache API je stále ve vývoji a není stabilní. Můžete nás bez obav informovat o zkušenostech s touto funkcí odesláním hlášení v příslušném <a href=\"https://github.com/owncloud/music/issues/60\">tiketu</a>. Chtěl bych také sestavit seznam zájemců o testování. Díky","Music":"Hudba","New music available":"Nová hudba k dispozici","New music available. Click here to reload the music library.":"Nová hudba k dispozici. Klikněte pro znovunačtení hudební knihovny.","Next":"Následující","No music found":"Hudba nenalezena","Path to your music collection":"Cesta k vlastní sbírce hudby","Pause":"Pozastavit","Play":"Přehrát","Previous":"Předchozí","Repeat":"Opakovat","Revoke API password":"Odvolat heslo API","Scanning music …":"Hledám hudbu …","Shuffle":"Promíchat","Some not playable tracks were skipped.":"Některé stopy byly přeskočeny, protože se nedají přehrát.","This setting specifies the folder which will be scanned for music.":"Toto nastavení určuje adresář, ve kterém bude hledána hudba.","Tracks":"Stopy","Unknown album":"Neznámé album","Unknown artist":"Neznámý umělec","Upload music in the files app to listen to it here":"Nahrát hudbu v aplikaci soubory k poslechu zde","Use this address to browse your music collection from any Ampache compatible player.":"Použijte tuto adresu pro přístup k hudební sbírce z jakéhokoliv přehrávače podporujícího Ampache.","Use your username and following password to connect to this Ampache instance:":"Použijte Vaše uživatelské jméno a následující heslo pro připojení k této instanci Ampache:","Volume":"Hlasitost","tracks":"stopy","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} z {{ scanningTotal }}"});
    gettextCatalog.setStrings('cs', {"+ New Playlist":"+ Nový seznam","Albums":"Alba","All tracks":"Všechny stopy","Artists":"Umělci","Click here to start the scan":"Klikněte zde pro začátek hledání","Description":"Popis","Description (e.g. App name)":"Popis (např. Jméno aplikace)","Generate API password":"Generovat heslo API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Zde můžete vytvářet hesla pro Ampache API, protože tato nemohou být uložena skutečně bezpečným způsobem z důvodu designu Ampache API. Je možné vygenerovat libovolné množství hesel a kdykoliv je zneplatnit.","Invalid path":"Chybná cesta","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Mějte na paměti, že Ampache API je stále ve vývoji a není stabilní. Můžete nás bez obav informovat o zkušenostech s touto funkcí odesláním hlášení v příslušném <a href=\"https://github.com/owncloud/music/issues/60\">tiketu</a>. Chtěl bych také sestavit seznam zájemců o testování. Díky","Music":"Hudba","New music available":"Nová hudba k dispozici","New music available. Click here to reload the music library.":"Nová hudba k dispozici. Klikněte pro znovunačtení hudební knihovny.","Next":"Následující","No music found":"Hudba nenalezena","Path to your music collection":"Cesta k vlastní sbírce hudby","Pause":"Pozastavit","Play":"Přehrát","Previous":"Předchozí","Repeat":"Opakovat","Revoke API password":"Odvolat heslo API","Scanning music …":"Hledám hudbu …","Shuffle":"Promíchat","Some not playable tracks were skipped.":"Některé stopy byly přeskočeny, protože se nedají přehrát.","This setting specifies the folder which will be scanned for music.":"Toto nastavení určuje adresář, ve kterém bude hledána hudba.","Tracks":"Stopy","Unknown album":"Neznámé album","Unknown artist":"Neznámý umělec","Upload music in the files app to listen to it here":"Nahrát hudbu v aplikaci soubory k poslechu zde","Use this address to browse your music collection from any Ampache compatible player.":"Použijte tuto adresu pro přístup k hudební sbírce z jakéhokoliv přehrávače podporujícího Ampache.","Use your username and following password to connect to this Ampache instance:":"Použijte Vaše uživatelské jméno a následující heslo pro připojení k této instanci Ampache:","Volume":"Hlasitost","tracks":"stopy","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} z {{ scanningTotal }}"});
    gettextCatalog.setStrings('cy_GB', {"Description":"Disgrifiad","Music":"Cerddoriaeth","Next":"Nesaf","Pause":"Seibio","Play":"Chwarae","Previous":"Blaenorol","Repeat":"Ailadrodd"});
    gettextCatalog.setStrings('da', {"+ New Playlist":"+ Ny spilleliste","Albums":"Album","All tracks":"Alle sange","Artists":"Kunstnere","Click here to start the scan":"Tryk her for at starte et scan","Description":"Beskrivelse","Description (e.g. App name)":"Beskrivelse (f.eks. App-navn)","Generate API password":"Generér API-adgangskode","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Her kan du generere adgangskoder, der bruges med Ampache API'et, da de ikke kan lagres på en rigtig sikker måde, hvilket skyldes designet af Ampache API'et. Du kan generere alle de adgangskoder som du ønsker, og tilbagekalde dem til enhver tid.","Invalid path":"Ugyldig sti","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Det bør holdes for øje, at Ampache API'et er i et meget tidligt stadie og fungerer ustabilt. Du er velkommen til at berette om dine erfaringer med denne funktion i den respektive <a href=\"https://github.com/owncloud/music/issues/60\">sag</a>. Jeg vil også være interesseret i at etablere en kreds af klienter, der kan hjælpe med afprøvninger. Tak","Music":"Musik","New music available":"Ny musik tilgængelig","New music available. Click here to reload the music library.":"Ny musik tilgængelig. Tryk her for at genindlæse musikbibliotekt","Next":"Næste","No music found":"Musik ikke fundet","Path to your music collection":"Sti til dit musikbibliotek ","Pause":"Pause","Play":"Afspil","Previous":"Forrige","Repeat":"Gentag","Revoke API password":"Tilbagekald API-adgangskode","Scanning music …":"Scanner musik...","Shuffle":"Bland","Some not playable tracks were skipped.":"Numre som ikke kunne afspilles blev sprunget over.","This setting specifies the folder which will be scanned for music.":"Denne indstilling angiver dén mappe, der vil blive skannet for musik.","Tracks":"Numre","Unknown album":"Ukendt album","Unknown artist":"Ukendt artist","Upload music in the files app to listen to it here":"Upload musk i fil-appen og lyt til dem her","Use this address to browse your music collection from any Ampache compatible player.":"Brug denne adresse til at gennemse din musiksamling fra hvilken som helst Ampache-kompatibel afspiller.","Use your username and following password to connect to this Ampache instance:":"Brug dit brugernavn og følgende adgangskode for at tilslutte til denne Ampache-instans:","Volume":"Volumen","tracks":"Numre","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} af {{ scanningTotal }}"});
    gettextCatalog.setStrings('de_AT', {"Description":"Beschreibung","Music":"Musik","Next":"Nächstes","Pause":"Pause","Play":"Abspielen","Previous":"Vorheriges","Repeat":"Wiederholen","Shuffle":"Zufallswiedergabe","Unknown album":"Unbekanntes Album","Unknown artist":"Unbekannter Künstler"});
    gettextCatalog.setStrings('de_CH', {"Description":"Beschreibung","Music":"Musik","Next":"Weiter","Pause":"Anhalten","Play":"Abspielen","Previous":"Vorheriges","Repeat":"Wiederholen"});
    gettextCatalog.setStrings('de_DE', {"+ New Playlist":"+ Neue Wiedergabeliste","Albums":"Alben","All tracks":"Alle Titel","Artists":"Künstler","Click here to start the scan":"Um das Durchsuchen zu starten, hier klicken","Description":"Beschreibung","Description (e.g. App name)":"Beschreibung (z.B. Name der Anwendung)","Generate API password":"API-Passwort erzeugen","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Hier können Sie Passwörter zur Benutzung mit der Ampache-API erzeugen, da diese aufgrund des Designs der Ampache-API auf keine wirklich sichere Art und Weise gespeichert werden können. Sie könenn soviele Passwörter generieren, wie Sie möchten und diese jederzeit verwerfen.","Invalid path":"Ungültiger Pfad","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Bitte bedenken Sie, dass die Ampache-API derzeit eine Vorschau und instabil ist. Sie können gerne Ihre Erfahrungen mit dieser Funktion im entsprechenden <a href=\"https://github.com/owncloud/music/issues/60\">Fehlerbericht</a> melden. Ich würde ebenfalls eine Liste von Anwendung zu Testzwecken sammeln. Dankeschön","Music":"Musik","New music available":"Neue Musik verfügbar","New music available. Click here to reload the music library.":"Neue Musik verfügbar. Zum Neuladen der Medienbibliothek, hier klicken.","Next":"Weiter","No music found":"Keine Musik gefunden","Path to your music collection":"Pfad zu Ihrer Musiksammlung","Pause":"Anhalten","Play":"Abspielen","Previous":"Zurück","Repeat":"Wiederholen","Revoke API password":"API-Passwort verwerfen","Scanning music …":"Untersuche Musik ...","Shuffle":"Zufallswiedergabe","Some not playable tracks were skipped.":"Einige nicht abspielbare Titel wurden übersprungen.","This setting specifies the folder which will be scanned for music.":"Diese Einstellung spezifiziert den zu durchsuchenden Musikordner.","Tracks":"Titel","Unknown album":"Unbekanntes Album","Unknown artist":"Unbekannter Künstler","Upload music in the files app to listen to it here":"Laden Sie Musik in der Dateien-App hoch, um diese hier anzuhören.","Use this address to browse your music collection from any Ampache compatible player.":"Nutzen Sie diese Adresse zum Durchsuchen Ihrer Musiksammlung auf einem beliebigen Ampache-kompatiblen Abspieler.","Use your username and following password to connect to this Ampache instance:":"Benutzen Sie Ihren Benutzernamen und folgendes Passwort, um sich mit dieser Ampache-Instanz zu verbinden:","Volume":"Lautstärke","tracks":"Titel","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} von {{ scanningTotal }}"});
    gettextCatalog.setStrings('de', {"+ New Playlist":"+ Neue Wiedergabeliste","Albums":"Alben","All tracks":"Alle Titel","Artists":"Künstler","Click here to start the scan":"Um das Durchsuchen zu starten, hier klicken","Description":"Beschreibung","Description (e.g. App name)":"Beschreibung (z.B. Name der Anwendung)","Generate API password":"API Passwort erzeugen","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Hier kannst Du Passwörter zur Benutzung mit der Ampache-API erzeugen, da diese aufgrund des Designs der Ampache-API auf keine wirklich sichere Art und Weise gespeichert werden können. Du kannst soviele Passwörter generieren, wie Du möchtest und diese jederzeit verwerfen.","Invalid path":"Ungültiger Pfad","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Bitte bedenke, dass die Ampache-API derzeit eine Vorschau und instabil ist. Du kannst gerne Deine Erfahrungen mit dieser Funktion im entsprechenden <a href=\"https://github.com/owncloud/music/issues/60\">Fehlerbericht</a> melden. Ich würde ebenfalls eine Liste von Anwendung zu Testzwecken sammeln. Dankeschön","Music":"Musik","New music available":"Neue Musik verfügbar","New music available. Click here to reload the music library.":"Neue Musik verfügbar. Zum Neuladen der Medienbibliothek, hier klicken.","Next":"Weiter","No music found":"Keine Musik gefunden","Path to your music collection":"Pfad zu Deiner Musiksammlung","Pause":"Anhalten","Play":"Abspielen","Previous":"Zurück","Repeat":"Wiederholen","Revoke API password":"API Passwort verwerfen","Scanning music …":"Untersuche Musik ...","Shuffle":"Zufallswiedergabe","Some not playable tracks were skipped.":"Einige nicht abspielbare Titel wurden übersprungen.","This setting specifies the folder which will be scanned for music.":"Diese Einstellung spezifiziert den zu durchsuchenden Musikordner.","Tracks":"Titel","Unknown album":"Unbekanntes Album","Unknown artist":"Unbekannter Künstler","Upload music in the files app to listen to it here":"Laden Sie Musik in der Dateien-App hoch, um diese hier anzuhören.","Use this address to browse your music collection from any Ampache compatible player.":"Nutze diese Adresse zum Durchsuchen Deiner Musiksammlung auf einem beliebigen Ampache-kompatiblen Abspieler.","Use your username and following password to connect to this Ampache instance:":"Nutze Deinen Benutzernamen und folgendes Passwort, um zu dieser Ampache-Instanz zu verbinden:","Volume":"Lautstärke","tracks":"Titel","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} von {{ scanningTotal }}"});
    gettextCatalog.setStrings('el', {"+ New Playlist":"+ Νέα λίστα αναπαραγωγής","Albums":"Άλμπουμ","All tracks":"Όλα τα κομμάτια","Artists":"Καλλιτέχνες","Click here to start the scan":"Κάντε κλικ εδώ για την εκκίνηση σάρωσης","Description":"Περιγραφή","Description (e.g. App name)":"Περιγραφή (π.χ. όνομα Εφαρμογής)","Generate API password":"Δημιουργία κωδικού πρόσβασης API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Εδώ μπορείτε να δημιουργήσετε κωδικούς πρόσβασης για χρήση με το API του Ampache, γιατί δεν είναι δυνατό να αποθηκευτούν με πραγματικά ασφαλή τρόπο λόγω της σχεδίασης του API του Ampache. Μπορείτε να δημιουργήσετε όσα συνθηματικά θέλετε και να τα ανακαλέσετε οποτεδήποτε.","Invalid path":"Άκυρη διαδρομή","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Θυμηθείτε ότι το API του Ampache είναι απλά μια προτεπισκόπηση και είναι ασταθές. Παρακαλούμε αναφέρετε την εμπειρία σας με αυτή τη λειτουργία στην αντίστοιχη <a href=\"https://github.com/owncloud/music/issues/60\">αναφορά</a>. Θα ήταν καλό να υπάρχει επίσης μια λίστα με εφαρμογές προς δοκιμή. Ευχαριστούμε!","Music":"Μουσική","New music available":"Διαθέσιμη νέα μουσική","New music available. Click here to reload the music library.":"Διαθέσιμη νέα μουσική. Κάντε κλικ εδώ για να φορτώσετε ξανά τη βιβλιοθήκη μουσικής.","Next":"Επόμενο","No music found":"Δεν βρέθηκε μουσική","Path to your music collection":"Διαδρομή για τη μουσική σας συλλογή","Pause":"Παύση","Play":"Αναπαραγωγή","Previous":"Προηγούμενο","Repeat":"Επανάληψη","Revoke API password":"Ανάκληση κωδικού πρόσβασης API","Scanning music …":"Σάρωση μουσικής ...","Shuffle":"Τυχαία αναπαραγωγή","Some not playable tracks were skipped.":"Μερικά μη αναγνώσιμα τραγούδια έχουν παρακαμφθεί.","This setting specifies the folder which will be scanned for music.":"Αυτή η ρύθμιση προσδιορίζει το φάκελο που θα σαρωθεί για μουσική.","Tracks":"Κομμάτια","Unknown album":"Άγνωστο άλμπουμ","Unknown artist":"Άγνωστος καλλιτέχνης","Upload music in the files app to listen to it here":"Μεταφόρτωση μουσικής στην εφαρμογή μουσικής για ακρόαση εδώ","Use this address to browse your music collection from any Ampache compatible player.":"Χρησιμοποιήστε αυτή τη διεύθυνση για να περιηγηθείτε στη μουσική σας συλλογή από οποιοδήποτε εφαρμογή αναπαραγωγής συμβατή με το Ampache.","Use your username and following password to connect to this Ampache instance:":"Χρησιμοποιήστε το όνομα χρήστη σας και τον παρακάτω κωδικό πρόσβασης για να συνδεθείτε σε αυτή την εγκατάσταση του Ampache:","Volume":"Ένταση","tracks":"κομμάτια","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} από {{ scanningTotal }}"});
    gettextCatalog.setStrings('en_GB', {"Albums":"Albums","Artists":"Artists","Description":"Description","Description (e.g. App name)":"Description (e.g. App name)","Generate API password":"Generate API password","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.","Invalid path":"Invalid path","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks","Music":"Music","Next":"Next","Path to your music collection":"Path to your music collection","Pause":"Pause","Play":"Play","Previous":"Previous","Repeat":"Repeat","Revoke API password":"Revoke API password","Shuffle":"Shuffle","Some not playable tracks were skipped.":"Some unplayable tracks were skipped.","This setting specifies the folder which will be scanned for music.":"This setting specifies the folder which will be scanned for music.","Tracks":"Tracks","Unknown album":"Unknown album","Unknown artist":"Unknown artist","Use this address to browse your music collection from any Ampache compatible player.":"Use this address to browse your music collection from any Ampache compatible player.","Use your username and following password to connect to this Ampache instance:":"Use your username and following password to connect to this Ampache instance:"});
    gettextCatalog.setStrings('en_NZ', {});
    gettextCatalog.setStrings('eo', {"Albums":"Albumoj","Artists":"Artistoj","Description":"Priskribo","Description (e.g. App name)":"Priskribo (ekz.: aplikaĵonomo)","Invalid path":"Nevalida vojo","Music":"Muziko","Next":"Jena","Path to your music collection":"Vojo al via muzikokolekto","Pause":"Paŭzi...","Play":"Ludi","Previous":"Maljena","Repeat":"Ripeti","Shuffle":"Miksi","Unknown album":"Nekonata albumo","Unknown artist":"Nekonata artisto"});
    gettextCatalog.setStrings('es_AR', {"+ New Playlist":"+ Nueva lista de reproducción","Albums":"Álbumes","Artists":"Artistas","Description":"Descripción","Description (e.g. App name)":"Descripción (ej. Nombre de la Aplicación)","Generate API password":"Generar contraseña de la API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aquí puede generar contraseñas para usar con la API de Ampache, porque no pueden ser guardadas de manera segura por diseño de la API de Ampache. Puede generar tantas contraseñas como quiera y revocarlas todas en cualquier momento.","Invalid path":"Ruta no válida","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Tenga en cuenta que la API de Ampache esta en etapa de prueba y es inestable. Siéntase libre de reportar su experiencia con esta característica en el correspondiente <a href=\"https://github.com/owncloud/music/issues/60\">punto</a>. También me gustaría tener una lista de clientes para probar.  Gracias!.","Music":"Música","Next":"Siguiente","Path to your music collection":"Ruta a tu colección de música.","Pause":"Pausar","Play":"Reproducir","Previous":"Previo","Repeat":"Repetir","Revoke API password":"Revocar contraseña de la API","Shuffle":"Aleatorio","Tracks":"Pistas","Unknown album":"Album desconocido","Unknown artist":"Artista desconocido","Use this address to browse your music collection from any Ampache compatible player.":"Use esta dirección para navegar tu colección de música desde cualquier reproductor compatible con Ampache.","Use your username and following password to connect to this Ampache instance:":"Use su nombre de usuario y la siguiente contraseña para conectar a esta instancia de Ampache:"});
    gettextCatalog.setStrings('es_BO', {});
    gettextCatalog.setStrings('es_CL', {});
    gettextCatalog.setStrings('es_CO', {});
    gettextCatalog.setStrings('es_CR', {});
    gettextCatalog.setStrings('es_EC', {});
    gettextCatalog.setStrings('es_MX', {"Albums":"Álbunes","Artists":"Artistas","Description":"Descripción","Description (e.g. App name)":"Descripción (e.g. Nombre de la aplicación)","Generate API password":"Generar contraseña de API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aqui puedes generar contraseñas para usar con la API Ampache, porque no pueden ser guardadas de una manera realmente segura debido al diseño de la API Ampache. Puedes generar tantas contraseñas como lo desees y revocarlas en cualquier momento.","Invalid path":"Ruta no valida","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Tenga en cuenta, que la API Ampache es sólo una vista previa y es inestable. No dude en informar de su experiencia con esta característica en el correspondiente  <a href=\"https://github.com/owncloud/music/issues/60\">asunto</a>. Me gustaría tener una lista de clientes para probarlo. Gracias","Music":"Música","Next":"Siguiente","Path to your music collection":"Ruta de acceso a la colección de música","Pause":"Pausa","Play":"Reproducir","Previous":"Anterior","Repeat":"Repetir","Revoke API password":"Revocar contraseña de API","Shuffle":"Mezclar","Some not playable tracks were skipped.":"Algunas pistas no reproducibles fueron omitidas.","This setting specifies the folder which will be scanned for music.":"Esta configuración especifica la carpeta que será analizada en busca de música.","Tracks":"Pistas","Unknown album":"Álbum desconocido","Unknown artist":"Artista desconocido","Use this address to browse your music collection from any Ampache compatible player.":"Utiliza esta dirección para navegar por tu colección de música desde cualquier reproductor compatible Ampache.","Use your username and following password to connect to this Ampache instance:":"Utiliza tu nombre de usuario seguido de tu contraseña para conectarte a esta instancia de Ampache"});
    gettextCatalog.setStrings('es_PE', {});
    gettextCatalog.setStrings('es_PY', {});
    gettextCatalog.setStrings('es_US', {});
    gettextCatalog.setStrings('es_UY', {});
    gettextCatalog.setStrings('es', {"+ New Playlist":"+ Nueva Lista de reproducción","Albums":"Álbumes","All tracks":"Todas las pistas","Artists":"Artistas","Click here to start the scan":"Clic para iniciar la busqueda","Description":"Descripción","Description (e.g. App name)":"Descripción (p.ej., nombre de la aplicación)","Generate API password":"Generar contraseña para la API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aquí se pueden crear contraseñas para usarlas con el API de Ampache. Dado que el diseño del API de Ampache no permite almacenar contraseñas de manera segura, se pueden generar tantas contraseñas como sea necesario, así como revocarlas en cualquier momento.","Invalid path":"Ruta inválida","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Recuerde que el API de Ampache solo es un prototipo y es inestable. Puede reportar su experiencia con esta nueva funcionalidad en el <a href=\"https://github.com/owncloud/music/issues/60\">informe de error</a> correspondiente. También quisiera tener una lista de clientes con quienes probarla. Gracias.","Music":"Música","New music available":"Nueva musica disponible","New music available. Click here to reload the music library.":"Nueva musica disponible. Clic para recargar la libreria de musica.","Next":"Siguiente","No music found":"No se ha encontrado musica","Path to your music collection":"Ruta a su colección de música","Pause":"Pausa","Play":"Reproducir","Previous":"Anterior","Repeat":"Repetir","Revoke API password":"Revocar contraseña para la API","Scanning music …":"Buscando Musica ...","Shuffle":"Mezclar","Some not playable tracks were skipped.":"No se pudieron reproducir algunas canciones.","This setting specifies the folder which will be scanned for music.":"Esta configuración especifica la carpeta en la cual se escaneará la música","Tracks":"Audios","Unknown album":"Álbum desconocido","Unknown artist":"Artista desconocido","Upload music in the files app to listen to it here":"Suba musica en la aplicación para escucharla desde aqui.","Use this address to browse your music collection from any Ampache compatible player.":"Use esta dirección para explorar su colección de música desde cualquier reproductor compatible con Ampache.","Use your username and following password to connect to this Ampache instance:":"Use su nombre de usuario y la siguiente contraseña para conectarse con esta instancia de Ampache:","Volume":"Volumen","tracks":"Pistas","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} de {{ scanningTotal }}"});
    gettextCatalog.setStrings('et_EE', {"+ New Playlist":"+ Uus esitusloend","Albums":"Albumid","All tracks":"Kõik lood","Artists":"Artistid","Click here to start the scan":"Skännimise alustamiseks kliki siia","Description":"Kirjeldus","Description (e.g. App name)":"Kirjeldus (nt. rakendi nimi)","Generate API password":"Tekita API parool","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Siin sa saad tekitada parooli, mida kasutada Ampache API-ga, kuid neid ei ole võimalik talletada turvalisel moel Ampache API olemuse tõttu. Sa saad genereerida nii palju paroole kui soovid ning tühistada neid igal ajal.","Invalid path":"Vigane tee","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Pea meeles, et Ampache APi on lihtsalt eelvaade ning see pole stabiilne. Anna teada oma kogemustest selle funktsionaalsusega vastavalt <a href=\"https://github.com/owncloud/music/issues/60\">teemaarendusele</a>. Ühtlasi soovin nimistut klientidest, mida testida. Tänan.","Music":"Muusika","New music available":"Saadaval on uut muusikat","New music available. Click here to reload the music library.":"Saadaval on uut muusikat. Kliki siia, et muusikakogu uuesti laadida.","Next":"Järgmine","No music found":"Muusikat ei leitud","Path to your music collection":"Tee sinu muusikakoguni","Pause":"Paus","Play":"Esita","Previous":"Eelmine","Repeat":"Korda","Revoke API password":"Keeldu API paroolist","Scanning music …":"Muusika otsimine ...","Shuffle":"Juhuslik esitus","Some not playable tracks were skipped.":"Mõned mittemängitavad lood jäeti vahele.","This setting specifies the folder which will be scanned for music.":"See seade määrab kausta, kust muusikat otsitakse.","Tracks":"Lood","Unknown album":"Tundmatu album","Unknown artist":"Tundmatu esitaja","Upload music in the files app to listen to it here":"Laadi muusika üles failide rakenduses, et seda siin kuulata","Use this address to browse your music collection from any Ampache compatible player.":"Kasuta seda aadressi sirvimaks oma muusikakogu suvalisest Ampache-ga ühilduvast muusikapleierist.","Use your username and following password to connect to this Ampache instance:":"Kasuta oma kasutajatunnust ja järgmist parooli ühendumaks selle Ampache instantsiga:","Volume":"Helitugevus","tracks":"lugu","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} / {{ scanningTotal }}"});
    gettextCatalog.setStrings('eu_ES', {"Description":"Deskripzioa","Music":"Musika","Next":"Aurrera","Pause":"geldi","Play":"jolastu","Previous":"Atzera","Repeat":"Errepikatu"});
    gettextCatalog.setStrings('eu', {"Albums":"Diskak","Artists":"Artistak","Description":"Deskribapena","Description (e.g. App name)":"Deskribapena (adb. App izena)","Generate API password":"Sortu API pasahitza","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Hemen Ampache APIrekin erabiltzeko pasahitzak sor ditzazkezu. Hauek ezin dira modu benetan seguru batean gorde Ampache APIren diseinua dela eta, honengatik nahi duzun pashitz aina sor ditzakezu eta nahi duzunean deuseztatu.","Invalid path":"Baliogabeko bidea","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Gogoratu Ampache APIa aurreikuspen bat besterik ez dela eta ez dela egonkorra.  Mesdez emazu aukera honekiko zure esperientziaren berri dagokion <a href=\"https://github.com/owncloud/music/issues/60\">lekuan</a>. Gustatuko litzaidake ere bezero zerrenda bat izatea probak egin ahal izateko. Milesker","Music":"Musika","Next":"Hurrengoa","Path to your music collection":"Musika bildumaren bidea","Pause":"Pausarazi","Play":"Erreproduzitu","Previous":"Aurrekoa","Repeat":"Errepikatu","Revoke API password":"Ezeztatu API pasahitza","Shuffle":"Nahastu","Some not playable tracks were skipped.":"Erreproduzitu ezin ziren pista batzuk saltatu egin dira.","This setting specifies the folder which will be scanned for music.":"Hemen musika bilatuko den karpetak zehazten dira.","Tracks":"Pistak","Unknown album":"Diska ezezaguna","Unknown artist":"Artista ezezaguna","Use this address to browse your music collection from any Ampache compatible player.":"Erabili helbide hau zure musika bilduma Ampacherekin bateragarria den edozein erreproduktorekin arakatzeko.","Use your username and following password to connect to this Ampache instance:":"Erabili zure erabiltzaile izena eta hurrengo pasahitza Ampache honetara konektatzeko:"});
    gettextCatalog.setStrings('fa', {"Albums":"آلبوم ها","Artists":"هنرمندان","Description":"توضیحات","Description (e.g. App name)":"توضیحات (همانند نام برنامه)","Generate API password":"تولید رمزعبور API ","Invalid path":"مسیر اشتباه","Music":"موزیک","Next":"بعدی","No music found":"موزیک جدید پیدا شد.","Pause":"توقف کردن","Play":"پخش کردن","Previous":"قبلی","Repeat":"تکرار","Shuffle":"درهم","Unknown album":"آلبوم نامشخص","Unknown artist":"خواننده نامشخص","Volume":"میزان صدا"});
    gettextCatalog.setStrings('fi_FI', {"+ New Playlist":"+ Uusi soittolista","Albums":"Albumit","All tracks":"Kaikki kappaleet","Artists":"Esittäjät","Click here to start the scan":"Napsauta aloittaaksesi skannauksen","Description":"Kuvaus","Description (e.g. App name)":"Kuvaus (esim. sovelluksen nimi)","Generate API password":"Luo API-salasana","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Tästä voit luoda Ampache API:n kanssa käytettäviä salasanoja. Rajapinnassa käytetään erillistä salasanaa koska rajapinnan rajoitteiden takia sitä ei voida tallentaa täysin turvallisesti. Voit luoda niin monta salasanaa kuin haluat ja peruuttaa ne koska vain.","Invalid path":"Virheellinen polku","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Huomaa että Ampache API on kehitysasteella ja voi olla epävakaa. Voit raportoida kokemuksiasi ominaisuudesta <a href=\"https://github.com/owncloud/music/issues/60\">tänne</a>. Myös lista asiakasohjelmista auttaisi testaamista. Kiitos","Music":"Musiikki","New music available":"Uusia kappaleita saatavilla","New music available. Click here to reload the music library.":"Uusia kappaleita saatavilla. Napsauta päivittääksesi musiikkikirjastosi.","Next":"Seuraava","No music found":"Musiikkia ei löytynyt","Path to your music collection":"Musiikkikokoelman polku","Pause":"Keskeytä","Play":"Toista","Previous":"Edellinen","Repeat":"Kertaa","Revoke API password":"Kumoa API-salasana","Scanning music …":"Skannataan musiikkia …","Shuffle":"Sekoita","Some not playable tracks were skipped.":"Ohitettiin joitain sellaisia kappaleita, joita ei voi toistaa.","This setting specifies the folder which will be scanned for music.":"Tämä asetus määrittää kansion, josta musiikkia etsitään.","Tracks":"Kappaleet","Unknown album":"Tuntematon albumi","Unknown artist":"Tuntematon esittäjä","Upload music in the files app to listen to it here":"Lähetä musiikkitiedostoja tiedostosovelluksen kautta. Sen jälkeen voit kuunnella musiikkia täällä.","Use this address to browse your music collection from any Ampache compatible player.":"Käytä tätä osoitetta selataksesi musiikkikokoelmaasi miltä tahansa Ampache-yhteensopivalta soittimelta.","Use your username and following password to connect to this Ampache instance:":"Käytä käyttäjätunnustasi ja seuraavaa salasanaa yhditäessäsi tähän Ampache-istuntoon:","Volume":"Äänenvoimakkuus","tracks":"kappaletta","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} / {{ scanningTotal }}"});
    gettextCatalog.setStrings('fi', {"+ New Playlist":"+ Uusi soittolista","Albums":"Albumit","All tracks":"Kaikki kappaleet","Artists":"Esittäjät","Click here to start the scan":"Napsauta aloittaaksesi skannauksen","Description":"Kuvaus","Description (e.g. App name)":"Kuvaus (esim. sovelluksen nimi)","Generate API password":"Luo API-salasana","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Tästä voit luoda Ampache API:n kanssa käytettäviä salasanoja. Rajapinnassa käytetään erillistä salasanaa koska rajapinnan rajoitteiden takia sitä ei voida tallentaa täysin turvallisesti. Voit luoda niin monta salasanaa kuin haluat ja peruuttaa ne koska vain.","Invalid path":"Virheellinen polku","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Huomaa että Ampache API on kehitysasteella ja voi olla epävakaa. Voit raportoida kokemuksiasi ominaisuudesta <a href=\"https://github.com/owncloud/music/issues/60\">tänne</a>. Myös lista asiakasohjelmista auttaisi testaamista. Kiitos","Music":"Musiikki","New music available":"Uusia kappaleita saatavilla","New music available. Click here to reload the music library.":"Uusia kappaleita saatavilla. Napsauta päivittääksesi musiikkikirjastosi.","Next":"Seuraava","No music found":"Musiikkia ei löytynyt","Path to your music collection":"Musiikkikokoelman polku","Pause":"Keskeytä","Play":"Toista","Previous":"Edellinen","Repeat":"Kertaa","Revoke API password":"Kumoa API-salasana","Scanning music …":"Skannataan musiikkia …","Shuffle":"Sekoita","Some not playable tracks were skipped.":"Ohitettiin joitain sellaisia kappaleita, joita ei voi toistaa.","This setting specifies the folder which will be scanned for music.":"Tämä asetus määrittää kansion, josta musiikkia etsitään.","Tracks":"Kappaleet","Unknown album":"Tuntematon albumi","Unknown artist":"Tuntematon esittäjä","Upload music in the files app to listen to it here":"Lähetä musiikkitiedostoja tiedostosovelluksen kautta. Sen jälkeen voit kuunnella musiikkia täällä.","Use this address to browse your music collection from any Ampache compatible player.":"Käytä tätä osoitetta selataksesi musiikkikokoelmaasi miltä tahansa Ampache-yhteensopivalta soittimelta.","Use your username and following password to connect to this Ampache instance:":"Käytä käyttäjätunnustasi ja seuraavaa salasanaa yhditäessäsi tähän Ampache-istuntoon:","Volume":"Äänenvoimakkuus","tracks":"kappaletta","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} / {{ scanningTotal }}"});
    gettextCatalog.setStrings('fil', {});
    gettextCatalog.setStrings('fr_CA', {});
    gettextCatalog.setStrings('fr', {"+ New Playlist":"+ Nouvelle liste de lecture","Albums":"Albums","All tracks":"Toutes les pistes","Artists":"Artistes","Click here to start the scan":"Cliquez ici pour lancer le balayage","Description":"Description","Description (e.g. App name)":"Description (ex. nom de l'application)","Generate API password":"Générer un mot de passe de l'API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ici, vous pouvez générer des mots de passe à utiliser avec l'API Ampache, parce qu'ils ne peuvent être stockés d'une manière sécurisée en raison de la conception de l'API d'Ampache. Vous pouvez générer autant de mots de passe que vous voulez et vous pouvez les révoquer à tout instant.","Invalid path":"Chemin non valide","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Gardez en mémoire que l'API Ampache est une avant-première et n'est pas encore stable. N'hésitez pas à donner un retour d'expérience de cette fonctionnalité <a href=\"https://github.com/owncloud/music/issues/60\">sur la page dédiée</a>. On aimerait également obtenir une liste des clients avec lesquels tester. Merci.","Music":"Musique","New music available":"Nouvelles pistes disponibles","New music available. Click here to reload the music library.":"Nouvelles pistes disponibles. Cliquer ici pour recharger la bibliothèque musicale.","Next":"Suivant","No music found":"Aucune piste trouvée","Path to your music collection":"Chemin vers votre collection de musique","Pause":"Pause","Play":"Lire","Previous":"Précédent","Repeat":"Répéter","Revoke API password":"Révoquer le mot de passe de l'API","Scanning music …":"Balayage de la musique …","Shuffle":"Lecture aléatoire","Some not playable tracks were skipped.":"Certaines pistes non jouables ont été ignorées.","This setting specifies the folder which will be scanned for music.":"Ce paramètre spécifie quel dossier sera balayé pour trouver de la musique.","Tracks":"Pistes","Unknown album":"Album inconnu","Unknown artist":"Artiste inconnu","Upload music in the files app to listen to it here":"Téléversez de la musique dans l'application Fichiers pour l'écouter ici","Use this address to browse your music collection from any Ampache compatible player.":"Utilisez cette adresse pour naviguer dans votre collection musicale avec un client compatible Ampache.","Use your username and following password to connect to this Ampache instance:":"Utilisez votre nom d'utilisateur et le mot de passe suivant pour vous connecter à cette instance d'Ampache : ","Volume":"Volume","tracks":"pistes","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} sur {{ scanningTotal }}"});
    gettextCatalog.setStrings('fy_NL', {});
    gettextCatalog.setStrings('gl', {"Albums":"Albumes","Artists":"Interpretes","Description":"Descrición","Description (e.g. App name)":"Descrición (p.ex. o nome da aplicación)","Generate API password":"Xerar o contrasinal da API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aquí pode xerar contrasinais para utilizar coa API de Ampache, xa que non poden ser almacenados nunha forma abondo segura por mor do deseño da API de Ampache. Pode xerar tantos contrasinais como queira e revogalos en calquera momento.","Invalid path":"Ruta incorrecta","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Teña presente que a API de Ampache é só unha edición preliminar e é inestábel. Non dubide en informarnos da súa experiencia con esta característica na correspondente páxina de  <a href=\"https://github.com/owncloud/music/issues/60\">incidencias</a>. Gustaríanos tamén, ter unha lista de clientes cos que facer probas. Grazas","Music":"Música","Next":"Seguinte","Path to your music collection":"Ruta á súa colección de música","Pause":"Pausa","Play":"Reproducir","Previous":"Anterior","Repeat":"Repetir","Revoke API password":"Revogar o contrasinal da API","Shuffle":"Ao chou","Some not playable tracks were skipped.":"Omitíronse algunhas pistas non reproducíbeis.","This setting specifies the folder which will be scanned for music.":"Este axuste especifica o cartafol que será analizado na busca de música.","Tracks":"Pistas","Unknown album":"Álbum descoñecido","Unknown artist":"Interprete descoñecido","Use this address to browse your music collection from any Ampache compatible player.":"Utilice este enderezo para navegar pola súa colección de música desde calquera reprodutor compatíbel con Ampache.","Use your username and following password to connect to this Ampache instance:":"Utilice o seu nome de usuario e o seguinte contrasinal para conectarse a esta instancia do Ampache:"});
    gettextCatalog.setStrings('gu', {});
    gettextCatalog.setStrings('he', {"+ New Playlist":"+ רשימת השמעה חדשה","Albums":"אלבומים","All tracks":"כל רצועות המוזיקה","Artists":"אומנים","Click here to start the scan":"לחיצה כאן להתחלת הסריקה","Description":"תיאור","Description (e.g. App name)":"תיאור (לדוגמא שם אפליקציה)","Generate API password":"יצירת סיסמאות API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"כאן ניתן ליצור סיסמאות לשימוש ב- Ampache API, כיוון שלא ניתן לאחסן אותן בצורה בטוחה בשל העיצוב של ה- Ampache API. ניתן ליצור מספר לא מוגבל של סיסמאות ולבטל אותן בכל זמן.","Invalid path":"נתיב לא חוקי","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"יש לזכור שה- Ampache API הוא רק קדימון והוא אינו יציב. ניתן לדווח את ההתרשמות מתכונה זו בתכתובת <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. כמו כן נשמח לקבל רשימת לקוחות לבדיקה איתם. תודה","Music":"מוזיקה","New music available":"קיימת מוזיקה חדשה","New music available. Click here to reload the music library.":"קיימת מוזיקה חדשה. יש ללחוץ כאן לטעינה מחדש של ספריית המוזיקה.","Next":"הבא","No music found":"לא נמצאה מוזיקה","Path to your music collection":"נתיב לאוסף המוזיקה שלך","Pause":"השהה","Play":"נגן","Previous":"קודם","Repeat":"חזרה","Revoke API password":"ביטול סיסמת API","Scanning music …":"סורק מוזיקה...","Shuffle":"ערבב","Some not playable tracks were skipped.":"מספר קטעי מוסיקה לא תקינים דולגו","This setting specifies the folder which will be scanned for music.":"ההגדרות של התיקייה עליה תבוצע סריקת המוזיקה","Tracks":"קטעי מוסיקה","Unknown album":"אלבום לא ידוע","Unknown artist":"אמן לא ידוע","Upload music in the files app to listen to it here":"יש להעלות מוזיקה ביישום הקבצים להשמעה שלה כאן","Use this address to browse your music collection from any Ampache compatible player.":"ניתן להשתמש בכתובת זו לעיון בספריית המוזיקה שלך מכל נגן התומך באפצ'י.","Use your username and following password to connect to this Ampache instance:":"השתמשו בשם המשתמש שלכם ובסיסמא הבאה לחיבור למריץ אפצ'י זה:","Volume":"עוצמת שמע","tracks":"רצועות מוזיקה","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} מתוך {{ scanningTotal }}"});
    gettextCatalog.setStrings('hi_IN', {});
    gettextCatalog.setStrings('hi', {"Albums":"एलबम","Artists":"कलाकारों","Description":"विवरण","Music":"गाना","Next":"अगला"});
    gettextCatalog.setStrings('hr', {"Albums":"Albumi","Artists":"Izvođači","Description":"Opis","Description (e.g. App name)":"Opis (primjer: ime aplikacije)","Generate API password":"Generiraj API lozinku","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ovo je mjesto gdje možete generirati svoju lozinku za Ampache API, iz razloga što ne mogu biti pohranjene sigurno radi dizajna Ampache API -a. Možeš generirati nebrojeno lozinki i povući ih u bilo koje vrijeme.","Invalid path":"Pogrešna putanja","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Imajte na umu, da je Ampache API tek probna verzija i poprilično je nestabilna. Slobodno opišite svoje iskustvo sa ovom značajkom u priradajući <a href=\"https://github.com/owncloud/music/issues/60\">problem</a> . Također, htjeli bi imati listu klijenata za testiranje. Hvala","Music":"Muzika","Next":"Sljedeća","Path to your music collection":"Putanja do tvoje baze muzike","Pause":"Pauza","Play":"Reprodukcija","Previous":"Prethodna","Repeat":"Ponavljanje","Revoke API password":"Povuci API lozinku","Shuffle":"Slučajni izbor","Some not playable tracks were skipped.":"Trake koje se ne mogu reproducirati, preskočene su","This setting specifies the folder which will be scanned for music.":"Ova postavka specificira folder koji će biti pretražen za muziku","Tracks":"Trake","Unknown album":"Nepoznati album","Unknown artist":"Nepoznati izvođač","Use this address to browse your music collection from any Ampache compatible player.":"Upotrijebi ovu adresu kada želiš vidjeti svoju glazbenu kolekciju sa bilo kojeg Ampache kompatibilnog uređaja","Use your username and following password to connect to this Ampache instance:":"upotrijebi svoje korisničko ime i sljedeću lozinku kako bi se spojio na Ampache instancu:"});
    gettextCatalog.setStrings('hu_HU', {"Albums":"Albumok","Artists":"Előadók","Description":"Leírás","Description (e.g. App name)":"Leírás (például az alkalmazás neve)","Generate API password":"API-jelszó előállítása","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Itt hozhat létre jelszavakat, amikkel távolról használhatja az Ampache szolgáltatást. Azért van szükség másik jelszóra, mert az Amapche protokoll miatt a használt jelszó nem tárolható igazán biztonságosan. Bármikor visszavonhatja az Ampache jelszavát és újat hozhat létre (sőt tobbfélét is használhat a különböző eszközeihez).","Invalid path":"Érvénytelen útvonal","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Kérjük vegye figyelembe, hogy az Ampache támogatás még nem tekinthető stabilnak, ez még csak tesztváltozat. <a href=\"https://github.com/owncloud/music/issues/60\">Ezen a webcímen</a> számolhat be a tapasztalatairól. Jó lenne minél több kliensprogrammal tesztelni a szolgáltatást. Köszönöm!","Music":"Zene","Next":"Következő","Path to your music collection":"A zenegyűjtemény útvonala","Pause":"Szünet","Play":"Lejátszás","Previous":"Előző","Repeat":"Ismétlés","Revoke API password":"API-jelszó visszavonása","Shuffle":"Keverés","Some not playable tracks were skipped.":"Néhány szám kimaradt, amit a rendszer nem tud lejátszani.","This setting specifies the folder which will be scanned for music.":"Ez a beállítás határozza meg, hogy melyik mappát figyelje a rendszer, amikor az zenei tartalmakat keresi.","Tracks":"Számok","Unknown album":"Ismeretlen album","Unknown artist":"Ismeretlen előadó","Use this address to browse your music collection from any Ampache compatible player.":"Ezt a címet használva a zenegyűjtemény bármely Ampache-kompatibilis lejátszóval böngészhető.","Use your username and following password to connect to this Ampache instance:":"Használja a felhasználónevét és a következő jelszót, ha csatlakozni kíván ehhez az Ampache kiszolgálóhoz:"});
    gettextCatalog.setStrings('hu', {"Albums":"Albumok","Artists":"Előadók","Description":"Leírás","Description (e.g. App name)":"Leírás (például az alkalmazás neve)","Generate API password":"API-jelszó előállítása","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Itt hozhat létre jelszavakat, amikkel távolról használhatja az Ampache szolgáltatást. Azért van szükség másik jelszóra, mert az Amapche protokoll miatt a használt jelszó nem tárolható igazán biztonságosan. Bármikor visszavonhatja az Ampache jelszavát és újat hozhat létre (sőt tobbfélét is használhat a különböző eszközeihez).","Invalid path":"Érvénytelen útvonal","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Kérjük vegye figyelembe, hogy az Ampache támogatás még nem tekinthető stabilnak, ez még csak tesztváltozat. <a href=\"https://github.com/owncloud/music/issues/60\">Ezen a webcímen</a> számolhat be a tapasztalatairól. Jó lenne minél több kliensprogrammal tesztelni a szolgáltatást. Köszönöm!","Music":"Zene","Next":"Következő","Path to your music collection":"A zenegyűjtemény útvonala","Pause":"Szünet","Play":"Lejátszás","Previous":"Előző","Repeat":"Ismétlés","Revoke API password":"API-jelszó visszavonása","Shuffle":"Keverés","Some not playable tracks were skipped.":"Néhány szám kimaradt, amit a rendszer nem tud lejátszani.","This setting specifies the folder which will be scanned for music.":"Ez a beállítás határozza meg, hogy melyik mappát figyelje a rendszer, amikor az zenei tartalmakat keresi.","Tracks":"Számok","Unknown album":"Ismeretlen album","Unknown artist":"Ismeretlen előadó","Use this address to browse your music collection from any Ampache compatible player.":"Ezt a címet használva a zenegyűjtemény bármely Ampache-kompatibilis lejátszóval böngészhető.","Use your username and following password to connect to this Ampache instance:":"Használja a felhasználónevét és a következő jelszót, ha csatlakozni kíván ehhez az Ampache kiszolgálóhoz:"});
    gettextCatalog.setStrings('hy', {"Albums":"Ալբոմներ","Artists":"Արտիստներ","Description":"Նկարագրություն","Description (e.g. App name)":"Նկարագրություն (օր.՝ App name)","Generate API password":"Գեներացնել API գաղտնաբառ","Invalid path":"Անվավեր ուղի","Music":"Երաժշտություն","Next":"Հաջորդ","Path to your music collection":"Քո երաժշտական հավաքածուի ուղին","Pause":"Կանգ","Play":"Նվագարկել","Previous":"Նախորդ","Repeat":"Կրկնել","Shuffle":"Խառը","Unknown album":"Անհայտ ալբոմ","Unknown artist":"Անհայտ հեղինակ","Volume":"Հատոր"});
    gettextCatalog.setStrings('ia', {"Description":"Description","Music":"Musica","Next":"Proxime","Pause":"Pausa","Play":"Reproducer","Previous":"Previe","Repeat":"Repeter"});
    gettextCatalog.setStrings('id', {"Albums":"Album","Artists":"Pembuat","Description":"Keterangan","Description (e.g. App name)":"Keterangan (cth. nama Aplikasi)","Generate API password":"Hasilkan sandi API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Disini Anda dapat menghasilkan sandi untuk digunakan dengan Ampache API, karena mereka tidak dapat disimpan dengan cara yang benar-benar aman karena desain Ampache API. Anda dapat menghasilkan banyak sandi yang Anda inginkan dan mencabut mereka kapan saja.","Invalid path":"Jalur lokasi salah.","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Harus diingat, bahwa Ampache API hanya pratinjau dan tidak stabil. Jangan ragu untuk melaporkan pengalaman Anda dengan fitur ini di <a href=\"https://github.com/owncloud/music/issues/60\">masalah yang sesuai</a>. Saya juga ingin memiliki daftar klien untuk menguji dengannya. Terima kasih","Music":"Musik","Next":"Berikutnya","Path to your music collection":"Jalur lokasi koleksi musik Anda","Pause":"Jeda","Play":"Putar","Previous":"Sebelumnya","Repeat":"Ulangi","Revoke API password":"Cabut sandi API","Shuffle":"Acak","Some not playable tracks were skipped.":"Beberapa trek yang tidak diputar akan dilewati.","This setting specifies the folder which will be scanned for music.":"Pengaturan ini menentukan folder yang akan dipindai untuk musik.","Tracks":"Trek","Unknown album":"Album tidak diketahui","Unknown artist":"Pembuat tidak diketahui","Use this address to browse your music collection from any Ampache compatible player.":"Gunakan alamat ini untuk meramban koleksi musik Anda dari pemutar yang kompatibel dengan Ampache.","Use your username and following password to connect to this Ampache instance:":"Gunakan nama pengguna dan sandi berikut untuk terhubung dengan instansi Ampache:"});
    gettextCatalog.setStrings('io', {});
    gettextCatalog.setStrings('is', {"+ New Playlist":"+ Nýr spilunarlisti","Albums":"Albúm","All tracks":"Öll lög","Artists":"Flytjandi","Click here to start the scan":"Smelltu hér til að hefja skönnun","Description":"Lýsing","Description (e.g. App name)":"Lýsing (t.d. heiti á forriti)","Generate API password":"Framleiða API-lykilorð","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Hér geturðu útbúið lykilorð til að nota með Ampache API, því ekki er hægt að geyma þau á algerlega öruggan máta vegna uppbyggingar Ampache API-samskiptareglnanna. Þú getur búið til eins mörg lykilorð og þér sýnist, og afturkallað þau hvenær sem er.","Invalid path":"Ógild slóð","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Hafðu í huga að Ampache API er bara sýnishorn og að það er óstöðugt. Þú mátt alveg segja frá reynslu þinni af notkun þess á tilheyrandi <a href=\"https://github.com/owncloud/music/issues/60\">færslu</a>. Það væri einnig gott að fá með lista yfir þau forrit sem hafa verið prófuð. Takk fyrir","Music":"Tónlist","New music available":"Ný tónlist í boði","New music available. Click here to reload the music library.":"Ný tónlist í boði. Smelltu hér til að endurhlaða tónlistarsafninu.","Next":"Næst","No music found":"Engin tónlist fannst","Path to your music collection":"Slóð á tónlistarsafnið þitt","Pause":"Í bið","Play":"Spila","Previous":"Fyrra","Repeat":"Endurtaka","Revoke API password":"Afturkalla API-lykilorð","Scanning music …":"Skanna tónlist …","Shuffle":"Stokka","Some not playable tracks were skipped.":"Sumum óspilanlegum hljóðsporum var sleppt.","This setting specifies the folder which will be scanned for music.":"Þetta tilgreinir möppuna þar sem leitað verður að tónlist.","Tracks":"Hljóðspor","Unknown album":"Óþekkt albúm","Unknown artist":"Óþekktur flytjandi","Upload music in the files app to listen to it here":"Sendu inn tónlist í skráaforritinu til að hlusta á hana hér","Use this address to browse your music collection from any Ampache compatible player.":"Notaðu þetta vistfang til að vafra um tónlistarsafnið þitt í öllum Ampache-samhæfðum spilurum.","Use your username and following password to connect to this Ampache instance:":"Notaðu notandanafn þitt og eftirfarandi aðgangsorð til að tengjast þessu Ampache-tilviki:","Volume":"Hljóðstyrkur","tracks":"lög","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} af {{ scanningTotal }}"});
    gettextCatalog.setStrings('it', {"+ New Playlist":"+ Nuova scaletta","Albums":"Album","All tracks":"Tutte le tracce","Artists":"Artisti","Click here to start the scan":"Fai clic qui per iniziare la scansione","Description":"Descrizione","Description (e.g. App name)":"Descrizione (ad es. Nome applicazione)","Generate API password":"Genera una password API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Qui puoi generare le password da utilizzare con l'API di Ampache, perché esse non possono essere memorizzate in maniera sicura a causa della forma dell'API di Ampache. Puoi generare tutte le password che vuoi e revocarle quando vuoi.","Invalid path":"Percorso non valido","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Ricorda, l'API di Ampache è solo un'anteprima e non è stabile. Sentiti libero di segnalare la tua esperienza con questa funzionalità nel corrispondente <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. Preferirei inoltre avere un elenco di client da provare. Grazie.","Music":"Musica","New music available":"Nuova musica disponibile","New music available. Click here to reload the music library.":"Nuova musica disponibile. Fai clic qui per ricaricare la raccolta musicale.","Next":"Successivo","No music found":"Nessun musica trovata","Path to your music collection":"Percorso alla tua collezione musicale","Pause":"Pausa","Play":"Riproduci","Previous":"Precedente","Repeat":"Ripeti","Revoke API password":"Revoca la password API","Scanning music …":"Scansione della musica...","Shuffle":"Mescola","Some not playable tracks were skipped.":"Alcune tracce non riproducibili sono state saltate.","This setting specifies the folder which will be scanned for music.":"Questa impostazione specifica la cartella che sarà analizzata alla ricerca di musica.","Tracks":"Tracce","Unknown album":"Album sconosciuto","Unknown artist":"Artista sconosciuto","Upload music in the files app to listen to it here":"Carica la musica nella App File per sentirla da qui","Use this address to browse your music collection from any Ampache compatible player.":"Usa questo indirizzo per sfogliare le tue raccolte musicali da qualsiasi lettore compatibile con Ampache.","Use your username and following password to connect to this Ampache instance:":"Utilizza il tuo nome utente e la password per collegarti a questa istanza di Ampache:","Volume":"Volume","tracks":"tracce","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} di {{ scanningTotal }}"});
    gettextCatalog.setStrings('ja_JP', {"+ New Playlist":"＋新しいプレイリスト","Albums":"アルバム","All tracks":"すべてのトラック","Artists":"アーティスト","Click here to start the scan":"ここをクリックしてスキャン開始","Description":"説明","Description (e.g. App name)":"説明 (例えばアプリケーション名)","Generate API password":"APIパスワードの生成","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"ここでは、Ampache APIに使用するパスワードを生成することができます。Ampache API のパスワードを本当に安全な方法では保管することができないからです。いつでも望むままに、いくつものパスワードを生成したり、それらを無効にしたりすることができます。","Invalid path":"無効なパス","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Ampache APIはまだプレビュー版で、まだ不安定ですので、注意してください。この機能について、 <a href=\"https://github.com/owncloud/music/issues/60\">issue</a> への動作結果報告を歓迎します。テスト済クライアントのリストも作成したいと考えていますので、よろしくお願いいたします。","Music":"ミュージック","New music available":"新しいミュージックが利用可能です","New music available. Click here to reload the music library.":"新しいミュージックが利用可能です。ここをクリックしてミュージックライブラリをリロード。","Next":"次","No music found":"ミュージックが見つかりません","Path to your music collection":"音楽コレクションのパス","Pause":"一時停止","Play":"再生","Previous":"前","Repeat":"繰り返し","Revoke API password":"API パスワードを無効にする","Scanning music …":"ミュージックをスキャン中...","Shuffle":"シャッフル","Some not playable tracks were skipped.":"一部の再生不可能なトラックをスキップしました。","This setting specifies the folder which will be scanned for music.":"この設定では、音楽ファイルをスキャンするフォルダーを指定します。","Tracks":"トラック","Unknown album":"不明なアルバム","Unknown artist":"不明なアーティスト","Upload music in the files app to listen to it here":"ファイルアプリからミュージックをアップロードするとここで聴けます。","Use this address to browse your music collection from any Ampache compatible player.":"あなたの音楽コレクションをAmpache対応プレイヤーから閲覧するには、このアドレスを使用してください。","Use your username and following password to connect to this Ampache instance:":"このAmpacheインスタンスに接続するには、あなたのユーザー名と以下のパスワードを使用してください:","Volume":"音量","tracks":"トラック","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningTotal }} 中 {{ scanningScanned }}"});
    gettextCatalog.setStrings('jv', {"Music":"Gamelan","Next":"Sak bare","Play":"Puter","Previous":"Sak durunge"});
    gettextCatalog.setStrings('ka_GE', {"Description":"გვერდის დახასიათება","Music":"მუსიკა","Next":"შემდეგი","Pause":"პაუზა","Play":"დაკვრა","Previous":"წინა","Repeat":"გამეორება"});
    gettextCatalog.setStrings('ka', {});
    gettextCatalog.setStrings('km', {"Albums":"អាល់ប៊ុម","Artists":"សិល្បករ","Description":"ការ​អធិប្បាយ","Description (e.g. App name)":"ការ​អធិប្បាយ (ឧ. ឈ្មោះ​កម្មវិធី)","Generate API password":"បង្កើត​ពាក្យ​សម្ងាត់ API","Invalid path":"ទីតាំង​មិន​ត្រឹម​ត្រូវ","Music":"តន្ត្រី","Next":"បន្ទាប់","Pause":"ផ្អាក","Play":"លេង","Previous":"មុន","Repeat":"ធ្វើម្ដងទៀត","Shuffle":"បង្អូស","Tracks":"បទ","Unknown album":"អាល់ប៊ុមអត់​ឈ្មោះ","Unknown artist":"សិល្បករអត់​ឈ្មោះ"});
    gettextCatalog.setStrings('kn', {"Next":"ಮುಂದೆ"});
    gettextCatalog.setStrings('ko', {"+ New Playlist":"+ 새 재생 목록","Albums":"앨범","All tracks":"모든 곡","Artists":"음악가","Click here to start the scan":"검색을 시작하려면 누르십시오","Description":"설명","Description (e.g. App name)":"설명(예: 앱 이름)","Generate API password":"API 암호 생성","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ampache API가 설계된 방법 때문에 Ampache API에 사용할 암호를 완전히 안전한 형태로 저장할 수 없습니다. Ampache API에 사용할 암호를 여기에서 생성하십시오. 필요한 만큼 암호를 생성하고 언제든지 취소할 수 있습니다.","Invalid path":"잘못된 경로","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Ampache API는 아직까지 완전하지 않습니다. 이 기능을 사용하면서 느낀 점을 <a href=\"https://github.com/owncloud/music/issues/60\">보고</a>해 주십시오. 테스트할 클라이언트에 대해서 알려 주셔도 좋습니다. 감사합니다.","Music":"음악","New music available":"새 음악을 사용할 수 있음","New music available. Click here to reload the music library.":"새 음악을 사용할 수 있습니다. 여기를 누르면 라이브러리를 새로 고칩니다.","Next":"다음","No music found":"음악을 찾을 수 없음","Path to your music collection":"내 음악 모음집 경로","Pause":"일시 정지","Play":"재생","Previous":"이전","Repeat":"반복","Revoke API password":"API 암호 취소","Scanning music …":"음악 검색 중 …","Shuffle":"임의 재생","Some not playable tracks were skipped.":"재생할 수 없는 곡을 건너뛰었습니다.","This setting specifies the folder which will be scanned for music.":"이 설정은 음악을 검색할 폴더를 지정합니다.","Tracks":"곡","Unknown album":"알 수 없는 앨범","Unknown artist":"알 수 없는 음악가","Upload music in the files app to listen to it here":"파일 앱에 음악을 업로드하면 여기에서 들을 수 있습니다","Use this address to browse your music collection from any Ampache compatible player.":"Ampache와 호환되는 음악 재생기에 이 주소를 입력하면 음악 모음집을 들을 수 있습니다.","Use your username and following password to connect to this Ampache instance:":"이 Ampache 인스턴스에 연결하려면 사용자 이름과 다음 암호를 사용하십시오:","Volume":"음량","tracks":"곡","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }}/{{ scanningTotal }}"});
    gettextCatalog.setStrings('ku_IQ', {"Description":"پێناسه","Music":"مۆسیقا","Next":"دوواتر","Pause":"وه‌ستان","Play":"لێدان","Previous":"پێشووتر"});
    gettextCatalog.setStrings('lb', {"Albums":"Album","Artists":"Artist","Description":"Beschreiwung","Music":"Musek","Next":"Weider","Pause":"Paus","Play":"Ofspillen","Previous":"Zeréck","Repeat":"Widderhuelen"});
    gettextCatalog.setStrings('lo', {});
    gettextCatalog.setStrings('lt_LT', {"Albums":"Albumai","Artists":"Atlikėjai","Description":"Aprašymas","Generate API password":"Sugeneruoti API slaptažodį","Invalid path":"Netinkamas kelias","Music":"Muzika","Next":"Kitas","Pause":"Pristabdyti","Play":"Groti","Previous":"Ankstesnis","Repeat":"Kartoti","Shuffle":"Maišyti","Unknown album":"Nežinomas albumas","Unknown artist":"Nežinomas atlikėjas"});
    gettextCatalog.setStrings('lv', {"Description":"Apraksts","Music":"Mūzika","Next":"Nākamā","Pause":"Pauzēt","Play":"Atskaņot","Previous":"Iepriekšējā","Repeat":"Atkārtot"});
    gettextCatalog.setStrings('mg', {});
    gettextCatalog.setStrings('mk', {"Albums":"Албуми","Artists":"Артисти","Description":"Опис","Description (e.g. App name)":"Опис (нпр. име на апликацијата)","Generate API password":"Генерирај API лозинка","Invalid path":"Грешна патека","Music":"Музика","Next":"Следно","Path to your music collection":"Патека до вашата музичка колекција","Pause":"Пауза","Play":"Пушти","Previous":"Претходно","Repeat":"Повтори","Revoke API password":"Отповикај ја API лозинката","Shuffle":"Помешај","Some not playable tracks were skipped.":"Некои песни кои не можеа да се пуштат беа прескокнати.","This setting specifies the folder which will be scanned for music.":"Овие поставки го одредуваат фолдерот кој ќе биде прегледан за музика.","Tracks":"Песна","Unknown album":"Непознат албум","Unknown artist":"Непознат артист"});
    gettextCatalog.setStrings('ml_IN', {"Music":"സംഗീതം","Next":"അടുത്തത്","Pause":" നിറുത്ത്","Play":"തുടങ്ങുക","Previous":"മുന്‍പത്തേത്"});
    gettextCatalog.setStrings('ml', {});
    gettextCatalog.setStrings('mn', {"Albums":"Цомог","Artists":"Хамтлаг/Дуучин","Description":"Тайлбар"});
    gettextCatalog.setStrings('mr', {});
    gettextCatalog.setStrings('ms_MY', {"Description":"Keterangan","Music":"Muzik","Next":"Seterus","Pause":"Jeda","Play":"Main","Previous":"Sebelum","Repeat":"Ulang","Shuffle":"Kocok"});
    gettextCatalog.setStrings('mt_MT', {});
    gettextCatalog.setStrings('my_MM', {"Albums":"သီချင်းခွေများ","Artists":"အဆိုတော်များ","Description":"ဖော်ပြချက်","Description (e.g. App name)":"ဖော်ြပချက်(ဥပမာ App ကိုအမည်)","Generate API password":"API ၏ လျှို့ဝှက်သ‌ေကၤတ ကို အလိုလျှာက်ြပပါ","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ampache API နှင့် အသုံးပြုရန် စကားဝှက်များကို ဒီနေရာတွင် ဖန်တီးပါ အ‌‌ေြကာင်းက Ampache API ၏ ဒီဇိုင်း ‌ေြကာင့် သူတို့ကို လုံြခံု အောင် မသိမ်းပေးထားနိုင်ပါ။ သင့် စိတ်ြကိုက် စကားဝှက် တွေ လိုသလောက် ဖန်တီးပါ မလိုချိန်မှာ အချိန်မရွေး ြပန်ဖျက်နိုင်ပါတယ်။","Invalid path":"လမ်း‌ေြကာင်းမှား","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"စိတ်ထဲ မှတ်ထား ပေး ပါ၊ Ampache API သည် အြပသက်သက် အဆင့် ပဲ ရှိသေးတာမို့ တည်ြငိမ်မှု မရှိေသးပါ။ သင့် သဘောကျ  ဆီလျှာ် တဲ့ <a href=\"https://github.com/owncloud/music/issues/60\"> အ‌ချက် </a>အြဖဟ် သင့် အတွေ့ အၾကံု ကို သတင်းပိုေပး ပါ။ သုံးစွဲသူ အများ နှင့် စမ်းသပ် ရတာ ကျွန်ုပ် လဲ နှစ်သက် ပါတယ်။ ကျေးဇူးပါ","Music":"သီခ်င္း","Next":"ရှေ့သို့","Path to your music collection":"သင် ၏ တေးဂီတ စုစည်းမှု လမ်း‌ေြကာင်း","Pause":"ခေတ္တရပ်","Play":"ဖွင့်","Previous":"နောက်သို့","Repeat":"အြကိမ်ြကိမ်","Revoke API password":"API စကားဝှက်ကိုပြန်ရုတ်သိမ်း","Shuffle":"ရောမွှေ","Some not playable tracks were skipped.":"တချို့ သော အပုဒ်များ ဖွင့်မရ၍ ကျော်ခဲ့သည်။","This setting specifies the folder which will be scanned for music.":"ဒီ အထူးပြု ဆက်တင် ရှိ ဖိုဒါ မှ တေးသီချင်း ကိုရှာဖွေပါလိမ့်မည်။","Tracks":"အပုဒ်များ","Unknown album":"အမည်မသိ သီချင်းခွေ","Unknown artist":"အမည်မသိ အဆိုတော်","Use this address to browse your music collection from any Ampache compatible player.":"Ampache နှင့် သဟဇာတ ြဖစ်သော မည်သည့် သီချင်းဖွင့် စက် မှ မဆို ဤ လိပ်စာကို သုံး၍ သင့် သီချင်း စုစည်းမှု့ ကို ရယူပါ။","Use your username and following password to connect to this Ampache instance:":"သင့် အသုံးြပုသူ အမည် နှင့် အောက်ဖော်ြပ ပါ လှို့ဝှက် စကား ကို ရိုက်၍ Ampache နှင့် ချက်ချင်း ချိတ်ဆက်ပါ"});
    gettextCatalog.setStrings('nb_NO', {"+ New Playlist":"+ Ny spilleliste","Albums":"Album","All tracks":"Alle spor","Artists":"Artister","Click here to start the scan":"Klikk her for å starte skanningen","Description":"Beskrivelse","Description (e.g. App name)":"Beskrivelse (f.eks. applikasjonsnavn)","Generate API password":"Generer API-passord","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Her kan du generere passord som kan brukes med Ampache API, fordi de ikke kan lagres på en virkelig sikker måte pga. utformingen av Ampache API. Du kan generere så mange passord som du vil og trekke dem tilbake når som helst.","Invalid path":"Individuell sti","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Vær klar over at Ampache API bare er en forhåndsversjon og er ustabil. Rapporter gjerne dine erfaringer med denne funksjonen i den tilhørende <a href=\"https://github.com/owncloud/music/issues/60\">saken</a>. Jeg vil også gjerne ha en liste over klienter som jeg kan teste med. Takk","Music":"Musikk","New music available":"ny musikk tilgjengelig","New music available. Click here to reload the music library.":"Ny musikk er tilgengelig. Klikk her for å laste biblioteket på nytt.","Next":"Neste","No music found":"Ingen musikk funnet","Path to your music collection":"Sti til din musikksamling","Pause":"Pause","Play":"Spill","Previous":"Forrige","Repeat":"Gjenta","Revoke API password":"Tilbakestill API-passord","Scanning music …":"Skanner musikk ...","Shuffle":"Tilfeldig","Some not playable tracks were skipped.":"Noen ikke-spillbare spor ble hoppet over.","This setting specifies the folder which will be scanned for music.":"Denne innstillingen spesifiserer mappen som vil bli skannet for musikk.","Tracks":"Spor","Unknown album":"Ukjent album","Unknown artist":"Ukjent artist","Upload music in the files app to listen to it here":"Last opp musikk i Filer-appen for å lytte til den her","Use this address to browse your music collection from any Ampache compatible player.":"Bruk denne adressen til å bla gjennom din musikksamling fra hvilket som helst Ampache-kompitabelt lag.","Use your username and following password to connect to this Ampache instance:":"Benytt ditt brukernavn og følgende passord for å koble til denne Ampache-forekomsten:","Volume":"Lydstyrke","tracks":"spor","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} av {{ scanningTotal }}"});
    gettextCatalog.setStrings('nb', {"+ New Playlist":"+ Ny spilleliste","Albums":"Album","All tracks":"Alle spor","Artists":"Artister","Click here to start the scan":"Klikk her for å starte skanningen","Description":"Beskrivelse","Description (e.g. App name)":"Beskrivelse (f.eks. applikasjonsnavn)","Generate API password":"Generer API-passord","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Her kan du generere passord som kan brukes med Ampache API, fordi de ikke kan lagres på en virkelig sikker måte pga. utformingen av Ampache API. Du kan generere så mange passord som du vil og trekke dem tilbake når som helst.","Invalid path":"Individuell sti","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Vær klar over at Ampache API bare er en forhåndsversjon og er ustabil. Rapporter gjerne dine erfaringer med denne funksjonen i den tilhørende <a href=\"https://github.com/owncloud/music/issues/60\">saken</a>. Jeg vil også gjerne ha en liste over klienter som jeg kan teste med. Takk","Music":"Musikk","New music available":"ny musikk tilgjengelig","New music available. Click here to reload the music library.":"Ny musikk er tilgengelig. Klikk her for å laste biblioteket på nytt.","Next":"Neste","No music found":"Ingen musikk funnet","Path to your music collection":"Sti til din musikksamling","Pause":"Pause","Play":"Spill","Previous":"Forrige","Repeat":"Gjenta","Revoke API password":"Tilbakestill API-passord","Scanning music …":"Skanner musikk ...","Shuffle":"Tilfeldig","Some not playable tracks were skipped.":"Noen ikke-spillbare spor ble hoppet over.","This setting specifies the folder which will be scanned for music.":"Denne innstillingen spesifiserer mappen som vil bli skannet for musikk.","Tracks":"Spor","Unknown album":"Ukjent album","Unknown artist":"Ukjent artist","Upload music in the files app to listen to it here":"Last opp musikk i Filer-appen for å lytte til den her","Use this address to browse your music collection from any Ampache compatible player.":"Bruk denne adressen til å bla gjennom din musikksamling fra hvilket som helst Ampache-kompitabelt lag.","Use your username and following password to connect to this Ampache instance:":"Benytt ditt brukernavn og følgende passord for å koble til denne Ampache-forekomsten:","Volume":"Lydstyrke","tracks":"spor","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} av {{ scanningTotal }}"});
    gettextCatalog.setStrings('nds', {"Next":"Nächtes","Pause":"Pause","Play":"Play","Previous":"Vorheriges"});
    gettextCatalog.setStrings('ne', {});
    gettextCatalog.setStrings('nl', {"+ New Playlist":"+ Nieuwe afspeellijst","Albums":"Albums","All tracks":"Alle nummers","Artists":"Artiesten","Click here to start the scan":"Klik hier om de scan te starten","Description":"Beschrijving","Description (e.g. App name)":"Beschrijving (bijv. appnaam)","Generate API password":"Genereren API wachtwoord","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Hier kunt u wachtwoorden genereren voor gebruik met de Ampache API, omdat ze door het ontwerp van de Ampache API niet op een echt veilige manier kunnen worden bewaard. U kunt zoveel wachtwoorden genereren als u wilt en ze op elk moment weer intrekken.","Invalid path":"Ongeldig pad","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Vergeet niet dat de Ampache API volop in ontwikkeling is en dus instabiel is. Rapporteer gerust uw ervaringen met deze functionaliteit in deze <a href=\"https://github.com/owncloud/music/issues/60\">melding</a>. Ik zou ook graag een lijst met clients hebben om te kunnen testen. Bij voorbaat dank!","Music":"Muziek","New music available":"Nieuwe muziek beschikbaar","New music available. Click here to reload the music library.":"Nieuwe muziek beschikbaar. Klik hier om de muziekbibliotheek te herladen.","Next":"Volgende","No music found":"Geen muziek gevonden","Path to your music collection":"Pad naar uw muziekverzameling","Pause":"Pause","Play":"Afspelen","Previous":"Vorige","Repeat":"Herhaling","Revoke API password":"Intrekken API wachtwoord","Scanning music …":"Scannen muziek …","Shuffle":"Shuffle","Some not playable tracks were skipped.":"Sommige niet af te spelen nummers werden overgeslagen.","This setting specifies the folder which will be scanned for music.":"De instelling bepaalt de map die wordt gescand op muziek.","Tracks":"Nummers","Unknown album":"Onbekend album","Unknown artist":"Onbekende artiest","Upload music in the files app to listen to it here":"Upload muziek in de bestandsapp, om hier te luisteren","Use this address to browse your music collection from any Ampache compatible player.":"Gebruik dit adres om door uw muziekverzameling te bladeren vanaf elke Ampache compatibele speler.","Use your username and following password to connect to this Ampache instance:":"Gebruik uw gebruikersnaam en het volgende wachtwoord om te verbinden met deze Ampache installatie:","Volume":"Volume","tracks":"nummers","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} van {{ scanningTotal }}"});
    gettextCatalog.setStrings('nn_NO', {"Description":"Skildring","Music":"Musikk","Next":"Neste","Pause":"Pause","Play":"Spel","Previous":"Førre","Repeat":"Gjenta"});
    gettextCatalog.setStrings('nqo', {});
    gettextCatalog.setStrings('oc', {"Albums":"Albums","Artists":"Artistas","Description":"Descripcion","Description (e.g. App name)":"Descripcion (ex. nom de l'aplicacion)","Generate API password":"Generar un senhal de l'API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aicí, podètz generar de senhals d'utilizar amb l'API Ampache, perque pòdon èsser emmagazinats d'un biais securizat en rason de la concepcion de l'API d'Ampache. Podètz generar autant de senhals coma volètz e los podètz revocar a tot moment.","Invalid path":"Camin invalid","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Gardatz en memòria que l'API Ampache es una avantprimièra e es pas encara establa. Trantalhetz pas a donar un retorn d'experiéncia d'aquesta foncionalitat <a href=\"https://github.com/owncloud/music/issues/60\">sus la pagina dedicada</a>. Nos agradariá tanbzn d'obténer una lista dels clients amb los quals podèm testar. Mercé.","Music":"Musica","Next":"Seguent","Path to your music collection":"Camin cap a vòstra colleccion de musica","Pause":"Pausa","Play":"Legir","Previous":"Precedent","Repeat":"Repetir","Revoke API password":"Revocar lo senhal de l'API","Shuffle":"Lectura aleatòria","Some not playable tracks were skipped.":"Certanas pistas pas jogables son estadas ignoradas.","This setting specifies the folder which will be scanned for music.":"Aqueste paramètre especifica quin dorsièr serà balejat per trobar de musica.","Tracks":"Pistas","Unknown album":"Album desconegut","Unknown artist":"Artista desconegut","Use this address to browse your music collection from any Ampache compatible player.":"Utilizatz aquesta adreça per navigar dins vòstra colleccion musicala amb un client compatible Ampache.","Use your username and following password to connect to this Ampache instance:":"Utilizatz vòstre nom d'utilizaire e lo senhal seguent per vos connectar a aquesta instància d'Ampache : "});
    gettextCatalog.setStrings('or_IN', {});
    gettextCatalog.setStrings('pa', {"Music":"ਸੰਗੀਤ"});
    gettextCatalog.setStrings('pl', {"+ New Playlist":"+ Nowa Lista odtwarzania","Albums":"Albumy","All tracks":"Wszystkie ściezki","Artists":"Artyści","Click here to start the scan":"Kliknij tutaj aby rozpocząć skanowanie","Description":"Opis","Description (e.g. App name)":"Opis (np. Nazwa aplikacji)","Generate API password":"Wygeneruj hasło API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Tutaj możesz wygenerować hasła do używania API Ampache, ponieważ nie mogą one być przechowywane w rzeczywiście bezpieczny sposób z powodu architektury API Ampache. Możesz wygenerować tyle haseł ile chcesz i odwołać je w dowolnym momencie.","Invalid path":"niewłaściwa ścieżka","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Miej na uwadze, że API Ampache jest tylko poglądowe i niestabilne. Możesz swobodnie raportować swoje doświadczenia z tą funkcją w odpowiednim <a href=\"https://github.com/owncloud/music/issues/60\">dokumencie</a>. Chciałbym mieć również listę klientów z którymi będę przeprowadzać testy. Dzięki","Music":"Muzyka","New music available":"Dostępne są nowe utwory","New music available. Click here to reload the music library.":"Dostępne są nowe utwory. Kliknij tutaj aby załadować ponownie bibliotekę muzyki.","Next":"Następny","No music found":"Nie znaleziono muzyki","Path to your music collection":"Ścieżka do Twojej kolekcji muzyki","Pause":"Wstrzymaj","Play":"Odtwarzaj","Previous":"Poprzedni","Repeat":"Powtarzaj","Revoke API password":"Odwołaj hasło API","Scanning music …":"Skanowanie muzyki ...","Shuffle":"Losowo","Some not playable tracks were skipped.":"Niektóre nieodtwarzalne ścieżki zostały pominięte.","This setting specifies the folder which will be scanned for music.":"To ustawienie określa folder, który będzie skanowany pod kątem muzyki.","Tracks":"Utwory","Unknown album":"Nieznany album","Unknown artist":"Nieznany artysta","Upload music in the files app to listen to it here":"Aby wysłuchać muzykę w plikach aplikacji, należy je tam wgrać","Use this address to browse your music collection from any Ampache compatible player.":"Użyj tego adresu aby przeglądać swoją kolekcję muzyczną na dowolnym odtwarzaczu kompatybilnym z Ampache.","Use your username and following password to connect to this Ampache instance:":"Użyj nazwy użytkownika i następującego hasła do połączenia do tej instancji Ampache:","Volume":"Głośność","tracks":"ścieżki","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} z {{ scanningTotal }}"});
    gettextCatalog.setStrings('pt_BR', {"+ New Playlist":"+ Nova playlist","Albums":"Albuns","All tracks":"Todas as faixas","Artists":"Artistas","Click here to start the scan":"Clique aqui para iniciar a busca","Description":"Descrição","Description (e.g. App name)":"Descrição (por exemplo, nome do App)","Generate API password":"Gerar senha API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aqui você pode gerar senhas para usar com a API Ampache, porque eles não podem ser armazenados de uma forma muito segura devido ao design da API Ampache. Você pode gerar o maior número de senhas que você quiser e revogá-las a qualquer hora.","Invalid path":"Caminho inválido","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Tenha em mente, que a API Ampache é apenas uma pré-visualização e é instável. Sinta-se livre para relatar sua experiência com esse recurso na questão correspondente <a href=\"https://github.com/owncloud/music/issues/60\">assunto</a>. Eu também gostaria de ter uma lista de clientes para testar. obrigado","Music":"Música","New music available":"Nova música disponível","New music available. Click here to reload the music library.":"Nova música disponível. Clique aqui para recarregar a coleção.","Next":"Próxima","No music found":"Nenhuma música encontrada","Path to your music collection":"Caminho para a sua coleção de músicas","Pause":"Pausa","Play":"Reproduzir","Previous":"Anterior","Repeat":"Repetir","Revoke API password":"Revogar senha API","Scanning music …":"Buscando música ...","Shuffle":"Embaralhar","Some not playable tracks were skipped.":"Algumas faixas não reproduzíveis ​​foram ignoradas.","This setting specifies the folder which will be scanned for music.":"Esta configuração especifica a pasta que será escaneada por músicas.","Tracks":"Trilhas","Unknown album":"Album desconhecido","Unknown artist":"Artista desconhecido","Upload music in the files app to listen to it here":"Envie músicas com o aplicativo de arquivos para escutá-las aqui","Use this address to browse your music collection from any Ampache compatible player.":"Utilize este endereço para navegar por sua coleção de música a partir de qualquer leitor compatível com Ampache.","Use your username and following password to connect to this Ampache instance:":"Use o seu nome de usuário e senha a seguir para se conectar a essa instância Ampache:","Volume":"Volume","tracks":"faixas","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} de {{ scanningTotal }}"});
    gettextCatalog.setStrings('pt_PT', {"+ New Playlist":"+ Nova Lista de Reprodução","Albums":"Álbuns","All tracks":"Todas as faixas","Artists":"Artistas","Click here to start the scan":"Clique aqui para iniciar a pesquisa","Description":"Descrição","Description (e.g. App name)":"Descrição (ex: Nome da Aplicação)","Generate API password":"Gerar palavra-passe da API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aqui pode gerar as palavras-passe para utilizar com a API do Ampache, porque elas não podem ser guardadas de um modo realmente seguro devido ao desenho da API do Ampache. Pode gerar as palavras-passe que quiser e revogá-las em qualquer altura.","Invalid path":"Caminho inválido","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Lembre-se que a API do Ampache é apenas provisória e instável. Esteja à vontade para relatar a sua experiência com esta característica na <a href=\"https://github.com/owncloud/music/issues/60\">questão</a> correspondente. Também gostaria de ter uma lista de clientes para testar. Obrigado","Music":"Música","New music available":"Nova música disponivel","New music available. Click here to reload the music library.":"Nova música disponivel. Clique aqui para recarregar a biblioteca de músicas.","Next":"Seguinte","No music found":"Nenhuma música encontrada","Path to your music collection":"Caminho para a sua coleção de música","Pause":"Pausa","Play":"Reproduzir","Previous":"Anterior","Repeat":"Repetir","Revoke API password":"Revogar palavra-passe da API","Scanning music …":"A pesquisar música...","Shuffle":"Baralhar","Some not playable tracks were skipped.":"Foram ignoradas algumas faixas com problemas","This setting specifies the folder which will be scanned for music.":"Esta definição especifica a pasta onde vai ser rastreada a música.","Tracks":"Faixas","Unknown album":"Álbum desconhecido","Unknown artist":"Artista desconhecido","Upload music in the files app to listen to it here":"Envie música na aplicação de ficheiros para as ouvir aqui","Use this address to browse your music collection from any Ampache compatible player.":"Utilize este endereço para navegar na sua coleção de música em qualquer leitor compatível com o Ampache.","Use your username and following password to connect to this Ampache instance:":"Use o seu nome de utilizador e a seguinte palavra-passe para ligar a esta instância do Ampache:","Volume":"Volume","tracks":"faixas","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} de {{ scanningTotal }}"});
    gettextCatalog.setStrings('ro', {"Albums":"Albume","Artists":"Artiști","Description":"Descriere","Description (e.g. App name)":"Descriere (ex. Numele aplicației)","Generate API password":"Generează parolă API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Aici poți genera parole pentru a le folosi în API-ul Ampache, deoarece ele nu pot fi stocate într-un mod securizat din cauza construcției API-ului Ampache. Poți genera oricâte parole vrei și le poți revoca oricând.","Invalid path":"Cale invalidă","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Ține minte faptul că API-ul Ampache este doar în perioada de test și nu este stabil. Simte-te liber să ne împărtășești experiențele tale cu această funcționalitate la această <a href=\"https://github.com/owncloud/music/issues/60\">pagină</a>. Am dori de asemenea să avem o listă cu clienți pe care să putem efectua teste. Mulțumim","Music":"Muzică","Next":"Următor","Path to your music collection":"Calea spre colecția cu muzica dvs.","Pause":"Pauză","Play":"Redă","Previous":"Anterior","Repeat":"Repetă","Revoke API password":"Revocă parola API","Shuffle":"Amestecă","Some not playable tracks were skipped.":"Unele piese care nu pot fi redate au fost sărite.","This setting specifies the folder which will be scanned for music.":"Această setare specifică directorul în care se vor căuta fișiere audio.","Tracks":"Piese","Unknown album":"Album necunoscut","Unknown artist":"Artist necunoscut","Use this address to browse your music collection from any Ampache compatible player.":"Folosește această adresă pentru a naviga în colecția ta muzicală din orice unealtă de redare audio.","Use your username and following password to connect to this Ampache instance:":"Folosește numele tău de utilizator și parola următoare pentru a te conecta la această instanță Ampache:"});
    gettextCatalog.setStrings('ru', {"+ New Playlist":"+ Новый плейлист","Albums":"Альбомы","All tracks":"Все дорожки","Artists":"Исполнители","Click here to start the scan":"Кликните здесь, чтобы начать сканирование","Description":"Описание","Description (e.g. App name)":"Описание (например Название приложения)","Generate API password":"Генерация пароля для API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Здесь вы можете генерировать пароли для использования API Ampache, так как они не могут быть сохранены действительно безопасным способом из-за особенностей API Ampache. Вы можете создать столько паролей, сколько необходимо, и отказаться от них в любое время.","Invalid path":"Некорректный путь","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Следует помнить, что API Ampache является предварительной и поэтому неустойчивой реализацией. Не стесняйтесь делиться опытом работы с этой функцией в соответствующем <a href=\"https://github.com/owncloud/music/issues/60\">разделе</a>. Я также хотел бы создать список клиентов для тестирования. Спасибо","Music":"Музыка","New music available":"Доступна новая музыка","New music available. Click here to reload the music library.":"Доступна новая музыка. Кликните здесь, чтобы перезагрузить музыкальную библиотеку.","Next":"Следующий","No music found":"Музыка не найдена","Path to your music collection":"Путь до вашей музыкальной коллекции","Pause":"Пауза","Play":"Проиграть","Previous":"Предыдущий","Repeat":"Повтор","Revoke API password":"Отозвать пароль для API","Scanning music …":"Сканирую музыку…","Shuffle":"Перемешать","Some not playable tracks were skipped.":"Некоторые не проигрываемые композиции были пропущены.","This setting specifies the folder which will be scanned for music.":"Эта настройка определяет каталог, в котором будет проведено сканирование музыки.","Tracks":"Композиции","Unknown album":"Неизвестный альбом","Unknown artist":"Неизвестный исполнитель","Upload music in the files app to listen to it here":"Закачайте музыку в приложении Файлы, чтобы послушать её здесь","Use this address to browse your music collection from any Ampache compatible player.":"Используйте этот адрес, чтобы просмотреть вашу музыкальную коллекцию с любого плеера совместимого с Ampache.","Use your username and following password to connect to this Ampache instance:":"Используйте свой логин и пароль ниже для подключения к данному экземпляру Ampache:","Volume":"Громкость","tracks":"дорожки","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} из {{ scanningTotal }}"});
    gettextCatalog.setStrings('si_LK', {"Description":"විස්තරය","Music":"සංගීතය","Next":"ඊලඟ","Pause":"විරාමය","Play":"ධාවනය","Previous":"පෙර","Repeat":"පුනරාවර්ථන"});
    gettextCatalog.setStrings('sk_SK', {"Albums":"Albumy","Artists":"Interpreti","Description":"Popis","Description (e.g. App name)":"Popis (napr. App name)","Generate API password":"Vygenerovanie hesla API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Tu môžete vytvárať heslá pre Ampache API, pretože tieto nemôžu byť uložené skutočne bezpečným spôsobom z dôvodu dizajnu Ampache API. Je možné vygenerovať ľubovoľné množstvo hesiel a kedykoľvek ich zneplatniť.","Invalid path":"Neplatná cesta","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Myslite na to, že Ampache API je stále vo vývoji a nie je stabilné. Môžete nás informovať o skúsenostiach s touto funkciou odoslaním hlásenia v príslušnom <a href=\"https://github.com/owncloud/music/issues/60\">tikete</a>. Chcel by som tiež zostaviť zoznam záujemcov o testovanie. Vďaka","Music":"Hudba","Next":"Ďalšia","Path to your music collection":"Cesta k vašej hudobnej zbierke","Pause":"Pauza","Play":"Prehrať","Previous":"Predošlá","Repeat":"Opakovať","Revoke API password":"Zneplatniť heslo API","Shuffle":"Zamiešať","Some not playable tracks were skipped.":"Niektoré neprehrateľné skladby boli vynechané.","This setting specifies the folder which will be scanned for music.":"Toto nastavenie určuje priečinok, v ktorom bude vyhľadaná hudba.","Tracks":"Skladby","Unknown album":"Neznámy album","Unknown artist":"Neznámy umelec","Use this address to browse your music collection from any Ampache compatible player.":"Použite túto adresu pre prístup k hudobnej zbierke z akéhokoľvek prehrávača podporujúceho Ampache.","Use your username and following password to connect to this Ampache instance:":"Použite svoje používateľské meno a heslo pre pripojenie k tejto inštancii Ampache:"});
    gettextCatalog.setStrings('sk', {"Albums":"Albumy","Artists":"Interpreti","Description":"Popis","Description (e.g. App name)":"Popis (napr. App name)","Generate API password":"Vygenerovanie hesla API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Tu môžete vytvárať heslá pre Ampache API, pretože tieto nemôžu byť uložené skutočne bezpečným spôsobom z dôvodu dizajnu Ampache API. Je možné vygenerovať ľubovoľné množstvo hesiel a kedykoľvek ich zneplatniť.","Invalid path":"Neplatná cesta","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Myslite na to, že Ampache API je stále vo vývoji a nie je stabilné. Môžete nás informovať o skúsenostiach s touto funkciou odoslaním hlásenia v príslušnom <a href=\"https://github.com/owncloud/music/issues/60\">tikete</a>. Chcel by som tiež zostaviť zoznam záujemcov o testovanie. Vďaka","Music":"Hudba","Next":"Ďalšia","Path to your music collection":"Cesta k vašej hudobnej zbierke","Pause":"Pauza","Play":"Prehrať","Previous":"Predošlá","Repeat":"Opakovať","Revoke API password":"Zneplatniť heslo API","Shuffle":"Zamiešať","Some not playable tracks were skipped.":"Niektoré neprehrateľné skladby boli vynechané.","This setting specifies the folder which will be scanned for music.":"Toto nastavenie určuje priečinok, v ktorom bude vyhľadaná hudba.","Tracks":"Skladby","Unknown album":"Neznámy album","Unknown artist":"Neznámy umelec","Use this address to browse your music collection from any Ampache compatible player.":"Použite túto adresu pre prístup k hudobnej zbierke z akéhokoľvek prehrávača podporujúceho Ampache.","Use your username and following password to connect to this Ampache instance:":"Použite svoje používateľské meno a heslo pre pripojenie k tejto inštancii Ampache:"});
    gettextCatalog.setStrings('sl', {"+ New Playlist":"+ Nov seznam predvajanja","Albums":"Albumi","All tracks":"Vsi posnetki","Artists":"Izvajalci","Click here to start the scan":"Kliknite za začetek preiskovanja za nove predmete","Description":"Opis","Description (e.g. App name)":"Opis (na primer ime programa)","Generate API password":"Ustvari geslo API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"TU je mogoče ustvariti gesla za uporabo z Ampache API, ker jih ni mogoče shraniti na resnično varen način, zaradi programske zasnove Ampache. Dovoljeno je ustvariti poljubno število gesel, do katerih je neomejen dostop.","Invalid path":"Neveljavna pot","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Imejte v mislih, da je Ampache API namenjen le predogledu in ni povsem stabilna programska oprema. Vaših odzivov in izkušenj o uporabi bomo zelo veseli. Objavite jih prek <a href=\"https://github.com/owncloud/music/issues/60\">spletnega obrazca</a>. Priporočljivo je dodati tudi seznam odjemalcev. Za sodelovanje se vam vnaprej najlepše zahvaljujemo.","Music":"Glasba","New music available":"Na voljo je nova glasba","New music available. Click here to reload the music library.":"Na voljo je nova glasba. Kliknite za ponovno nalaganje glasbene zbirke.","Next":"Naslednja","No music found":"Ni zaznanih glasbenih datotek","Path to your music collection":"Pot do zbirke glasbe","Pause":"Premor","Play":"Predvajaj","Previous":"Predhodna","Repeat":"Ponovi","Revoke API password":"Razveljavi geslo API","Scanning music …":"Poteka preiskovanje glasbe ...","Shuffle":"Premešaj","Some not playable tracks were skipped.":"Nekateri posnetki, ki jih ni mogoče predvajati, so bili preskočeni.","This setting specifies the folder which will be scanned for music.":"Nastavitev določa mapo, ki bo preiskana za glasbo.","Tracks":"Sledi","Unknown album":"Neznan album","Unknown artist":"Neznan izvajalec","Upload music in the files app to listen to it here":"Pošljite glasbene datoteke v oblak za predvajanje","Use this address to browse your music collection from any Ampache compatible player.":"Uporabite ta naslov za brskanje po zbirki glasbe preko kateregakoli predvajalnika, ki podpira sistem Ampache.","Use your username and following password to connect to this Ampache instance:":"Uporabite uporabniško ime in navedeno geslo za povezavo z Ampache:","Volume":"Glasnost","tracks":"posnetki","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} od {{ scanningTotal }}"});
    gettextCatalog.setStrings('sq', {"+ New Playlist":"+ Luajlistë e Re","Albums":"Albume","All tracks":"Krejt pjesët","Artists":"Artistë","Click here to start the scan":"Klikoni që të fillojë skanimi","Description":"Përshkrim","Description (e.g. App name)":"Përshkrim (p.sh. Emër aplikacioni)","Generate API password":"Prodhoni fjalëkalim API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Këtu mund të proshoni fjalëkalime për përdoruim me API-n e Ampache-it, ngaqë këta s’mund të depozitohen në mënyrë vërtet të sigurt, për shkak të konceptimit të API-t të Ampache-it. Mund të prodhoni as fjalëkalime të doni, dhe t’i shfuqizoni kur të doni.","Invalid path":"Shteg i pavlefshëm","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Mbani parasysh që API i Ampache-it është thjesht paraprak dhe i paqëndrueshëm. Mos ngurroni të njoftoni përvojën tuaj me këtë veçori te <a href=\"https://github.com/owncloud/music/issues/60\">tema</a> përkatëse. Do të doja të kisha edhe një listë klientësh me të cilën ta testoj. Faleminderit!","Music":"Muzikë","New music available":"Ka gati muzikë të re","New music available. Click here to reload the music library.":"Ka gati muzikë të re. Klikoni këtu që të ringarkohet fonoteka. ","Next":"Pasuesja","No music found":"S’u gjet muzikë","Path to your music collection":"Shteg te koleksioni juaj muzikor","Pause":"Pushim","Play":"Luaje","Previous":"E mëparshmja","Repeat":"Përsërite","Revoke API password":"Shfuqizojeni fjalëkalimin API","Scanning music …":"Po skanohet muzika…","Shuffle":"Përzieji","Some not playable tracks were skipped.":"Disa pjesë që s’luheshin dot u anashkaluan.","This setting specifies the folder which will be scanned for music.":"Ky rregullim përcakton dosjen që do të kontrollohet për muzikë.","Tracks":"Pjesë","Unknown album":"Album i panjohur","Unknown artist":"Artist i panjohur","Upload music in the files app to listen to it here":"Ngarkoni muzikë te aplikacioni i kartelave që ta dëgjoni këtu","Use this address to browse your music collection from any Ampache compatible player.":"Përdoreni këtë adresë që të shfletoni koleksionin tuaj muzikor prej cilitdo luajtësi muzike që funksionon për Ampache.","Use your username and following password to connect to this Ampache instance:":"Përdorni emrin tuaj të përdoruesit dhe fjalëkalimin që të lidheni te kjo instancë Ampache-i:","Volume":"Volum","tracks":"gjurmë","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} nga {{ scanningTotal }} gjithsej"});
    gettextCatalog.setStrings('sr@latin', {"Albums":"Albumi","Artists":"Izvođači","Description":"Opis","Description (e.g. App name)":"Opis (npr. Ime aplikacije)","Generate API password":"Generiši API lozinku","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ovde možete da generišete lozinke za korišćenje sa Ampache API-jem za to što one ne mogu biti sačuvane na veoma siguran način zbog dizajna Ampache API-ja. Možete da generišete koliko god želite lozinki i da ih opozovete u bilo kom trenutku.","Invalid path":"Neispravna putanja","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Imajte na umu da je Ampache API samo probna verzija i da je nestabilna. Slobodno prijavite Vaša iskustva sa ovom opcijom obraćajući se na odgovarajuću <a href=\"https://github.com/owncloud/music/issues/60\">stavku</a>. Takođe je dobrodošla lista klijenata za testiranje ove opcije. Hvala","Music":"Muzika","Next":"Sledeća","Path to your music collection":"Putanja do Vaše muzičke kolekcije","Pause":"Pauziraj","Play":"Pusti","Previous":"Prethodna","Repeat":"Ponavljaj","Revoke API password":"Opozovi API lozinku","Shuffle":"Nasumično","Some not playable tracks were skipped.":"Neke numere koje nije bilo moguće pustiti su preskočene.","This setting specifies the folder which will be scanned for music.":"Ovo podešavanje određuje direktorijum koji će biti skeniran u potrazi za muzikom.","Tracks":"Numere","Unknown album":"Nepoznati album","Unknown artist":"Nepoznati izvođač","Use this address to browse your music collection from any Ampache compatible player.":"Koristite ovu adresu da pregledate Vašu muzičku kolekciju iz bilo kog Ampache kompatibilnog plejera.","Use your username and following password to connect to this Ampache instance:":"Koristite Vaše korisničko ime i sledeću lozinku da se povežete na ovu Ampache instancu:"});
    gettextCatalog.setStrings('sr', {"Albums":"Албуми","Artists":"Извођачи","Description":"Опис","Description (e.g. App name)":"Опис (нпр. назив апликације)","Generate API password":"Генериши АПИ лозинку","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Овде можете генерисати лозинке да бисте користили са Ampache API, јер не могу да се чувају у сигуран начин због дизајна Ampache API. Можете генерисати колико желите лозинки и можете их обрисати било када.","Invalid path":"Неисправна путања","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Имајте на уму да је Ампаш АПИ у развоју и да је нестабилан. Слободно пријавите ваша искуства са овом функцијом у одговарајућем <a href=\"https://github.com/owncloud/music/issues/60\">издању</a>. Такође бих желео да имам списак клијената за тестирање. Хвала","Music":"Музика","Next":"Следећа","Path to your music collection":"Путања до ваше музичке колекције","Pause":"Паузирај","Play":"Пусти","Previous":"Претходна","Repeat":"Понављај","Revoke API password":"Опозови АПИ лозинку","Shuffle":"Измешај","Some not playable tracks were skipped.":"Прескочене су нумере које се не могу пустити.","This setting specifies the folder which will be scanned for music.":"Ова поставка наводи фасциклу у којој ће бити тражена музика.","Tracks":"Нумере","Unknown album":"Непознат албум","Unknown artist":"Непознат извођач","Use this address to browse your music collection from any Ampache compatible player.":"Користи ову адресу за прегледање ваше музичке колекције из било ког Ампаш компатибилног плејера.","Use your username and following password to connect to this Ampache instance:":"Користите ваше корисничко име и следећу лозинку за повезивање на овај Ампаш:"});
    gettextCatalog.setStrings('su', {});
    gettextCatalog.setStrings('sv', {"+ New Playlist":"+ Ny spellista","Albums":"Album","All tracks":"Alla låtar","Artists":"Artister","Click here to start the scan":"Klicka här för att börja skanning","Description":"Beskrivning","Description (e.g. App name)":"Beskrivning (ex. App-namn)","Generate API password":"Generera API-lösenord","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Här kan du generera lösenord för användning med Ampaches API, eftersom de inte kan lagras på ett riktigt säkert sätt på grund av Ampachi API:ns design. Du kan generera så många lösenord du vill och upphäva dem när som helst.","Invalid path":"Ogiltig sökväg","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Kom ihåg, att Ampaches API endast är en förhandsvisning och är ostabil. Du är välkommen att rapportera din upplevelse med denna funktionen i motsvarande <a href=\"https://github.com/owncloud/music/issues/60\">problem</a>. Jag skulle också vilja ha en lista över klienter att testa med.\nTack","Music":"Musik","New music available":"Ny musik tillgänglig","New music available. Click here to reload the music library.":"Ny musik tillgänglig. Klicka här för att ladda om musikbiblioteket.","Next":"Nästa","No music found":"Ingen musik hittades","Path to your music collection":"Sökvägen till din musiksamling","Pause":"Paus","Play":"Spela","Previous":"Föregående","Repeat":"Upprepa","Revoke API password":"Upphäv API-lösenord","Scanning music …":"Skannar musik...","Shuffle":"Blanda","Some not playable tracks were skipped.":"Några icke spelbara spår hoppades över","This setting specifies the folder which will be scanned for music.":"Denna inställning specificerar vilken mapp som kommer skannas efter musik","Tracks":"Spår","Unknown album":"Okänt album","Unknown artist":"Okänd artist","Upload music in the files app to listen to it here":"Ladda upp musik i filappen för att lyssna till den här","Use this address to browse your music collection from any Ampache compatible player.":"Använd denna adress för att bläddra igenom din musiksamling från valfri Ampache-kompatibel enhet.","Use your username and following password to connect to this Ampache instance:":"Använd ditt användarnamn och följande lösenord för att ansluta mot denna Ampache instansen:","Volume":"Volym","tracks":"låtar","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} av {{ scanningTotal }}"});
    gettextCatalog.setStrings('sw_KE', {});
    gettextCatalog.setStrings('ta_IN', {});
    gettextCatalog.setStrings('ta_LK', {"Description":"விவரிப்பு","Music":"இசை","Next":"அடுத்த","Pause":"இடைநிறுத்துக","Play":"Play","Previous":"முன்தைய","Repeat":"மீண்டும்"});
    gettextCatalog.setStrings('te', {"Music":"సంగీతం","Next":"తదుపరి","Previous":"గత"});
    gettextCatalog.setStrings('tg_TJ', {});
    gettextCatalog.setStrings('th_TH', {"+ New Playlist":"+ เพลย์ลิสต์ใหม่","Albums":"อัลบัม","All tracks":"แทร็กทั้งหมด","Artists":"ศิลปิน","Click here to start the scan":"คลิกที่นี่เพื่อเริ่มการสแกน","Description":"คำอธิบาย","Description (e.g. App name)":"รายละเอียด (ยกตัวอย่าง ชื่อแอพฯ)","Generate API password":"สุ่มรหัสผ่าน API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"ที่นี่คุณสามารถสร้างรหัสผ่านที่จะใช้กับ Ampache API เพราะไม่สามารถเก็บไว้ในที่mujปลอดภัย เนื่องจากการออกแบบของ Ampache API คุณสามารถสร้างรหัสผ่านให้มากที่สุดเท่าที่คุณต้องการและยกเลิกได้ตลอดเวลา","Invalid path":"เส้นทางไม่ถูกต้อง","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"โปรดทราบว่า Ampache API เป็นเพียงตัวอย่างและไม่เสถียร อย่าลังเลที่จะมาช่วยกันรายงานบัค <a href=\"https://github.com/owncloud/music/issues/60\"> ที่นี่ </a> เรายังต้องการผู้ที่จะร่วมทดสอบ ขอบคุณ","Music":"เพลง","New music available":"มีเพลงใหม่มาแล้ว","New music available. Click here to reload the music library.":"มีเพลงใหม่ คลิกที่นี่เพื่อโหลดไลบรารีเพลงใหม่","Next":"ถัดไป","No music found":"ไม่พบเพลง","Path to your music collection":"เส้นทางที่จะเก็บเพลงของคุณ","Pause":"หยุดชั่วคราว","Play":"เล่น","Previous":"ก่อนหน้า","Repeat":"ทำซ้ำ","Revoke API password":"ยกเลิกรหัสผ่าน API","Scanning music …":"กำลังสแกนเพลง...","Shuffle":"สับเปลี่ยน","Some not playable tracks were skipped.":"บางเพลงที่ไม่สามารถเล่นได้จะถูกข้ามไป","This setting specifies the folder which will be scanned for music.":"ตั้งค่าเพื่อระบุโฟลเดอร์ที่จะสแกนหาเพลงฟัง","Tracks":"เพลง","Unknown album":"ไม่ทราบอัลบั้ม","Unknown artist":"ไม่รู้จักศิลปิน","Upload music in the files app to listen to it here":"อัพโหลดเพลงในไฟล์แอพฯเพื่อฟังได้ที่นี่","Use this address to browse your music collection from any Ampache compatible player.":"ใช้ที่อยู่นี้เพื่อเรียกคอลเลคชันเพลงจากเครื่องเล่น Ampache ที่เข้ากันได้","Use your username and following password to connect to this Ampache instance:":"ใช้ชื่อผู้ใช้และรหัสผ่านของคุณต่อไปนี้เพื่อเชื่อมต่อไปยัง Ampache ตัวอย่างเช่น:","Volume":"ปริมาณ","tracks":"เพลง","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} จากทั้งหมด {{ scanningTotal }}"});
    gettextCatalog.setStrings('th', {"+ New Playlist":"+ เพลย์ลิสต์ใหม่","Albums":"อัลบัม","All tracks":"แทร็กทั้งหมด","Artists":"ศิลปิน","Click here to start the scan":"คลิกที่นี่เพื่อเริ่มการสแกน","Description":"คำอธิบาย","Description (e.g. App name)":"รายละเอียด (ยกตัวอย่าง ชื่อแอพฯ)","Generate API password":"สุ่มรหัสผ่าน API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"ที่นี่คุณสามารถสร้างรหัสผ่านที่จะใช้กับ Ampache API เพราะไม่สามารถเก็บไว้ในที่mujปลอดภัย เนื่องจากการออกแบบของ Ampache API คุณสามารถสร้างรหัสผ่านให้มากที่สุดเท่าที่คุณต้องการและยกเลิกได้ตลอดเวลา","Invalid path":"เส้นทางไม่ถูกต้อง","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"โปรดทราบว่า Ampache API เป็นเพียงตัวอย่างและไม่เสถียร อย่าลังเลที่จะมาช่วยกันรายงานบัค <a href=\"https://github.com/owncloud/music/issues/60\"> ที่นี่ </a> เรายังต้องการผู้ที่จะร่วมทดสอบ ขอบคุณ","Music":"เพลง","New music available":"มีเพลงใหม่มาแล้ว","New music available. Click here to reload the music library.":"มีเพลงใหม่ คลิกที่นี่เพื่อโหลดไลบรารีเพลงใหม่","Next":"ถัดไป","No music found":"ไม่พบเพลง","Path to your music collection":"เส้นทางที่จะเก็บเพลงของคุณ","Pause":"หยุดชั่วคราว","Play":"เล่น","Previous":"ก่อนหน้า","Repeat":"ทำซ้ำ","Revoke API password":"ยกเลิกรหัสผ่าน API","Scanning music …":"กำลังสแกนเพลง...","Shuffle":"สับเปลี่ยน","Some not playable tracks were skipped.":"บางเพลงที่ไม่สามารถเล่นได้จะถูกข้ามไป","This setting specifies the folder which will be scanned for music.":"ตั้งค่าเพื่อระบุโฟลเดอร์ที่จะสแกนหาเพลงฟัง","Tracks":"เพลง","Unknown album":"ไม่ทราบอัลบั้ม","Unknown artist":"ไม่รู้จักศิลปิน","Upload music in the files app to listen to it here":"อัพโหลดเพลงในไฟล์แอพฯเพื่อฟังได้ที่นี่","Use this address to browse your music collection from any Ampache compatible player.":"ใช้ที่อยู่นี้เพื่อเรียกคอลเลคชันเพลงจากเครื่องเล่น Ampache ที่เข้ากันได้","Use your username and following password to connect to this Ampache instance:":"ใช้ชื่อผู้ใช้และรหัสผ่านของคุณต่อไปนี้เพื่อเชื่อมต่อไปยัง Ampache ตัวอย่างเช่น:","Volume":"ปริมาณ","tracks":"เพลง","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} จากทั้งหมด {{ scanningTotal }}"});
    gettextCatalog.setStrings('tl_PH', {});
    gettextCatalog.setStrings('tr', {"+ New Playlist":"+Yeni Çalma Listesi","Albums":"Albümler","All tracks":"Tüm Parçalar","Artists":"Sanatçılar","Click here to start the scan":"Taramayı başlatmak için buraya tıklayın","Description":"Açıklama","Description (e.g. App name)":"Açıklama (örn. Uygulama adı)","Generate API password":"API parolası oluştur","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ampache API'sinin tasarımından dolayı bu parolalar yeterince güvenli bir şekilde depolanamadığından, burada Ampache API'si ile kullanılacak parolaları oluşturabilirsiniz. İstediğiniz kadar parola oluşturup; ardından istediğiniz zaman geçersiz kılabilirsiniz.","Invalid path":"Geçersiz yol","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Ampache API'nin henüz bir önizleme olup, kararlı olmadığını unutmayın. Bu özellikle ilgili deneyiminizi ilgili <a href=\"https://github.com/owncloud/music/issues/60\">sorunlar</a> kısmında bildirmekten çekinmeyin. Ayrıca test edilmesi gereken istemcilerin listesini de edinmek isterim. Teşekkürler.","Music":"Müzik","New music available":"Yeni müzik mevcut","New music available. Click here to reload the music library.":"Yeni müzik mevcut. Kütüphaneyi yeniden taramak için buraya tıklayın.","Next":"Sonraki","No music found":"Müzik bulunamadı","Path to your music collection":"Müzik koleksiyonunuzun yolu","Pause":"Beklet","Play":"Oynat","Previous":"Önceki","Repeat":"Tekrarla","Revoke API password":"API parolasını geçersiz kıl","Scanning music …":"Müzik taranıyor ...","Shuffle":"Karıştır","Some not playable tracks were skipped.":"Bazı oynatılamayan parçalar atlandı.","This setting specifies the folder which will be scanned for music.":"Bu ayar, müzik için taranacak klasörü belirtir.","Tracks":"Parçalar","Unknown album":"Bilinmeyen albüm","Unknown artist":"Bilinmeyen sanatçı","Upload music in the files app to listen to it here":"Müziği burada dinlemek için dosya uygulaması içinde yükleyin","Use this address to browse your music collection from any Ampache compatible player.":"Herhangi Ampache uyumlu çalardan müzik koleksiyonunuza göz atmak için bu adresi kullanın.","Use your username and following password to connect to this Ampache instance:":"Bu Ampache örneğine bağlanmak için kullanıcı adınızı ve aşağıdaki parolayı kullanın:","Volume":"Ses","tracks":"parçalar","{{ scanningScanned }} of {{ scanningTotal }}":"Toplam {{ scanningTotal }} parçanın {{ scanningScanned }} tanesi tarandı"});
    gettextCatalog.setStrings('tzm', {});
    gettextCatalog.setStrings('ug', {"Description":"چۈشەندۈرۈش","Music":"نەغمە","Next":"كېيىنكى","Pause":"ۋاقىتلىق توختا","Play":"چال","Previous":"ئالدىنقى","Repeat":"قايتىلا"});
    gettextCatalog.setStrings('uk', {"+ New Playlist":"+ Новий список відтворення","Albums":"Альбоми","All tracks":"Всі доріжки","Artists":"Виконавці","Click here to start the scan":"Натисніть тут, щоб розпочати сканування","Description":"Опис","Description (e.g. App name)":"Опис (наприклад назва додатку)","Generate API password":"Сгенерувати пароль для API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Тут ви можете згенерувати пароль для використання з Ampache API, оскільки вони не можуть бути збережені дійсно безпечним чином через конструкцію Ampache API. Ви можете створити стільки паролей, скільки необхідно, та відмовитись від них в будь який час.","Invalid path":"Невірний шлях","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Пам'ятайте, що Ampache API є демо-версією і тому не стабільна. Ми будемо вдячні, якщо ви поділитеся досвідом роботи з цією функцією у відповідному <a href=\"https://github.com/owncloud/music/issues/60\">розділі</a>. Я також хотів би створити список клієнтів для тестування. Дякую.","Music":"Музика","New music available":"Нова музика доступна","New music available. Click here to reload the music library.":"Нова музика доступна. Натисніть тут, щоб перезавантажити музичну бібліотеку.","Next":"Наступний","No music found":"Музики не знайдено","Path to your music collection":"Шлях до вашої музичної колекції","Pause":"Пауза","Play":"Грати","Previous":"Попередній","Repeat":"Повторювати","Revoke API password":"Відкликати API пароль","Scanning music …":"Сканування музики …","Shuffle":"Перемішати","Some not playable tracks were skipped.":"Деякі треки, що не відтворюються, були пропущені.","This setting specifies the folder which will be scanned for music.":"Цей параметр вказує теку, в якій буде проведено пошук музики.","Tracks":"Доріжки","Unknown album":"Невідомий альбом","Unknown artist":"Невідомий виконавець","Upload music in the files app to listen to it here":"Завантажте музику в додаток до файлів, щоб прослухати її тут","Use this address to browse your music collection from any Ampache compatible player.":"Використовуйте цю адресу, щоб переглядати вашу музичну колекцію в будь-якому програвачі, що підтримує Ampache.","Use your username and following password to connect to this Ampache instance:":"Використовуйте власний логін та пароль для з'єднання з даним Ampache:","Volume":"Гучність","tracks":"доріжки","{{ scanningScanned }} of {{ scanningTotal }}":"{{ scanningScanned }} з {{ scanningTotal }}"});
    gettextCatalog.setStrings('ur_PK', {"Description":"تصریح","Next":"اگلا","Repeat":"دہرایں"});
    gettextCatalog.setStrings('ur', {});
    gettextCatalog.setStrings('uz', {});
    gettextCatalog.setStrings('vi', {"Albums":"Album","Artists":"Nghệ sỹ","Description":"Mô tả","Description (e.g. App name)":"Mô tả (vd: Tên ứng dụng)","Generate API password":"Tạo password API","Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.":"Ở đây bạn có thể tạo mật khẩu để sử dụng với các API Ampache, bởi vì nó không thể được lưu trữ trong một cách thực sự an toàn do thiết kế của API Ampache. Bạn có thể tạo ra nhiều mật khẩu khi bạn muốn và thu hồi chúng bất cứ lúc nào.","Invalid path":"Đường dẫn không hợp lệ","Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. I would also like to have a list of clients to test with. Thanks":"Hãy nhớ, rằng các API Ampache chỉ là một bản xem trước và không ổn định. Hãy báo cáo kinh nghiệm của bạn với tính năng này  <a href=\"https://github.com/owncloud/music/issues/60\">issue</a>. Tôi cũng muốn có một danh sách khách hàng để thử nghiệm. Cảm ơn. Thanks","Music":"Âm nhạc","Next":"Kế tiếp","Path to your music collection":"Đường dẫn đến bộ sưu tập nhạc của bạn","Pause":"Tạm dừng","Play":"Play","Previous":"Lùi lại","Repeat":"Lặp lại","Revoke API password":"Hủy password API","Shuffle":"Ngẫu nhiên","Some not playable tracks were skipped.":"Một số bài không thể phát đã được bỏ qua","This setting specifies the folder which will be scanned for music.":"Thiết lập này xác định thư mục đó sẽ được quét để tìm nhạc.","Tracks":"Bài","Unknown album":"Không tìm thấy album","Unknown artist":"Không tìm thấy nghệ sĩ","Use this address to browse your music collection from any Ampache compatible player.":"Sử dụng địa chỉ này để duyệt bộ sưu tập nhạc của bạn từ bất kỳ máy nghe nhạc tương thích Ampache.","Use your username and following password to connect to this Ampache instance:":"Sử dụng tên đăng nhập và mật khẩu sau để kết nối đến Ampache:"});
    gettextCatalog.setStrings('yo', {});
    gettextCatalog.setStrings('zh_CN', {"+ New Playlist":"+ 新播放列表","Albums":"专辑页","All tracks":"所有日志","Artists":"艺术家","Click here to start the scan":"点击开始扫描","Description":"描述","Description (e.g. App name)":"描述 (例如 App 名称)","Generate API password":"生成 API 密码","Invalid path":"无效路径","Music":"音乐","Next":"下一曲","Path to your music collection":"音乐集路径","Pause":"暂停","Play":"播放","Previous":"前一首","Repeat":"重复","Revoke API password":"撤销 API 密码","Scanning music …":"扫描音乐中……","Shuffle":"随机","Some not playable tracks were skipped.":"部分无法播放的音轨已被跳过。","This setting specifies the folder which will be scanned for music.":"将会在此设置指定的文件夹中扫描音乐文件。","Tracks":"音轨","Unknown album":"未知专辑","Unknown artist":"未知艺术家","Use this address to browse your music collection from any Ampache compatible player.":"使用此地址在任何与 Ampache 兼容的音乐播放器中查看您的音乐集。","Use your username and following password to connect to this Ampache instance:":"使用您的用户名和密码连接到此 Ampache 服务：","Volume":"音量"});
    gettextCatalog.setStrings('zh_HK', {"Albums":"相簿","Artists":"歌手","Description":"描述","Music":"音樂","Next":"下一首","Pause":"暫停","Play":"播放","Previous":"上一首","Repeat":"重複"});
    gettextCatalog.setStrings('zh_TW', {"Albums":"專輯","Artists":"演出者","Description":"描述","Description (e.g. App name)":"描述（例如應用程式名稱）","Generate API password":"產生 API 密碼","Invalid path":"無效的路徑","Music":"音樂","Next":"下一個","Path to your music collection":"您的音樂資料夾的路徑","Pause":"暫停","Play":"播放","Previous":"上一個","Repeat":"重覆","Revoke API password":"撤銷 API 密碼","Shuffle":"隨機播放","Some not playable tracks were skipped.":"部份無法播放的曲目已跳過","This setting specifies the folder which will be scanned for music.":"我們會在這個資料夾內掃描音樂檔案","Tracks":"曲目","Unknown album":"未知的專輯","Unknown artist":"未知的表演者"});
/* jshint +W100 */
}]);
function PlayerWrapper() {
	var m_underlyingPlayer = null; // set later as 'aurora' or 'html5'
	var m_html5audio = null;
	var m_aurora = null;
	var m_position = 0;
	var m_duration = 0;
	var m_volume = 100;
	var m_playing = false;
	var m_url = null;
	var m_self = this;

	_.extend(this, OC.Backbone.Events);

	function initHtml5() {
		m_html5audio = document.createElement('audio');

		var getBufferedEnd = function() {
			// The buffer may contain holes after seeking but just ignore those.
			// Show the buffering status according the last buffered position.
			var bufCount = m_html5audio.buffered.length;
			return (bufCount > 0) ? m_html5audio.buffered.end(bufCount-1) : 0;
		};
		var latestNotifiedBufferState = null;

		// Bind the various callbacks
		m_html5audio.ontimeupdate = function() {
			// On Firefox, both the last 'progress' event and the 'suspend' event
			// often fire a tad too early, before the 'buffered' state has been
			// updated to its final value. Hence, check here during playback if the
			// buffering state has changed, and fire an extra event if it has.
			if (latestNotifiedBufferState != getBufferedEnd()) {
				this.onprogress();
			}

			m_position = this.currentTime * 1000;
			m_self.trigger('progress', m_position);
		};

		m_html5audio.ondurationchange = function() {
			m_duration = this.duration * 1000;
			m_self.trigger('duration', m_duration);
		};

		m_html5audio.onprogress = function() {
			var bufEnd = getBufferedEnd();
			m_self.trigger('buffer', bufEnd / this.duration * 100);
			latestNotifiedBufferState = bufEnd;
		};

		m_html5audio.onsuspend = function() {
			this.onprogress();
		};

		m_html5audio.onended = function() {
			m_self.trigger('end');
		};

		m_html5audio.oncanplay = function() {
			m_self.trigger('ready');
		};

		m_html5audio.onerror = function() {
			m_playing = false;
			if (m_url) {
				console.log('HTML5 audio: sound load error');
				m_self.trigger('error', m_url);
			} else {
				// ignore stray errors fired by the HTML audio when the src
				// has been cleared (set to invalid).
			}
		};

		m_html5audio.onplaying = onPlayStarted;

		m_html5audio.onpause = onPaused;
	}
	initHtml5();

	function onPlayStarted() {
		m_playing = true;
		m_self.trigger('play');
	}

	function onPaused() {
		m_playing = false;
		if (m_url !== null) {
			m_self.trigger('pause');
		} else {
			m_self.trigger('stop');
		}
	}

	this.play = function() {
		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.play();
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.play();
					onPlayStarted(); // Aurora has no callback => fire event synchronously
				}
				break;
		}
	};

	this.pause = function() {
		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.pause();
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.pause();
				}
				onPaused(); // Aurora has no callback => fire event synchronously
				break;
		}
	};

	this.stop = function() {
		m_url = null;

		switch (m_underlyingPlayer) {
			case 'html5':
				// Amazingly, there's no 'stop' functionality in the HTML5 audio API, nor is there a way to
				// properly remove the src attribute: setting it to null wold be interpreted as addess
				// "<baseURI>/null" and setting it to empty string will make the src equal the baseURI.
				// Still, resetting the source is necessary to detach the player from the mediaSession API.
				// Just be sure to ignore the resulting 'error' events. Unfortunately, this will still print
				// a warning to the console on Firefox.
				m_html5audio.pause();
				m_html5audio.src = '';
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.stop();
				}
				onPaused(); // Aurora has no callback => fire event synchronously
				break;
		}
	};

	this.isPlaying = function() {
		return m_playing;
	};

	this.seekingSupported = function() {
		// Seeking is not implemented in aurora/flac.js and does not work on all
		// files with aurora/mp3.js. Hence, we disable seeking with aurora.
		return (m_underlyingPlayer == 'html5');
	};

	this.seekMsecs = function(msecs) {
		if (this.seekingSupported()) {
			switch (m_underlyingPlayer) {
				case 'html5':
					m_html5audio.currentTime = msecs / 1000;
					break;
				case 'aurora':
					if (m_aurora) {
						m_aurora.seek(msecs);
					}
					break;
			}
		}
		else {
			console.log('seeking is not supported for this file');
		}
	};

	this.seek = function(ratio) {
		this.seekMsecs(ratio * m_duration);
	};

	this.seekForward = function(msecs /*optional*/) {
		msecs = msecs || 10000;
		this.seekMsecs(m_position + msecs);
	};

	this.seekBackward = function(msecs /*optional*/) {
		msecs = msecs || 10000;
		this.seekMsecs(m_position - msecs);
	};

	this.setVolume = function(percentage) {
		m_volume = percentage;

		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.volume = m_volume/100;
				break;
			case 'aurora':
				if (m_aurora) {
					m_aurora.volume = m_volume;
				}
				break;
		}
	};

	function canPlayWithHtml5(mime) {
		// The m4b format is almost identical with m4a (but intended for audio books).
		// Still, browsers actually able to play m4b files seem to return false when
		// queuring the support for the mime. Hence, a little hack.
		// The m4a files use MIME type 'audio/mp4' while the m4b use 'audio/m4b'.
		return m_html5audio.canPlayType(mime)
			|| (mime == 'audio/m4b' && m_html5audio.canPlayType('audio/mp4'));
	}

	this.canPlayMIME = function(mime) {
		var canPlayWithAurora = (mime == 'audio/flac' || mime == 'audio/mpeg');
		return canPlayWithHtml5(mime) || canPlayWithAurora;
	};

	this.fromURL = function(url, mime) {
		this.trigger('loading');

		m_url = url;

		if (canPlayWithHtml5(mime)) {
			m_underlyingPlayer = 'html5';
		} else {
			m_underlyingPlayer = 'aurora';
		}
		console.log('Using ' + m_underlyingPlayer + ' for type ' + mime + ' URL ' + url);

		switch (m_underlyingPlayer) {
			case 'html5':
				m_html5audio.pause();
				m_html5audio.src = url;
				break;

			case 'aurora':
				if (m_aurora) {
					m_aurora.stop();
				}

				m_aurora = AV.Player.fromURL(url);
				m_aurora.asset.source.chunkSize=524288;

				m_aurora.on('buffer', function(percent) {
					m_self.trigger('buffer', percent);
				});
				m_aurora.on('progress', function(currentTime) {
					m_position = currentTime;
					m_self.trigger('progress', currentTime);
				});
				m_aurora.on('ready', function() {
					m_self.trigger('ready');
				});
				m_aurora.on('end', function() {
					m_self.trigger('end');
				});
				m_aurora.on('duration', function(msecs) {
					m_duration = msecs;
					m_self.trigger('duration', msecs);
				});

				break;
		}

		// Set the current volume to the newly created/selected player instance
		this.setVolume(m_volume);
	};
}

/** @namespace */
var OC_Music_Utils = {

	/**
	 * Nextcloud 14 has a new overall layout structure which requires some
	 * changes on the application logic.
	 */
	newLayoutStructure: function() {
		// Detect the new structure from the presence of the #content-wrapper element.
		return $('#content-wrapper').length === 0;
	},

	/**
	 * Newer versions of Nextcloud come with a "dark theme" which may be activated
	 * from the accessibility settings. Test if the theme is active.
	 */
	darkThemeActive: function() {
		// The name of the theme was originally 'themedark' but changed to simply 'dark' in NC18.
		return OCA.hasOwnProperty('Accessibility')
			&& (OCA.Accessibility.theme == 'themedark' || OCA.Accessibility.theme == 'dark');
	},

	/**
	 * Test if the string @a str starts with another string @a search
	 */
	startsWith: function(str, search) {
		return str !== null && search !== null && str.slice(0, search.length) === search;
	},

	/**
	 * Test if the string @a str ends with another string @a search
	 */
	endsWith: function(str, search) {
		return str !== null && search !== null && str.slice(-search.length) === search;
	}

};
