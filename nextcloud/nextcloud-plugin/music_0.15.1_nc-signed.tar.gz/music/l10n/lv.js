OC.L10N.register(
    "music",
    {
    "Description" : "Apraksts",
    "Music" : "Mūzika",
    "Next" : "Nākamā",
    "Pause" : "Pauzēt",
    "Play" : "Atskaņot",
    "Previous" : "Iepriekšējā",
    "Repeat" : "Atkārtot"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
