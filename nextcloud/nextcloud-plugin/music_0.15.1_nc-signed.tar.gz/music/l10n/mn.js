OC.L10N.register(
    "music",
    {
    "Albums" : "Цомог",
    "Artists" : "Хамтлаг/Дуучин",
    "Description" : "Тайлбар"
},
"nplurals=2; plural=(n != 1);");
