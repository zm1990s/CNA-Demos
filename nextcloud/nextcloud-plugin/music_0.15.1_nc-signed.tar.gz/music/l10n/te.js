OC.L10N.register(
    "music",
    {
    "Music" : "సంగీతం",
    "Next" : "తదుపరి",
    "Previous" : "గత"
},
"nplurals=2; plural=(n != 1);");
