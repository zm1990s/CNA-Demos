OC.L10N.register(
    "music",
    {
    "Albums" : "Albumoj",
    "Artists" : "Artistoj",
    "Description" : "Priskribo",
    "Description (e.g. App name)" : "Priskribo (ekz.: aplikaĵonomo)",
    "Invalid path" : "Nevalida vojo",
    "Music" : "Muziko",
    "Next" : "Jena",
    "Path to your music collection" : "Vojo al via muzikokolekto",
    "Pause" : "Paŭzi...",
    "Play" : "Ludi",
    "Previous" : "Maljena",
    "Repeat" : "Ripeti",
    "Shuffle" : "Miksi",
    "Unknown album" : "Nekonata albumo",
    "Unknown artist" : "Nekonata artisto"
},
"nplurals=2; plural=(n != 1);");
