OC.L10N.register(
    "music",
    {
    "Description" : "විස්තරය",
    "Music" : "සංගීතය",
    "Next" : "ඊලඟ",
    "Pause" : "විරාමය",
    "Play" : "ධාවනය",
    "Previous" : "පෙර",
    "Repeat" : "පුනරාවර්ථන"
},
"nplurals=2; plural=(n != 1);");
