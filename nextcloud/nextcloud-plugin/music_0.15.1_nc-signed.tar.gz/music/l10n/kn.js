OC.L10N.register(
    "music",
    {
    "Next" : "ಮುಂದೆ"
},
"nplurals=2; plural=(n > 1);");
