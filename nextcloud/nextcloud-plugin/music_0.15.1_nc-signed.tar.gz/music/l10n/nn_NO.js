OC.L10N.register(
    "music",
    {
    "Description" : "Skildring",
    "Music" : "Musikk",
    "Next" : "Neste",
    "Pause" : "Pause",
    "Play" : "Spel",
    "Previous" : "Førre",
    "Repeat" : "Gjenta"
},
"nplurals=2; plural=(n != 1);");
