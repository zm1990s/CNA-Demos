OC.L10N.register(
    "music",
    {
    "Albums" : "Albumai",
    "Artists" : "Atlikėjai",
    "Description" : "Aprašymas",
    "Generate API password" : "Sugeneruoti API slaptažodį",
    "Invalid path" : "Netinkamas kelias",
    "Music" : "Muzika",
    "Next" : "Kitas",
    "Pause" : "Pristabdyti",
    "Play" : "Groti",
    "Previous" : "Ankstesnis",
    "Repeat" : "Kartoti",
    "Shuffle" : "Maišyti",
    "Unknown album" : "Nežinomas albumas",
    "Unknown artist" : "Nežinomas atlikėjas"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
