OC.L10N.register(
    "music",
    {
    "Description" : "چۈشەندۈرۈش",
    "Music" : "نەغمە",
    "Next" : "كېيىنكى",
    "Pause" : "ۋاقىتلىق توختا",
    "Play" : "چال",
    "Previous" : "ئالدىنقى",
    "Repeat" : "قايتىلا"
},
"nplurals=1; plural=0;");
