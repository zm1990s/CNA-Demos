OC.L10N.register(
    "music",
    {
    "Description" : "تصریح",
    "Next" : "اگلا",
    "Repeat" : "دہرایں"
},
"nplurals=2; plural=(n != 1);");
