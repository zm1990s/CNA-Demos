OC.L10N.register(
    "music",
    {
    "Description" : "விவரிப்பு",
    "Music" : "இசை",
    "Next" : "அடுத்த",
    "Pause" : "இடைநிறுத்துக",
    "Play" : "Play",
    "Previous" : "முன்தைய",
    "Repeat" : "மீண்டும்"
},
"nplurals=2; plural=(n != 1);");
