OC.L10N.register(
    "music",
    {
    "Albums" : "Album",
    "Artists" : "Artist",
    "Description" : "Beschreiwung",
    "Music" : "Musek",
    "Next" : "Weider",
    "Pause" : "Paus",
    "Play" : "Ofspillen",
    "Previous" : "Zeréck",
    "Repeat" : "Widderhuelen"
},
"nplurals=2; plural=(n != 1);");
