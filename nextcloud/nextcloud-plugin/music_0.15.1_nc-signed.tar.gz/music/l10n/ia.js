OC.L10N.register(
    "music",
    {
    "Description" : "Description",
    "Music" : "Musica",
    "Next" : "Proxime",
    "Pause" : "Pausa",
    "Play" : "Reproducer",
    "Previous" : "Previe",
    "Repeat" : "Repeter"
},
"nplurals=2; plural=(n != 1);");
