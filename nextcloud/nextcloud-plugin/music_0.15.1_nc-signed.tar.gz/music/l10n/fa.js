OC.L10N.register(
    "music",
    {
    "Albums" : "آلبوم ها",
    "Artists" : "هنرمندان",
    "Description" : "توضیحات",
    "Description (e.g. App name)" : "توضیحات (همانند نام برنامه)",
    "Generate API password" : "تولید رمزعبور API ",
    "Invalid path" : "مسیر اشتباه",
    "Music" : "موزیک",
    "Next" : "بعدی",
    "No music found" : "موزیک جدید پیدا شد.",
    "Pause" : "توقف کردن",
    "Play" : "پخش کردن",
    "Previous" : "قبلی",
    "Repeat" : "تکرار",
    "Shuffle" : "درهم",
    "Unknown album" : "آلبوم نامشخص",
    "Unknown artist" : "خواننده نامشخص",
    "Volume" : "میزان صدا"
},
"nplurals=2; plural=(n > 1);");
