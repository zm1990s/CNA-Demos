# Author

* [Pauli Järvinen](https://github.com/paulijar): <pauli.jarvinen@gmail.com>

# Original author

* [Morris Jobke](https://github.com/MorrisJobke): <hey@morrisjobke.de>

# Original design

* [Jan-Christoph Borchardt](https://github.com/jancborchardt): <hey@jancborchardt.net>
* [Morris Jobke](https://github.com/MorrisJobke): <hey@morrisjobke.de>

# Other contributors

* [7ebra](https://github.com/7ebra)
* [Arboss](https://github.com/arboss)
* [Armin]
* [Ashot Nazaryan](https://github.com/AshotN)
* [Bernhard Posselt](https://github.com/BernhardPosselt)
* [Cbxk1xg](https://github.com/cbxk1xg)
* [Chris Allan](https://github.com/ChrisJAllan): <chrisallan@pm.me>
* [ChristophWurst](https://github.com/ChristophWurst)
* [Christopher Schäpers](https://github.com/Kondou-ger): <christopher@schaepers.it>
* [David Prevot](https://github.com/DavidPrevot)
* [Felix Böhm](https://github.com/felixboehm)
* [Gaurav Narula](https://github.com/gnarula): <gnarula94@gmail.com>
* [Gigen Chang](https://github.com/gigenchang): <th33ts@gmail.com>
* [Glandos](https://github.com/Glandos)
* [Gregory Baudet](https://github.com/greku): <gregory.baudet@gmail.com>
* [Jbtbnl](https://github.com/jbtbnl)
* [Jean-Marie de Boer] (https://github.com/jmdeboer-surfsara): <jean-marie.deboer@surfsara.nl>
* [Jonathan Kawohl](https://github.com/Kawohl)
* [Jérôme Pouiller](https://github.com/jerome-pouiller)
* [Jörn Friedrich Dreyer](https://github.com/butonic): <d@butonic.de>
* [K Widholm](https://github.com/apotek)
* [Konrad Mosoń](https://github.com/morsik): <morsik@darkserver.it>
* [Leizh](https://github.com/eizh): <leizh@free.fr>
* [Lukas Reschke](https://github.com/LukasReschke)
* [Moritz Meißelbach](https://github.com/Biont): <moritz@meisselba.ch>
* [Ndurchx](https://github.com/ndurchx)
* [Nico Boehr](https://github.com/youknow0): <nico@nicoboehr.de>
* [Nuno Jesus](https://github.com/nunojesus)
* [Pellaeon Lin](https://github.com/pellaeon): <nfsmwlin@gmail.com>
* [Ralf Pietsch](https://github.com/AlZiBa)
* [RealRancor](https://github.com/RealRancor)
* [Rello](https://github.com/rello)
* [Roland Hager](https://github.com/roha4000)
* [Selpelt](https://github.com/selpelt)
* [Thomas Müller](https://github.com/DeepDiver1975): <github@tmit.eu>
* [Thomas Pulzer](https://github.com/Faldon)
* [Victor Dubiniuk](https://github.com/VicDeo): <victor.dubiniuk@gmail.com>
* [Vincent Petry](https://github.com/PVince81)
* [Volkan Gezer](https://github.com/wakeup)
* [Xefir](https://github.com/Xefir)
* [Yurifag](https://github.com/Yurifag): <jannesgrzebien@gmail.com>
