<div class="error">
	<h2><?php p($l->t('Error')) ?></h2>
	<p><?php p($_['message']) ?></p>
</div>
