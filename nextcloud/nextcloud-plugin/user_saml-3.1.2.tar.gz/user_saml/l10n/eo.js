OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Konservita",
    "Email address" : "Retpoŝtadreso",
    "Open documentation" : "Malfermi la dokumentaron",
    "General" : "Ĝenerala",
    "Error" : "Eraro"
},
"nplurals=2; plural=(n != 1);");
