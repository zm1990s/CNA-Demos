OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Gespäichert",
    "Open documentation" : "Dokumentatioun opmaachen",
    "General" : "Allgemeng",
    "Metadata invalid" : "Falsch Metadata",
    "Error" : "Fehler"
},
"nplurals=2; plural=(n != 1);");
