OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Salveguardate",
    "Open documentation" : "Aperir documentation",
    "General" : "General",
    "Security settings" : "Configurationes de securitate",
    "Metadata invalid" : "Metadatos non valide",
    "Metadata valid" : "Metadatos valide",
    "Error" : "Error"
},
"nplurals=2; plural=(n != 1);");
