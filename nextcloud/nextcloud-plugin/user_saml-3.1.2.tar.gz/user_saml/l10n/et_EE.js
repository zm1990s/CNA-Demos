OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Salvestatud",
    "X.509 certificate of the Service Provider" : "Teenusepakkuja X.509 sertifikaat",
    "Private key of the Service Provider" : "Teenusepakkuja privaatvõti",
    "SSO & SAML authentication" : "SSO & SAML autentimine",
    "Open documentation" : "Ava dokumentatsioon",
    "Use built-in SAML authentication" : "Kasuta sisse-ehitatud SAML autentimist",
    "Use environment variable" : "Kasuta keskonnamuutujat",
    "General" : "Üldine",
    "Service Provider Data" : "Teenusepakkuja andmed",
    "Security settings" : "Turvaseaded",
    "Error" : "Viga"
},
"nplurals=2; plural=(n != 1);");
