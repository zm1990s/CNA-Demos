OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Запазено",
    "Email address" : "Имейл адрес",
    "SSO & SAML authentication" : "SSO и SAML удостоверяване",
    "Open documentation" : "Отвори документацията",
    "Use built-in SAML authentication" : "Ползвай вграденото SAML удостоверяване",
    "General" : "Общи",
    "Security settings" : "Настройки за сигурност",
    "Reset settings" : "Нулиране на настройките",
    "Error" : "Грешка"
},
"nplurals=2; plural=(n != 1);");
