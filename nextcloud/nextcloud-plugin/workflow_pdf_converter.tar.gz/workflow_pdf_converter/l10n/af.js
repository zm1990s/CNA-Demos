OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Mode…" : "Modus…",
    "Keep original, preserve existing PDFs" : "Behou oorspronklike, behou bestaande PDF’s",
    "Keep original, overwrite existing PDF" : "Behou oorspronklike, skryf oor bestaande PDF",
    "Delete original, preserve existing PDFs" : "Skrap oorspronklike, behou bestaande PDF’s",
    "Delete original, overwrite existing PDF" : "Skrap oorspronklike, skryf oor bestaande PDF",
    "Please choose a mode." : "Kies asb. ’n modus.",
    "PDF conversion" : "PDF-omskakeling",
    "Automated PDF conversion" : "Geoutomatiseerde PDF-omskakeling",
    "Document to PDF converter" : "Dokument-na-PDF-omskakelaar"
},
"nplurals=2; plural=(n != 1);");
