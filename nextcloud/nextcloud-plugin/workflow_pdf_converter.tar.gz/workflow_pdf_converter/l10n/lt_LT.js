OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Mode…" : "Veiksena…",
    "Keep original, preserve existing PDFs" : "Palikti pradinius, išsaugoti esamus PDF",
    "Keep original, overwrite existing PDF" : "Palikti pradinius, perrašyti esamus PDF",
    "Delete original, preserve existing PDFs" : "Ištrinti pradinius, išsaugoti esamus PDF",
    "Delete original, overwrite existing PDF" : "Ištrinti pradinius, perrašyti esamus PDF",
    "Please choose a mode." : "Pasirinkite veikseną.",
    "PDF conversion" : "PDF konvertavimas",
    "Automated PDF conversion" : "Automatizuotas PDF konvertavimas",
    "Rule based conversion of Documents into the PDF format" : "Taisykle pagrįstas dokumentų konvertavimas į PDF formatą"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
