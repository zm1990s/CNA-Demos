OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Mode…" : "شسیب"
},
"nplurals=2; plural=(n != 1);");
