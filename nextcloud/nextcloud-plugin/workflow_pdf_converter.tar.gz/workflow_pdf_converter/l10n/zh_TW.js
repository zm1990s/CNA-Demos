OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Mode…" : "模式…",
    "Keep original, preserve existing PDFs" : "保留原文件，留存已存在PDF檔",
    "Keep original, overwrite existing PDF" : "保留原文件，覆蓋已存在PDF檔",
    "Delete original, preserve existing PDFs" : "刪除原文件，留存已存在PDF檔",
    "Delete original, overwrite existing PDF" : "刪除原文件，覆蓋已存在PDF檔",
    "Please choose a mode." : "請選擇模式。",
    "PDF conversion" : "轉換PDF",
    "Convert documents into the PDF format on upload and write." : "上載和寫入時轉換為PDF",
    "Automated PDF conversion" : "自動PDF轉換",
    "Document to PDF converter" : "文件至PDF轉換器"
},
"nplurals=1; plural=0;");
