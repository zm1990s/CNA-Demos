<?php

$app = new \OCA\CameraRawPreviews\AppInfo\Application;
$app->register();