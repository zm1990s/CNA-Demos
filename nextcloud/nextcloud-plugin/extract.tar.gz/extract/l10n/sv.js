OC.L10N.register(
    "extract",
    {
    "Extract here" : "Extrahera här",
    "Error extracting " : "Fel när filen extraherades",
    "Extract" : "Extrahera",
    "Extract archive from the web interface" : "Extrahera arkiv i webinterfacet",
    "Zip extension is not available" : "Zip-tillägg är inte tillgängligt",
    "Can't find zip file" : "Zip-filen kunde inte hittas",
    "Can't open zip file at %s" : "Zip-filen kunde inte öppnas i %s",
    "rar extension or unrar is not installed or available" : "Rar eller Unrar är inte installerat, eller är otillgängligt",
    "Can't find rar file" : "Rar-filen kunde inte hittas",
    "Can't find rar file at %s" : "Rar-filen hittades inte i %s",
    "p7zip and p7zip-full are not installed or available" : "p7zip och p7zip-full är inte installerat, eller är otillgängligt",
    "Can't find archive on external local storage" : "Kunde inte hitta arkivet på extern lokal lagring.",
    "Can't find archive at %s" : "Arkivet hittades inte i %s",
    "Can't scan file at %s" : "Filen i %s kunde inte scannas"
},
"");
