OC.L10N.register(
    "extract",
    {
    "Extract here" : "Extracto aquí",
    "Error extracting " : "Error de desembalaje",
    "Extract" : "Extracto",
    "Extract archive from the web interface" : "Desempaquetar archivo de la interfaz web"
},
"");
