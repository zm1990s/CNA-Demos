OC.L10N.register(
    "extract",
    {
    "Extract here" : "Распаковать здесь",
    "Error extracting " : "Ошибка распаковки ",
    "Extract" : "Распаковать",
    "Extract archive from the web interface" : "Распаковка архивов в веб-интерфейсе",
    "Zip extension is not available" : "Расширение zip недоступно",
    "Can't find zip file" : "Невозможно обнаружить zip-файл",
    "Can't open zip file at %s" : "Невозможно открыть zip-файл в %s",
    "rar extension or unrar is not installed or available" : "расширение rar недоступно или unrar не установлен",
    "Can't find rar file" : "Невозможно обнаружить rar-файл",
    "Can't find rar file at %s" : "Невозможно обнаружить rar-файл в %s",
    "p7zip and p7zip-full are not installed or available" : "p7zip и p7zip-full не установлены или недоступны",
    "Can't find archive on external local storage" : "Невозможно обнаружить архив в локальном внешнем хранилище",
    "Can't find archive at %s" : "Невозможно обнаружить архив в %s",
    "Can't scan file at %s" : "Невозможно просканировать файл в %s"
},
"");
