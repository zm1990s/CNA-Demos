| Metadata UI         | EXIF              | XMP                        | IPTC  |
| ------------------- | ----------------- | -------------------------- | ----- |
| Title               |                   | dc:title                   | 2#005 |
| Keywords            |                   | dc:subject                 | 2#025 |
| Instructions        |                   | photoshop:Instructions     | 2#040 |
| Date created        | DateTimeOriginal  | photoshop:DateCreated      | 2#055 |
| Author              | Artist            | dc:creator                 | 2#080 |
| Job title           |                   | photoshop:AuthorsPosition  | 2#085 |
| Location            |                   | photoshop:City             | 2#090 |
| Location            |                   | photoshop:State            | 2#095 |
| Location            |                   | photoshop:Country          | 2#101 |
| Headline            |                   | photoshop:Headline         | 2#105 |
| Credits             |                   | photoshop:Credit           | 2#110 |
| Source              |                   | photoshop:Source           | 2#115 |
| Copyright           | Copyright         | dc:rights                  | 2#116 |
| Description         |                   | dc:description             | 2#120 |
| Description writer  |                   | photoshop:CaptionWriter    | 2#122 |

[IPTC Core schema 1.2 specifications](https://iptc.org/std/photometadata/specification/IPTC-PhotoMetadata#iptc-core-schema-1-2-specifications)
