<?php

return ['routes' => [
    ['name' => 'metadata#get', 'url' => '/get', 'verb' => 'GET']
]];
