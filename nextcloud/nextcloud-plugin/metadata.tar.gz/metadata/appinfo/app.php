<?php

namespace OCA\Metadata\AppInfo;

$app = \OC::$server->query(Application::class);
