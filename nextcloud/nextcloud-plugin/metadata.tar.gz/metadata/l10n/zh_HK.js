OC.L10N.register(
    "metadata",
    {
    "Location" : "位置",
    "Title" : "標題",
    "Date" : "Date",
    "Description" : "描述",
    "Unknown" : "未知",
    "Other" : "其他"
},
"nplurals=1; plural=0;");
