OC.L10N.register(
    "metadata",
    {
    "Location" : "Sted",
    "Title" : "Titel",
    "Length" : "Længde",
    "Copyright" : "Ophavsret",
    "Date" : "Dato",
    "Comment" : "Kommentér",
    "Description" : "Beskrivelse",
    "Rating" : "Bedømmelse",
    "Tags" : "Tags",
    "Credits" : "Credits",
    "Manual" : "Manuel",
    "Unknown" : "Ukendt",
    "Pattern" : "Mønster",
    "Other" : "Andet"
},
"nplurals=2; plural=(n != 1);");
