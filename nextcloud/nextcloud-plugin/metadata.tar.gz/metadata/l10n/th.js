OC.L10N.register(
    "metadata",
    {
    "Location" : "ตำแหน่งที่อยู่",
    "Title" : "ชื่อเรื่อง",
    "Copyright" : "ลิขสิทธิ์",
    "Date" : "Date",
    "Comment" : "แสดงความคิดเห็น",
    "Description" : "รายละเอียด",
    "Tags" : "ป้ายกำกับ",
    "Unknown" : "ไม่ทราบ",
    "Other" : "อื่นๆ"
},
"nplurals=1; plural=0;");
