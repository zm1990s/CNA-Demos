OC.L10N.register(
    "metadata",
    {
    "Location" : "Location",
    "Title" : "Title",
    "Copyright" : "Copyright",
    "Date" : "Date",
    "Comment" : "Comment",
    "Description" : "Description",
    "Rating" : "Rating",
    "Tags" : "Tags",
    "Credits" : "Credits",
    "Unknown" : "Unknown",
    "Pattern" : "Pattern",
    "Other" : "Other"
},
"nplurals=2; plural=(n != 1);");
