OC.L10N.register(
    "metadata",
    {
    "Location" : "Emplaçament",
    "Title" : "Títol",
    "Copyright" : "Drech d'autor",
    "Date" : "Date",
    "Comment" : "Comentar",
    "Description" : "Descripcion",
    "Unknown" : "Desconegut",
    "Other" : "Autre"
},
"nplurals=2; plural=(n > 1);");
