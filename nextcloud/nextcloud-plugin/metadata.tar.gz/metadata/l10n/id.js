OC.L10N.register(
    "metadata",
    {
    "Location" : "Lokasi",
    "Title" : "Judul",
    "Copyright" : "Hak cipta",
    "Date" : "Date",
    "Comment" : "Komentar",
    "Description" : "Deskrisi",
    "Rating" : "Nilai",
    "Tags" : "Tag",
    "Credits" : "Kredit",
    "Unknown" : "Tidak diketahui",
    "Other" : "Lainnya"
},
"nplurals=1; plural=0;");
