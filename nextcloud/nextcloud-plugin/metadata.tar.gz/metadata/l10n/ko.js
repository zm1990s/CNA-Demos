OC.L10N.register(
    "metadata",
    {
    "Location" : "위치",
    "Title" : "직위",
    "Copyright" : "저작권",
    "Date" : "날짜",
    "Comment" : "설명",
    "Description" : "설명",
    "Rating" : "평가",
    "Tags" : "태그",
    "Credits" : "크레딧",
    "Manual" : "수동",
    "Unknown" : "알 수 없음",
    "Pattern" : "패턴",
    "Other" : "기타"
},
"nplurals=1; plural=0;");
