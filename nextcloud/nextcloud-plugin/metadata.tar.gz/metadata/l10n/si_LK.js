OC.L10N.register(
    "metadata",
    {
    "Metadata" : "පාර දත්ත",
    "Location" : "ස්ථානය",
    "File not found." : "ගොනුව සොයාගත නොහෑක",
    "Title" : "මාතෘකාව",
    "Date" : "Date",
    "Comment" : "අදහස",
    "Description" : "විස්තරය",
    "Tags" : "ටැග",
    "Unknown" : "නොදනී",
    "Other" : "වෙනත්"
},
"nplurals=2; plural=(n != 1);");
