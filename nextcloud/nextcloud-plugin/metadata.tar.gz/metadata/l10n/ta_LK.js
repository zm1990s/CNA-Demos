OC.L10N.register(
    "metadata",
    {
    "Location" : "இடம்",
    "Title" : "தலைப்பு",
    "Date" : "Date",
    "Description" : "விவரிப்பு",
    "Tags" : "சீட்டுகள்",
    "Unknown" : "தெரியாத",
    "Other" : "மற்றவை"
},
"nplurals=2; plural=(n != 1);");
