OC.L10N.register(
    "metadata",
    {
    "Location" : "Lokasi",
    "Title" : "Judul",
    "Date" : "Date",
    "Description" : "Keterangan",
    "Other" : "Lain"
},
"nplurals=1; plural=0;");
