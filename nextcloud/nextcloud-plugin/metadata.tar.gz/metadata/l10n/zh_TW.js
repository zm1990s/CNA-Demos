OC.L10N.register(
    "metadata",
    {
    "Location" : "地點",
    "Title" : "標題",
    "Copyright" : "著作權",
    "Year" : "年",
    "Date" : "日期",
    "Comment" : "備註",
    "Description" : "描述",
    "Rating" : "評價",
    "Tags" : "標籤",
    "Instructions" : "說明",
    "Credits" : "致謝",
    "Source" : "來源",
    "Manual" : "手動",
    "Unknown" : "不明",
    "Other" : "其他"
},
"nplurals=1; plural=0;");
