OC.L10N.register(
    "metadata",
    {
    "Metadata" : "Метаданни",
    "Location" : "Местоположение",
    "Title" : "Име",
    "Copyright" : "Авторско право",
    "Date" : "Дата",
    "Comment" : "Коментар",
    "Description" : "Описание",
    "Rating" : "Оценка",
    "Tags" : "Етикети",
    "Manual" : "Ръчно",
    "Unknown" : "Непознат",
    "Pattern" : "Модел",
    "Other" : "Друг",
    "auto" : "Автоматично"
},
"nplurals=2; plural=(n != 1);");
