OC.L10N.register(
    "metadata",
    {
    "Location" : "ადგილმდებარეობა",
    "Title" : "სათაური",
    "Copyright" : "საავტორო უფლებები",
    "Date" : "თარიღი",
    "Comment" : "კომენტარი",
    "Description" : "აღწერილობა",
    "Rating" : "რეიტინგი",
    "Tags" : "ტეგები",
    "Credits" : "კრედიტები",
    "Unknown" : "ამოუცნობი",
    "Pattern" : "ნიმუში",
    "Other" : "სხვა"
},
"nplurals=2; plural=(n!=1);");
