OC.L10N.register(
    "metadata",
    {
    "Location" : "Uert",
    "Title" : "Titel",
    "Date" : "Date",
    "Comment" : "Kommentar",
    "Description" : "Beschreiwung",
    "Tags" : "Tags",
    "Unknown" : "Onbekannt",
    "Other" : "Aner"
},
"nplurals=2; plural=(n != 1);");
