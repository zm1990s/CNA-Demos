OC.L10N.register(
    "metadata",
    {
    "Location" : "Ubicación",
    "Title" : "Título",
    "Copyright" : "Derechos de autor",
    "Date" : "Fecha",
    "Comment" : "Comentario",
    "Description" : "Descripción",
    "Rating" : "Calificación",
    "Tags" : "Etiquetas",
    "Credits" : "Créditos",
    "Unknown" : "Desconocido",
    "Pattern" : "Patrón",
    "Other" : "Otro"
},
"nplurals=2; plural=(n != 1);");
