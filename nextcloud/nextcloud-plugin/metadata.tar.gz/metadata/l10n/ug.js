OC.L10N.register(
    "metadata",
    {
    "Location" : "ئورنى",
    "Title" : "ماۋزۇ",
    "Date" : "Date",
    "Description" : "چۈشەندۈرۈش",
    "Tags" : "بەلگەلەر",
    "Other" : "باشقا"
},
"nplurals=2; plural=(n != 1);");
