OC.L10N.register(
    "metadata",
    {
    "Location" : "Տեղակայություն",
    "Title" : "Վերնագիր",
    "Date" : "Date",
    "Comment" : "Մեկնաբանել",
    "Description" : "Նկարագրություն",
    "Credits" : "անվանացանկ",
    "Unknown" : "Անհայտ",
    "Other" : "Այլ"
},
"nplurals=2; plural=(n != 1);");
