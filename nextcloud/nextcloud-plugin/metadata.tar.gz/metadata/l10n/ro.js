OC.L10N.register(
    "metadata",
    {
    "Location" : "Locație",
    "Title" : "Titlu",
    "Date" : "Date",
    "Comment" : "Comentariu",
    "Description" : "Descriere",
    "Tags" : "Etichete",
    "Credits" : "Realizatori",
    "Manual" : "Manual",
    "Unknown" : "Necunoscut",
    "Other" : "Altele"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
