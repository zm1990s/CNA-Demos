OC.L10N.register(
    "metadata",
    {
    "Location" : "ទីតាំង",
    "Title" : "ចំណងជើង",
    "Date" : "Date",
    "Comment" : "មតិ",
    "Description" : "ការ​អធិប្បាយ",
    "Tags" : "ស្លាក",
    "Other" : "ផ្សេងៗ"
},
"nplurals=1; plural=0;");
