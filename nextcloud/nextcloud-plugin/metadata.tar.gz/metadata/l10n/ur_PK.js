OC.L10N.register(
    "metadata",
    {
    "Location" : "مقام",
    "Title" : "عنوان",
    "Date" : "Date",
    "Description" : "تصریح",
    "Other" : "دیگر"
},
"nplurals=2; plural=(n != 1);");
