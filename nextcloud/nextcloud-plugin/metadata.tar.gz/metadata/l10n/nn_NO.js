OC.L10N.register(
    "metadata",
    {
    "Location" : "Stad",
    "Title" : "Tittel",
    "Date" : "Date",
    "Comment" : "Kommentér",
    "Description" : "Skildring",
    "Tags" : "Emneord",
    "Unknown" : "Ukjend",
    "Other" : "Anna"
},
"nplurals=2; plural=(n != 1);");
