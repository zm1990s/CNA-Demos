OC.L10N.register(
    "metadata",
    {
    "Location" : "Loko",
    "Title" : "Titolo",
    "Copyright" : "Kopirajto",
    "Date" : "Date",
    "Comment" : "Komento",
    "Description" : "Priskribo",
    "Rating" : "Pritakso",
    "Tags" : "Etikedoj",
    "Manual" : "Permane",
    "Unknown" : "Nekonata",
    "Other" : "Alia"
},
"nplurals=2; plural=(n != 1);");
