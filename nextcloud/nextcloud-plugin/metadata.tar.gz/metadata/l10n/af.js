OC.L10N.register(
    "metadata",
    {
    "Location" : "Ligging",
    "Title" : "Titel",
    "Date" : "Datum",
    "Comment" : "Kommentaar",
    "Description" : "Beskrywing",
    "Tags" : "Etikette",
    "Unknown" : "Onbekend",
    "Other" : "Ander"
},
"nplurals=2; plural=(n != 1);");
