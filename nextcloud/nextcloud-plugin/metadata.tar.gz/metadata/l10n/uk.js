OC.L10N.register(
    "metadata",
    {
    "Metadata" : "Метадані",
    "Location" : "Місце",
    "Title" : "Назва",
    "Copyright" : "Права на копіюівння",
    "Date" : "Date",
    "Comment" : "Коментар",
    "Description" : "Опис",
    "Rating" : "Оцінка",
    "Tags" : "Позначки",
    "Credits" : "Подяки",
    "Manual" : "Вручну",
    "Unknown" : "Невідомо",
    "Pattern" : "Шаблон",
    "Other" : "Інший"
},
"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);");
