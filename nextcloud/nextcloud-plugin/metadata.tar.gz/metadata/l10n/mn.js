OC.L10N.register(
    "metadata",
    {
    "Location" : "Байршил",
    "Title" : "Цол/Албан тушаал",
    "Copyright" : "Зохиогчийн эрх",
    "Date" : "Он сар өдөр",
    "Comment" : "undefined",
    "Description" : "Тодорхойлолт",
    "Rating" : "Зэрэглэл",
    "Tags" : "Tag-үүд",
    "Credits" : "Кредит",
    "Unknown" : "Үл танигдах зүйл",
    "Other" : "Бусад"
},
"nplurals=2; plural=(n != 1);");
