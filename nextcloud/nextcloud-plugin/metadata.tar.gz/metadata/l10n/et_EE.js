OC.L10N.register(
    "metadata",
    {
    "Location" : "Asukoht",
    "Title" : "Pealkiri",
    "Copyright" : "Autoriõigused",
    "Date" : "Kuupäev",
    "Comment" : "Kommentaar",
    "Description" : "Kirjeldus",
    "Rating" : "Hinnang",
    "Tags" : "Sildid",
    "Unknown" : "Teadmata",
    "Other" : "Muu"
},
"nplurals=2; plural=(n != 1);");
