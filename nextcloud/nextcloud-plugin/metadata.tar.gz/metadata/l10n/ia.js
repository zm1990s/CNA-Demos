OC.L10N.register(
    "metadata",
    {
    "Location" : "Loco",
    "Title" : "Titulo",
    "Copyright" : "Copyright",
    "Date" : "Date",
    "Comment" : "Commentario",
    "Description" : "Description",
    "Tags" : "Etiquettas",
    "Unknown" : "Incognite",
    "Other" : "Altere"
},
"nplurals=2; plural=(n != 1);");
