OC.L10N.register(
    "metadata",
    {
    "Location" : "Vendndodhje",
    "Title" : "Titulli",
    "Copyright" : "Të drejta kopjimi",
    "Date" : "Data",
    "Comment" : "Koment",
    "Description" : "Përshkrim",
    "Rating" : "Rankim",
    "Tags" : "Etiketat",
    "Credits" : "Kreditet",
    "Unknown" : "I/E panjohur",
    "Pattern" : "Strukturë",
    "Other" : "Tjetër"
},
"nplurals=2; plural=(n != 1);");
