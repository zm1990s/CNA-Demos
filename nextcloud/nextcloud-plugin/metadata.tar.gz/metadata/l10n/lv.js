OC.L10N.register(
    "metadata",
    {
    "Metadata" : "Metadati",
    "Location" : "Vieta",
    "Title" : "Amats",
    "Copyright" : "Autortiesības",
    "Date" : "Datums",
    "Comment" : "Komentārs",
    "Description" : "Apraksts",
    "Rating" : "Vērtējums",
    "Tags" : "Birkas",
    "Instructions" : "Norādes gatavošanai",
    "Credits" : "Kredīti",
    "Source" : "Avots",
    "Manual" : "Manuāli",
    "Unknown" : "Nezināms",
    "Other" : "Cits"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
