OC.L10N.register(
    "metadata",
    {
    "Location" : "অবস্থান",
    "Title" : "শিরোনাম",
    "Date" : "Date",
    "Comment" : "মন্তব্য",
    "Description" : "বিবরণ",
    "Tags" : "ট্যাগ",
    "Unknown" : "অজানা",
    "Other" : "অন্যান্য"
},
"nplurals=2; plural=(n != 1);");
