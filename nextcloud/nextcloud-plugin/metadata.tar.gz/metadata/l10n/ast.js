OC.L10N.register(
    "metadata",
    {
    "Location" : "Llocalización",
    "Title" : "Títulu",
    "Copyright" : "Copyright",
    "Date" : "Date",
    "Comment" : "Comentariu",
    "Description" : "Descripción",
    "Rating" : "Valoración",
    "Tags" : "Etiquetes",
    "Credits" : "Creitos",
    "Unknown" : "Desconozse",
    "Pattern" : "Patrón",
    "Other" : "Otru"
},
"nplurals=2; plural=(n != 1);");
