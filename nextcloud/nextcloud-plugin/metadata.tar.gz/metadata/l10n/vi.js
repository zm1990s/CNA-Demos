OC.L10N.register(
    "metadata",
    {
    "Location" : "Vị trí",
    "Title" : "Tên",
    "Copyright" : "Bản quyền",
    "Date" : "Date",
    "Comment" : "Bình luận",
    "Description" : "Mô tả",
    "Rating" : "Đánh giá",
    "Tags" : "Thẻ",
    "Unknown" : "Không xác định",
    "Other" : "Khác"
},
"nplurals=1; plural=0;");
