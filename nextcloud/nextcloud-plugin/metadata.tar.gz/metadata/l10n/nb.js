OC.L10N.register(
    "metadata",
    {
    "Location" : "Sted",
    "Title" : "Tittel",
    "Copyright" : "Opphavsrett",
    "Date" : "Dato",
    "Comment" : "Kommentar",
    "Description" : "Beskrivelse",
    "Rating" : "Vurdering",
    "Tags" : "Merkelapper",
    "Credits" : "Bidragsytere",
    "Manual" : "Manuell",
    "Unknown" : "Ukjent",
    "Pattern" : "Mønster",
    "Other" : "Annet"
},
"nplurals=2; plural=(n != 1);");
