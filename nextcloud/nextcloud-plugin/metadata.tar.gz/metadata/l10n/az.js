OC.L10N.register(
    "metadata",
    {
    "Location" : "Yerləşdiyiniz ünvan",
    "Title" : "Başlıq",
    "Date" : "Date",
    "Comment" : "Komentariya",
    "Description" : "Açıqlanma",
    "Tags" : "Işarələr",
    "Other" : "Digər"
},
"nplurals=2; plural=(n != 1);");
