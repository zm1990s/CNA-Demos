OC.L10N.register(
    "notes",
    {
    "Error" : "Fehler",
    "Notes" : "Notizen",
    "Settings" : "Astellungen",
    "Today" : "Haut",
    "Yesterday" : "Gëschter",
    "Rename" : "Ëmbenennen",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detailer",
    "Edit" : "Änneren",
    "Android app" : "Android-App",
    "iOS app" : "iOS-App"
},
"nplurals=2; plural=(n != 1);");
