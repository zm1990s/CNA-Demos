OC.L10N.register(
    "notes",
    {
    "Error" : "ایرر",
    "Notes" : "Notes",
    "Settings" : "سیٹینگز",
    "Today" : "آج",
    "Rename" : "Rename",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "تدوین کریں"
},
"nplurals=2; plural=(n != 1);");
