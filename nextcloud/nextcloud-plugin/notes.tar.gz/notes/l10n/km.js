OC.L10N.register(
    "notes",
    {
    "Error" : "កំហុស",
    "New note" : "កំណត់​ចំណាំ​ថ្មី",
    "Notes" : "កំណត់​ចំណាំ",
    "Settings" : "ការកំណត់",
    "Today" : "ថ្ងៃ​នេះ",
    "Rename" : "ប្ដូរ​ឈ្មោះ",
    "Delete note" : "លុប​កំណត់​ចំណាំ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "ព័ត៌មាន​លម្អិត",
    "Edit" : "កែប្រែ"
},
"nplurals=1; plural=0;");
