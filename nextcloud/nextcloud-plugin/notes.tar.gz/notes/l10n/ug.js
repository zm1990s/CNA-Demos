OC.L10N.register(
    "notes",
    {
    "Error" : "خاتالىق",
    "Notes" : "ئىزاھاتلار",
    "Settings" : "تەڭشەكلەر",
    "Today" : "بۈگۈن",
    "Rename" : "ئات ئۆزگەرت",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "تەھرىر"
},
"nplurals=2; plural=(n != 1);");
