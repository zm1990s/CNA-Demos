OC.L10N.register(
    "notes",
    {
    "Error" : "Greška",
    "Notes" : "Notes",
    "Settings" : "Podešavanje",
    "Today" : "Danas",
    "Yesterday" : "Jučer",
    "Rename" : "Preimenuj",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Izmjeni",
    "Android app" : "Android aplikacija",
    "iOS app" : "iOS aplikacija"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
