OC.L10N.register(
    "notes",
    {
    "Error" : "Error",
    "New note" : "Nòta novèla",
    "Notes" : "Nòtas",
    "Settings" : "Paramètres",
    "Today" : "Uèi",
    "Yesterday" : "Ièr",
    "Rename" : "Renomenar",
    "Delete note" : "Suprimir la nòta",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detalhs",
    "Edit" : "Modificar",
    "_%n word_::_%n words_" : ["%n mot","%n mots"],
    "Android app" : "Aplicacion Android",
    "iOS app" : "Aplicacion iOS"
},
"nplurals=2; plural=(n > 1);");
