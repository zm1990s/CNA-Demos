OC.L10N.register(
    "notes",
    {
    "Error" : "Lỗi",
    "New note" : "Ghi chú mới",
    "Notes" : "Ghi chép",
    "Settings" : "Thiết lập",
    "Categories" : "Các hạng mục",
    "Loading …" : "Đang tải...",
    "Today" : "Hôm nay",
    "Yesterday" : "Hôm qua",
    "Rename" : "Đổi tên",
    "Remove from favorites" : "Xóa khỏi ưa thích",
    "Add to favorites" : "Thêm vào ưa thích",
    "Details" : "Thông tin",
    "Edit" : "Chỉnh sửa",
    "Android app" : "Ứng dụng Android",
    "iOS app" : "Ứng dụng IOS"
},
"nplurals=1; plural=0;");
