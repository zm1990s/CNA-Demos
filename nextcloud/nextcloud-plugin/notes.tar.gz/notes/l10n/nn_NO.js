OC.L10N.register(
    "notes",
    {
    "Error" : "Feil",
    "New note" : "Nytt notat",
    "Notes" : "Notat",
    "Settings" : "Instillingar",
    "Today" : "I dag",
    "Yesterday" : "i går",
    "Rename" : "Gje nytt namn",
    "Delete note" : "Slett notat",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detaljar",
    "Edit" : "Endra",
    "Category" : "Kategori"
},
"nplurals=2; plural=(n != 1);");
