OC.L10N.register(
    "notes",
    {
    "Error" : "Ralat",
    "New note" : "Note baharu",
    "Notes" : "Nota",
    "Settings" : "Tetapan",
    "Today" : "Hari ini",
    "Yesterday" : "Semalam",
    "Rename" : "Namakan",
    "Delete note" : "Hapus nota",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Sunting"
},
"nplurals=1; plural=0;");
