OC.L10N.register(
    "notes",
    {
    "Error" : "Səhv",
    "New note" : "Yeni qeyd",
    "Notes" : "Qeydlər",
    "Settings" : "Quraşdırmalar",
    "Today" : "Bu gün",
    "Yesterday" : "Dünən",
    "Rename" : "Adı dəyiş",
    "Delete note" : "Qeydi sil",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detallar",
    "Edit" : "Dəyişiklik et",
    "Android app" : "Android proqramı",
    "iOS app" : "iOS proqramı"
},
"nplurals=2; plural=(n != 1);");
