OC.L10N.register(
    "notes",
    {
    "Error" : "Viga",
    "New note" : "Uus märge",
    "Notes" : "Märkmed",
    "Settings" : "Seaded",
    "Categories" : "Kategooriad",
    "Today" : "Täna",
    "Yesterday" : "Eile",
    "Rename" : "Nimeta ümber",
    "Delete note" : "Kustuta märge",
    "Remove from favorites" : "Eemalda lemmikutest",
    "Add to favorites" : "Lisa lemmikutesse",
    "Details" : "Üksikasjad",
    "Preview" : "Eelvaade",
    "Edit" : "Redigeeri",
    "Category" : "Kategooria",
    "_%n word_::_%n words_" : ["%n sõna","%n sõna"],
    "Android app" : "Androidi rakendus",
    "iOS app" : "iOS-i rakendus"
},
"nplurals=2; plural=(n != 1);");
