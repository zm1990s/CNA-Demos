OC.L10N.register(
    "notes",
    {
    "Error" : "Error",
    "New note" : "Nove nota",
    "Notes" : "Notas",
    "Settings" : "Configurationes",
    "Today" : "Hodie",
    "Yesterday" : "Heri",
    "This week" : "Iste septimana",
    "This month" : "Iste mense",
    "Rename" : "Renominar",
    "Delete note" : "Dele nota",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detalios",
    "Preview" : "Previsualisar",
    "Edit" : "Modificar",
    "Category" : "Categoria",
    "_%n word_::_%n words_" : ["%n parola","%n parolas"],
    "Android app" : "Application Android",
    "iOS app" : "Application iOS"
},
"nplurals=2; plural=(n != 1);");
