OC.L10N.register(
    "notes",
    {
    "Error" : "Xato",
    "New note" : "Yangi eslatma",
    "Notes" : "Eslatmalar",
    "Settings" : "Sozlamalar",
    "Rename" : "Nomni o'zgartiring"
},
"nplurals=1; plural=0;");
