OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Saxlanıldı",
    "Video" : "Video",
    "Upload" : "Serverə yüklə",
    "Loading" : "Loading",
    "Username" : "İstifadəçi adı",
    "Password" : "Şifrə",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "Saxla",
    "minutes" : "dəqiqələr",
    "hours" : "saatlar",
    "days" : "günlər",
    "weeks" : "həftələr"
},
"nplurals=2; plural=(n != 1);");
