OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Enregistrat",
    "Video" : "Video",
    "Uploaded" : "Mandat",
    "Upload" : "Cargament",
    "Loading" : "Loading",
    "Username" : "Nom d'utilizaire",
    "Password" : "Senhal",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "Salvar",
    "minutes" : "minutas",
    "hours" : "oras",
    "days" : "jorns",
    "weeks" : "setmanas"
},
"nplurals=2; plural=(n > 1);");
