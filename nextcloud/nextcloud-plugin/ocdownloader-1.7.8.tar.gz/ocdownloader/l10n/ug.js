OC.L10N.register(
    "ocdownloader",
    {
    "Video" : "Video",
    "Upload" : "يۈكلە",
    "Loading" : "Loading",
    "Username" : "ئىشلەتكۈچى ئاتى",
    "Password" : "ئىم",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "ساقلا"
},
"nplurals=1; plural=0;");
