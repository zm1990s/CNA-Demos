OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Guardado",
    "Video" : "Video",
    "Uploaded" : "Cargado",
    "Paused" : "Pausado",
    "Upload" : "Cargar",
    "Loading" : "Cargando",
    "Options" : "Opciones",
    "Username" : "Nombre de usuario",
    "Password" : "Contraseña",
    "Filename" : "Nombre de archivo",
    "No" : "No",
    "Yes" : "Si",
    "General settings" : "Configuraciones generales",
    "Save" : "Guardar",
    "minutes" : "minutos",
    "hours" : "horas",
    "days" : "días",
    "weeks" : "semanas"
},
"nplurals=2; plural=(n != 1);");
