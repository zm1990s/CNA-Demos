OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Lagret",
    "Video" : "Video",
    "Uploaded" : "Opplastet",
    "Paused" : "Pauset",
    "Upload" : "Last opp",
    "Loading" : "Laster",
    "Username" : "Brukernavn",
    "Password" : "Passord",
    "Filename" : "Filnavn",
    "No" : "Nei",
    "Yes" : "Ja",
    "General settings" : "Generelle innstillinger",
    "Save" : "Lagre",
    "minutes" : "minutter",
    "hours" : "timer",
    "days" : "dager",
    "weeks" : "uker",
    "months" : "måneder",
    "years" : "år"
},
"nplurals=2; plural=(n != 1);");
