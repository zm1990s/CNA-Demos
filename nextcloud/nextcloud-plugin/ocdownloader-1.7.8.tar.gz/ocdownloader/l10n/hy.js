OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Պահված",
    "Video" : "Video",
    "Upload" : "Բեռնել",
    "Loading" : "Loading",
    "Username" : "Օգտանուն",
    "Password" : "Գաղտնաբառ",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "Պահպանել",
    "minutes" : "րոպե",
    "hours" : "ժամ",
    "days" : "օր"
},
"nplurals=2; plural=(n != 1);");
