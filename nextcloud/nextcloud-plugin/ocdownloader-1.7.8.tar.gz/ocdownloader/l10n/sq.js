OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Ruajtur",
    "Video" : "Video",
    "Uploaded" : "U ngarkua",
    "Paused" : "Pushuar",
    "Upload" : "Ngarkoni",
    "Loading" : "Duke ngarkuar",
    "Username" : "Username",
    "Password" : "Fjalëkalim",
    "Filename" : "Emri i skedarit",
    "No" : "Jo",
    "Yes" : "Yes",
    "General settings" : "Opsjonet e Pergjithshme",
    "Save" : "Ruaj",
    "minutes" : "minuta",
    "hours" : "orë",
    "days" : "ditë",
    "weeks" : "javë"
},
"nplurals=2; plural=(n != 1);");
