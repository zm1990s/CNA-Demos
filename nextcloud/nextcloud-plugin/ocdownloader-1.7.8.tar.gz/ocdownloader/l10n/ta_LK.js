OC.L10N.register(
    "ocdownloader",
    {
    "Video" : "Video",
    "Upload" : "பதிவேற்றுக",
    "Loading" : "Loading",
    "Username" : "பயனாளர் பெயர்",
    "Password" : "கடவுச்சொல்",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "சேமிக்க "
},
"nplurals=2; plural=(n != 1);");
