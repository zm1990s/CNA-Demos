OC.L10N.register(
    "ocdownloader",
    {
    "Video" : "Video",
    "Upload" : "Muat naik",
    "Loading" : "Loading",
    "Username" : "Nama pengguna",
    "Password" : "Kata laluan",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
