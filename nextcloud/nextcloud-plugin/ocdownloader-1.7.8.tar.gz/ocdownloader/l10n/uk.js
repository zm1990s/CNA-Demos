OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Збережено",
    "Video" : "Video",
    "Uploaded" : "Завантажені",
    "Paused" : "Призупинено",
    "Upload" : "Вивантажити",
    "Loading" : "Завантаження",
    "Username" : "Логін",
    "Password" : "Пароль",
    "Filename" : "Ім'я файлу",
    "No" : "Ні",
    "Yes" : "Так",
    "General settings" : "Загальні налаштування",
    "Save" : "Зберегти",
    "minutes" : "хвилини",
    "hours" : "години",
    "days" : "дні",
    "weeks" : "тижні",
    "months" : "місяці",
    "years" : "роки"
},
"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);");
