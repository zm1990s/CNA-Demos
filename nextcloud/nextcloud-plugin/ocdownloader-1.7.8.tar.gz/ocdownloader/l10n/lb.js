OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Gespäichert",
    "Video" : "Video",
    "Uploaded" : "Eropgelueden",
    "Paused" : "Gepaust",
    "Upload" : "Eroplueden",
    "Loading" : "Loading",
    "Username" : "Benotzernumm",
    "Password" : "Passwuert",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "Späicheren",
    "minutes" : "Minutten",
    "hours" : "Stonnen",
    "days" : "Deeg",
    "weeks" : "Wochen"
},
"nplurals=2; plural=(n != 1);");
