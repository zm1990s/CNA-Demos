OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Konservita",
    "Video" : "Video",
    "Uploaded" : "Alŝutita",
    "Upload" : "Alŝuti",
    "Loading" : "Ŝargado",
    "Username" : "Uzantnomo",
    "Password" : "Pasvorto",
    "Filename" : "Dosiernomo",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "Konservi",
    "minutes" : "minutoj",
    "hours" : "horojn",
    "days" : "tagojn",
    "weeks" : "semajnoj"
},
"nplurals=2; plural=(n != 1);");
