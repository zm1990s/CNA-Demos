OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "บันทึกแล้ว",
    "Video" : "Video",
    "Uploaded" : "ถูกอัพโหลด",
    "Paused" : "หยุดชั่วคราวแล้ว",
    "Upload" : "อัพโหลด",
    "Loading" : "Loading",
    "Username" : "ชื่อผู้ใช้",
    "Password" : "รหัสผ่าน",
    "No" : "ไม่ใช่",
    "Yes" : "ใช่",
    "Save" : "บันทึก",
    "minutes" : "นาที",
    "hours" : "ชั่วโมง",
    "days" : "วัน",
    "weeks" : "สัปดาห์"
},
"nplurals=1; plural=0;");
