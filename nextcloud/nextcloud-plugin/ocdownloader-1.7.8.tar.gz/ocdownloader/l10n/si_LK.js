OC.L10N.register(
    "ocdownloader",
    {
    "Video" : "Video",
    "Upload" : "උඩුගත කරන්න",
    "Loading" : "Loading",
    "Username" : "පරිශීලක නම",
    "Password" : "මුර පදය",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "සුරකින්න"
},
"nplurals=2; plural=(n != 1);");
