OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "﻿ಉಳಿಸಿದ",
    "Video" : "Video",
    "Upload" : "ವರ್ಗಾಯಿಸಿ",
    "Loading" : "Loading",
    "Username" : "﻿ಬಳಕೆಯ ಹೆಸರು",
    "Password" : "ಗುಪ್ತ ಪದ",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "﻿ಉಳಿಸಿ",
    "days" : "﻿ದಿನಗಳು"
},
"nplurals=2; plural=(n > 1);");
