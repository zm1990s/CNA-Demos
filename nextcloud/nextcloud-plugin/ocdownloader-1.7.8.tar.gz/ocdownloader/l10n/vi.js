OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Đã lưu",
    "Video" : "Video",
    "Uploaded" : "Đã tải lên",
    "Upload" : "Tải lên",
    "Loading" : "Đang tải",
    "Username" : "Tài khoản",
    "Password" : "Mật khẩu",
    "Filename" : "Tên tập tin",
    "No" : "Không",
    "Yes" : "Đồng ý",
    "Save" : "Lưu",
    "hours" : "giờ",
    "days" : "ngày"
},
"nplurals=1; plural=0;");
