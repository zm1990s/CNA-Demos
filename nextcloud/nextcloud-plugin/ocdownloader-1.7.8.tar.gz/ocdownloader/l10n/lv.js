OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Saglabāts",
    "Video" : "Video",
    "Uploaded" : "Augšupielādēts",
    "Paused" : "Apturēts",
    "Upload" : "Augšupielādēt",
    "Loading" : "Ielādē",
    "Username" : "Lietotājvārds",
    "Password" : "Parole",
    "Filename" : "Datnes nosaukums",
    "No" : "Nē",
    "Yes" : "Jā",
    "General settings" : "Vispārīgie iestatījumi",
    "Save" : "Saglabāt",
    "minutes" : "minūtes",
    "hours" : "stundas",
    "days" : "dienas",
    "weeks" : "nedēļas"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
