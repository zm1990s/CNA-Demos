OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "সংরক্ষণ করা হলো",
    "Video" : "Video",
    "Uploaded" : "আপলোড করা হয়েছে",
    "Upload" : "আপলোড",
    "Loading" : "Loading",
    "Username" : "ব্যবহারকারী",
    "Password" : "কূটশব্দ",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "সংরক্ষণ",
    "minutes" : "মিনিটসমূহ",
    "hours" : "ঘন্টাসমূহ",
    "days" : "দিনগুলি",
    "weeks" : "সপ্তাহসমূহ"
},
"nplurals=2; plural=(n != 1);");
