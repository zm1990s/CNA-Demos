OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Wedi'u cadw",
    "Video" : "Video",
    "Upload" : "Llwytho i fyny",
    "Loading" : "Llwytho",
    "Username" : "Enw defnyddiwr",
    "Password" : "Cyfrinair",
    "No" : "No",
    "Yes" : "Iawn",
    "Save" : "Cadw",
    "hours" : "awr",
    "days" : "diwrnod"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
