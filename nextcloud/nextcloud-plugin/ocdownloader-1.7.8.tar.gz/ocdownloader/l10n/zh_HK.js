OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "已儲存",
    "Video" : "Video",
    "Upload" : "上戴",
    "Loading" : "Loading",
    "Username" : "用戶名稱",
    "Password" : "密碼",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "儲存",
    "minutes" : "分鐘",
    "hours" : "小時",
    "days" : "日",
    "weeks" : "星期"
},
"nplurals=1; plural=0;");
