OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Хадгалах",
    "Video" : "Video",
    "Uploaded" : "Байршуулсан",
    "Paused" : "Зогсоосон",
    "Upload" : "байршуулах",
    "Loading" : "Loading",
    "Username" : "Хэрэглэгчийн нэр",
    "Password" : "Нууц үг",
    "Filename" : "Файлын нэр",
    "No" : "Үгүй",
    "Yes" : "Тийм",
    "Save" : "Хадгалах",
    "hours" : "хугацаа",
    "days" : "өдрүүд"
},
"nplurals=2; plural=(n != 1);");
