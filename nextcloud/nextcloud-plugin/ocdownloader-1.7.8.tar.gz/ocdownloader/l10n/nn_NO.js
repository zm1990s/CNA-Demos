OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Lagra",
    "Video" : "Video",
    "Upload" : "Last opp",
    "Loading" : "Loading",
    "Username" : "Brukarnamn",
    "Password" : "Passord",
    "No" : "Nei",
    "Yes" : "Ja",
    "Save" : "Lagre",
    "minutes" : "minutt",
    "hours" : "timar"
},
"nplurals=2; plural=(n != 1);");
