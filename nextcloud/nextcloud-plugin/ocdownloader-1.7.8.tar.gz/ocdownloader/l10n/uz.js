OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Saqlangan",
    "Upload" : "Yuklash",
    "Loading" : "Yuklanmoqda",
    "Username" : "Foydalanuvchi nomi",
    "Password" : "Parol",
    "No" : "Yo'q",
    "Yes" : "Ha",
    "Save" : "Saqlash",
    "minutes" : "daqiqalar"
},
"nplurals=1; plural=0;");
