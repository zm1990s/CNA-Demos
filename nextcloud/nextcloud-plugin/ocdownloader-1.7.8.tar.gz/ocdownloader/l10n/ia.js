OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Salveguardate",
    "Video" : "Video",
    "Upload" : "Incargar",
    "Loading" : "Loading",
    "Username" : "Nomine de usator",
    "Password" : "Contrasigno",
    "No" : "No",
    "Yes" : "Si",
    "Save" : "Salveguardar",
    "minutes" : "minutas",
    "hours" : "horas",
    "days" : "dies",
    "weeks" : "septimanas"
},
"nplurals=2; plural=(n != 1);");
