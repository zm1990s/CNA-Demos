OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Guardado",
    "Video" : "Video",
    "Uploaded" : "Cargado",
    "Paused" : "En pausa",
    "Upload" : "Cargar",
    "Loading" : "Cargando",
    "Username" : "Usuario",
    "Password" : "Contraseña",
    "Filename" : "Nombre del archivo",
    "No" : "No",
    "Yes" : "Sí",
    "General settings" : "Configuraciones generales",
    "Save" : "Guardar",
    "minutes" : "minutos",
    "hours" : "horas",
    "days" : "días",
    "weeks" : "semanas"
},
"nplurals=2; plural=(n != 1);");
