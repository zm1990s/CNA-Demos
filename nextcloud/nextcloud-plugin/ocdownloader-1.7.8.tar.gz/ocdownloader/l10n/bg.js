OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Запазено",
    "Video" : "Видео",
    "Uploaded" : "Качени",
    "Paused" : "На пауза",
    "Upload" : "Качване",
    "Loading" : "Зареждане",
    "Username" : "Потребител",
    "Password" : "Парола",
    "Filename" : "Име на файла",
    "No" : "Не",
    "Yes" : "Да",
    "General settings" : "Общи настройки",
    "Save" : "Запазване",
    "minutes" : "минути",
    "hours" : "часове",
    "days" : "дни",
    "weeks" : "седмици",
    "months" : "месеци",
    "years" : "години"
},
"nplurals=2; plural=(n != 1);");
