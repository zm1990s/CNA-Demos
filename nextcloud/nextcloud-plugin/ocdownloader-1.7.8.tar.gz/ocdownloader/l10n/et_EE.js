OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Salvestatud",
    "Video" : "Video",
    "Uploaded" : "Ülesse laetud",
    "Paused" : "Peatatud",
    "Upload" : "Lae üles",
    "Loading" : "Laadimine",
    "Username" : "Kasutajanimi",
    "Password" : "Parool",
    "Filename" : "Faili nimi",
    "No" : "Ei",
    "Yes" : "Jah",
    "Save" : "Salvesta",
    "minutes" : "minutit",
    "hours" : "tundi",
    "days" : "päeva",
    "weeks" : "nädalat"
},
"nplurals=2; plural=(n != 1);");
