OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Bewaar",
    "Video" : "Video",
    "Upload" : "Laai op",
    "Loading" : "Laai tans..",
    "Username" : "Gebruikersnaam",
    "Password" : "Wagwoord",
    "Filename" : "Lêernaam",
    "No" : "Nee",
    "Yes" : "Ja",
    "Save" : "Stoor",
    "minutes" : "minute",
    "hours" : "uur",
    "days" : "dae",
    "weeks" : "weke"
},
"nplurals=2; plural=(n != 1);");
