OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "저장됨",
    "Video" : "비디오",
    "Uploaded" : "업로드 완료",
    "Paused" : "일시 정지",
    "Upload" : "업로드",
    "Loading" : "불러오는 중",
    "Username" : "사용자 이름",
    "Password" : "암호",
    "Filename" : "파일 이름",
    "No" : "아니요",
    "Yes" : "예",
    "General settings" : "일반 설정",
    "Save" : "저장",
    "minutes" : "분",
    "hours" : "시간",
    "days" : "일",
    "weeks" : "주"
},
"nplurals=1; plural=0;");
