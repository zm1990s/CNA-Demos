OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Saved",
    "Video" : "Video",
    "Uploaded" : "Uploaded",
    "Paused" : "Paused",
    "Upload" : "Upload",
    "Loading" : "Loading",
    "Username" : "Username",
    "Password" : "Password",
    "Filename" : "Filename",
    "No" : "No",
    "Yes" : "Yes",
    "General settings" : "General settings",
    "Save" : "Save",
    "minutes" : "minutes",
    "hours" : "hours",
    "days" : "days",
    "weeks" : "weeks"
},
"nplurals=2; plural=(n != 1);");
