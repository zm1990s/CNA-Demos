OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Guardáu",
    "Video" : "Video",
    "Uploaded" : "Xubíu",
    "Paused" : "Pausáu",
    "Upload" : "Xubir",
    "Loading" : "Cargando",
    "Username" : "Nome d'usuariu",
    "Password" : "Password",
    "Filename" : "Nome de ficheru",
    "No" : "Non",
    "Yes" : "Sí",
    "General settings" : "Axustes xenerales",
    "Save" : "Guardar",
    "minutes" : "minutos",
    "hours" : "hores",
    "days" : "díes",
    "weeks" : "selmanes"
},
"nplurals=2; plural=(n != 1);");
