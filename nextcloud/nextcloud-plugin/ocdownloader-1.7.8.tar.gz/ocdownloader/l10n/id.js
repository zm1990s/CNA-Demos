OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Disimpan",
    "Video" : "Video",
    "Uploaded" : "Diunggah",
    "Paused" : "Dihentikan",
    "Upload" : "Unggah",
    "Loading" : "Memuat",
    "Options" : "Pilihan",
    "Username" : "Nama pengguna",
    "Password" : "Kata kunci",
    "Filename" : "Nama berkas",
    "No" : "Tidak",
    "Yes" : "Ya",
    "Save" : "Simpan",
    "minutes" : "menit",
    "hours" : "jam",
    "days" : "hari",
    "weeks" : "minggu"
},
"nplurals=1; plural=0;");
