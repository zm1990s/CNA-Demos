OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "បាន​រក្សាទុក",
    "Video" : "Video",
    "Upload" : "ផ្ទុក​ឡើង",
    "Loading" : "Loading",
    "Username" : "ឈ្មោះ​អ្នកប្រើ",
    "Password" : "ពាក្យសម្ងាត់",
    "No" : "No",
    "Yes" : "Yes",
    "Save" : "រក្សាទុក"
},
"nplurals=1; plural=0;");
