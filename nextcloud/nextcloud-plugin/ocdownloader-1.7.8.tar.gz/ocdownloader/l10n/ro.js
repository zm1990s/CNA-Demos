OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "Salvat",
    "Video" : "Video",
    "Uploaded" : "Încărcat",
    "Paused" : "oprit",
    "Upload" : "Încarcă",
    "Loading" : "Loading",
    "Username" : "Nume utilizator",
    "Password" : "Parolă",
    "Filename" : "Nume fișier",
    "No" : "Nu",
    "Yes" : "a",
    "Save" : "Salvează",
    "minutes" : "minute",
    "hours" : "ore",
    "days" : "zile",
    "weeks" : "săptămâni"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
