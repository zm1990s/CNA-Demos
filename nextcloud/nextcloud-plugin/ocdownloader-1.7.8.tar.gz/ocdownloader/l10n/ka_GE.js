OC.L10N.register(
    "ocdownloader",
    {
    "Saved" : "შენახულია",
    "Video" : "ვიდეო",
    "Uploaded" : "აიტვირთა",
    "Paused" : "დაპაუზებულია",
    "Upload" : "ატვირთვა",
    "Loading" : "იტვირთება",
    "Username" : "მომხმარებელი",
    "Password" : "პაროლი",
    "Filename" : "ფაილის სახელი",
    "No" : "არა",
    "Yes" : "კი",
    "General settings" : "მთავარი პარამეტრები",
    "Save" : "შენახვა",
    "minutes" : "წუთი",
    "hours" : "საათი",
    "days" : "დღე",
    "weeks" : "კვირა"
},
"nplurals=2; plural=(n!=1);");
